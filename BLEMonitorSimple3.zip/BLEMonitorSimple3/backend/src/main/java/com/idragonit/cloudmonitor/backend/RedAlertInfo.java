package com.idragonit.cloudmonitor.backend;

import java.util.ArrayList;

/** The object model for the data we are sending through endpoints */
public class RedAlertInfo {

    private String macAddress;
    private String cause;
    private Long span = 0L;
    private Long[] trends;
    private Integer[] trendsPercent;
    private Integer totalCount = 0;

    private String startTime;
    private String endTime;

    public String getMachineName() {
        return machineName;
    }

    public void setMachineName(String machineName) {
        this.machineName = machineName;

        if (this.machineName == null)
            this.machineName = macAddress;
    }

    private String machineName;

    private ArrayList<ProductivityInfo> infos = new ArrayList<ProductivityInfo>();


    public RedAlertInfo() {
        trends = new Long[7];
        trendsPercent = new Integer[7];

        for (int i = 0; i < 7; i++) {
            trends[i] = 0L;
            trendsPercent[i] = 0;
        }
    }

    public RedAlertInfo(int count) {
        trends = new Long[count];
        trendsPercent = new Integer[count];

        for (int i = 0; i < count; i++) {
            trends[i] = 0L;
            trendsPercent[i] = 0;
        }
    }

    public String getMacAddress() {
        return macAddress;
    }

    public void setMacAddress(String macAddress) {
        this.macAddress = macAddress;
    }

    public String getCause() {
        return cause;
    }

    public void setCause(String cause) {
        this.cause = macAddress;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String time) {
        startTime = time;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String time) {
        endTime = time;
    }

    public Long getSpan() {
        return span;
    }

    public void setSpan(Long value) {
        span = value;
    }

    public Long getTrends(int index) {
        return trends[index];
    }

    public Long[] getTrends() {
        return trends;
    }

    public void setTrends(int index, Long value) {
        trends[index] = value;
    }

    public Integer getTrendsPercent(int index) {
        return trendsPercent[index];
    }

    public Integer[] getTrendsPercent() {
        return trendsPercent;
    }

    public void setTrendsPercent(int index, Integer value) {
        trendsPercent[index] = value;
    }

    public ArrayList<ProductivityInfo> getProductivityInfo() {
        return infos;
    }

    public void addProductivityInfo(ProductivityInfo info) {
        infos.add(info);
    }

    public Integer getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(Integer value) {
        totalCount = value;
    }

}