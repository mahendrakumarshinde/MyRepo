package com.idragonit.cloudmonitor.backend;

/**
 * Created by idragon on 2/26/16.
 */
public class FeatureInfo {

    private Integer state;
    private Float featureValue;
    private Long startTime;
    private Long endTime;
    private Long duration;
    private String timeLabel;

    private String startTimePi;
    private String endTimePi;

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public Float getFeatureValue(){
        return featureValue;
    }

    public void setFeatureValue(Float featureValue){
        this.featureValue = featureValue;
    }

    public Long getStartTime() {
        return startTime;
    }

    public void setStartTime(Long value) {
        startTime = value;
    }

    public Long getEndTime() {
        return endTime;
    }

    public void setEndTime(Long value) {
        endTime = value;
        duration = endTime - startTime;
    }

    public Long getDuration() {
        return duration;
    }

    public void setDuration(Long value) {
        duration = value;
    }

    public String getTimeLabel() {
        return timeLabel;
    }

    public void setTimeLabel(String label) {
        this.timeLabel = label;
    }

    public String getStartTimePi() {
        return startTimePi;
    }

    public void setStartTimePi(String time) {
        this.startTimePi = time;
    }

    public String getEndTimePi() {
        return endTimePi;
    }

    public void setEndTimePi(String time) {
        this.endTimePi = time;
    }

}
