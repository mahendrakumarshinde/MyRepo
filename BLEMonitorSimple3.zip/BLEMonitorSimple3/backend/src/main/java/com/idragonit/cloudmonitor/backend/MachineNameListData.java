package com.idragonit.cloudmonitor.backend;

/**
 * Created by idragon on 2/26/16.
 */
public class MachineNameListData {

    private MachineNameData[] machine;

    public MachineNameData[] getMachine() {
        return machine;
    }

    public void setMachine(MachineNameData[] machine) {
        this.machine = machine;
    }
}
