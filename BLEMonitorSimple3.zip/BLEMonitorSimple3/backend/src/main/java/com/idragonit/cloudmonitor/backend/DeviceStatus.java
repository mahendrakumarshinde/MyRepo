package com.idragonit.cloudmonitor.backend;

/**
 * Created by idragon on 2/26/16.
 */
public class DeviceStatus {

    private String MAC_ADDRESS;
    private Integer Status;
    private Float Battery_Level;
    private String machineName;
    private Integer toolCount = 0;
    private Integer toolActiveCount = 0;
    private Integer toolID = 1;

    public String getMachineName() {
        return machineName;
    }

    public void setMachineName(String machineName) {
        this.machineName = machineName;

        if (this.machineName == null)
            this.machineName = MAC_ADDRESS;

    }

    public String getMacAddress() {
        return MAC_ADDRESS;
    }

    public void setMacAddress(String macAddress) {
        MAC_ADDRESS = macAddress;
    }

    public Integer getStatus() {
        return Status;
    }

    public void setStatus(Integer status) {
        Status = status;
    }

    public Float getBatteryLevel() {
        return Battery_Level;
    }

    public void setBatteryLevel(Float batteryLevel) {
        Battery_Level = batteryLevel;
    }

    public Integer getToolCount() {
        return toolCount;
    }

    public void setToolCount(Integer toolCount) {
        this.toolCount = toolCount;
    }

    public Integer getToolActiveCount() {
        return toolActiveCount;
    }

    public void setToolActiveCount(Integer toolActiveCount) {
        this.toolActiveCount = toolActiveCount;
    }

    public Integer getToolID() {
        return toolID;
    }

    public void setToolID(Integer toolID) {
        this.toolID = toolID;
    }
}
