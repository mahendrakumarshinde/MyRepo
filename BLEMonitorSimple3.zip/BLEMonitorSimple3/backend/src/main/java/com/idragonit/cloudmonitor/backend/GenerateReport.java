package com.idragonit.cloudmonitor.backend;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import java.net.URL;
import java.text.SimpleDateFormat;

/**
 * Created by idragon on 2/26/16.
 */
public class GenerateReport {

    public static String generatePDFReport(double[] actualHz, double[] actualg, double[] xyz, double actualHzCorrect, double actualgCorrect) {
        Document document = new Document(PageSize.A4, 20, 20, 15, 10);
        String fileName = null;

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        String time = format.format(new java.util.Date());
        //fileName = "Calibration Report" + time + ".pdf";
        fileName = "Calibration_Report.pdf";

        // create blob url
        //BlobstoreService blobService = BlobstoreServiceFactory.getBlobstoreService();
        //String uploadUrl = blobService.createUploadUrl("/blob/upload/" + fileName);
        //uploadUrl = "http://infinite-uptime-1232.appspot.com/images/Calibration_Report.pdf";
        try
        {

            // Post request to BlobstorageService
            // Note: We cannot use Apache HttpClient, since AppEngine only supports Url-Fetch
            //  See: https://cloud.google.com/appengine/docs/java/sockets/
            //URL url = new URL(uploadUrl);
            //HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            //connection.setDoOutput(true);

            //PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream("/gs/report" + fileName));
            //PdfWriter writer = PdfWriter.getInstance(document, connection.getOutputStream());
            PdfWriter writer = PdfWriter.getInstance(document, GcsUtils.outputStream("calibration", fileName));

            document.open();

            addPdfHeader(document);

            Paragraph paragraph = new Paragraph();
            paragraph.setSpacingAfter(10);
            paragraph.setSpacingBefore(10);
            paragraph.setAlignment(Element.ALIGN_CENTER);
            document.add(paragraph);
            addFrequencyCalibration(document, actualHz);

            paragraph = new Paragraph();
            paragraph.setSpacingAfter(5);
            paragraph.setSpacingBefore(5);
            paragraph.setAlignment(Element.ALIGN_CENTER);
            document.add(paragraph);
            addAmplitudeCalibration(document, actualg);

            document.add(paragraph);
            addOffsetsDetected(document, xyz);

            document.add(paragraph);
            addCorrectedFrequencyCalibration(document, actualHzCorrect);

            document.add(paragraph);
            addCorrectedAmplitudeCalibration(document, actualgCorrect);

            paragraph = new Paragraph();
            paragraph.setSpacingAfter(10);
            paragraph.setSpacingBefore(10);
            paragraph.setAlignment(Element.ALIGN_CENTER);
            document.add(paragraph);
            addPdfFooter(document);

            document.close();
            writer.close();

            return GcsUtils.mediaLink("calibration", fileName);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            fileName += ":" + e.toString();
        }

        //BlobKey key = blobService.createGsBlobKey("/gs/blob/upload/" + fileName);
        //return uploadUrl + ":" + key.toString();
        return fileName;
    }

    public static void addPdfHeader(Document document) throws Exception {
        Font titleFont = FontFactory.getFont(FontFactory.HELVETICA, 10, Font.NORMAL, BaseColor.BLACK);
        Font contentFont = FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD, BaseColor.BLACK);

        PdfPTable table = new PdfPTable(2); // 2 columns.
        table.setWidthPercentage(100);

        float[] headerColumnWidths = {4.5f, 5.5f};
        table.setWidths(headerColumnWidths);

        float[] columnWidths = {1f, 1f};
        PdfPCell cell;
        cell = new PdfPCell();

        //Image logo = Image.getInstance("ic_callibration_logo.png");
        Image logo = Image.getInstance(new URL("http://infinite-uptime-1232.appspot.com/images/ic_callibration_logo.png"));
        logo.setWidthPercentage(75);
        cell.addElement(logo);
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(Element.ALIGN_TOP);
        cell.setBorderColor(BaseColor.WHITE);
        cell.setPaddingTop(10);
        table.addCell(cell);

        cell = new PdfPCell();
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(Element.ALIGN_TOP);
        cell.setBorderColor(BaseColor.WHITE);

        PdfPTable infoTable;
        PdfPCell infoCell;

        String[] labelName = new String[] {"Report # :", "Manufacturer :", "MAC Address :", "Customer Tag # :",
                "Range :", "Least Count :", "Calibration Date :", "Next Calibration Date :", "Ambient Calibration Condition :"};
        String[] labelContent = new String[] {" 10/06/01", " Infinite Uptime", " XX - XX - XX - XX - XX - XX", " ____________",
                " +/- Xg", " 0.01g", " xx / xx / xx", " xx / xx / xx", " 28°C"};

        for (int i = 0; i < labelName.length; i++) {
            infoTable = new PdfPTable(2); // 2 columns.
            infoTable.setWidthPercentage(100);
            infoTable.setWidths(columnWidths);
            infoTable.setSpacingAfter(0);
            infoTable.setSpacingBefore(0);

            infoCell = new PdfPCell();
            Paragraph paragraph = new Paragraph(labelName[i], titleFont);
            paragraph.setAlignment(Element.ALIGN_RIGHT);
            infoCell.addElement(paragraph);
            infoCell.setBorderColor(BaseColor.WHITE);
            infoCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
            infoCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            infoCell.setPadding(0);
            infoCell.setFixedHeight(15);
            infoTable.addCell(infoCell);

            infoCell = new PdfPCell();
            infoCell.addElement(new Paragraph(labelContent[i], contentFont));
            infoCell.setBorderColor(BaseColor.WHITE);
            infoCell.setHorizontalAlignment(Element.ALIGN_LEFT);
            infoCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            infoCell.setPadding(0);
            infoCell.setFixedHeight(15);
            infoTable.addCell(infoCell);

            cell.addElement(infoTable);
        }

        table.addCell(cell);

        document.add(table);
    }

    public static void addFrequencyCalibration(Document document, double[] actualHz) throws Exception {
        Font titleFont = FontFactory.getFont(FontFactory.HELVETICA, 12, Font.NORMAL, BaseColor.WHITE);
        Font unitFont = FontFactory.getFont(FontFactory.HELVETICA, 10, Font.NORMAL, BaseColor.WHITE);
        Font headerFont = FontFactory.getFont(FontFactory.HELVETICA, 10, Font.NORMAL, BaseColor.WHITE);
        Font contentFont = FontFactory.getFont(FontFactory.HELVETICA, 10, Font.NORMAL, BaseColor.BLACK);

        int tablePercentage = 80;

        PdfPTable table = new PdfPTable(2); // 2 columns.
        table.setWidthPercentage(tablePercentage);
        table.setSpacingBefore(0f);
        table.setSpacingAfter(0f);

        float[] headerColumnWidths = {1f, 1f};
        table.setWidths(headerColumnWidths);

        PdfPCell cell;
        Paragraph paragraph;

        // Title
        cell = new PdfPCell();
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setBorderColor(BaseColor.BLACK);
        cell.setPaddingBottom(6);
        cell.setPaddingLeft(10);
        cell.setPaddingTop(0);
        cell.setBackgroundColor(BaseColor.BLACK);
        paragraph = new Paragraph("Frequency Calibration", titleFont);
        paragraph.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(paragraph);
        table.addCell(cell);

        cell = new PdfPCell();
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setBorderColor(BaseColor.BLACK);
        cell.setPaddingBottom(5);
        cell.setPaddingRight(10);
        cell.setPaddingTop(0);
        cell.setBackgroundColor(BaseColor.BLACK);
        paragraph = new Paragraph("Unit: Hz", unitFont);
        paragraph.setAlignment(Element.ALIGN_RIGHT);
        cell.addElement(paragraph);
        table.addCell(cell);

        document.add(table);

        // Header
        table = new PdfPTable(6);
        table.setWidthPercentage(tablePercentage);
        float[] columnWidths = {10f, 18f, 18f, 18f, 18f, 18f};
        table.setSpacingBefore(0f);
        table.setSpacingAfter(0f);

        table.setWidths(columnWidths);

        String[] headerName = new String[] {"No.", "Actual Hz", "Expected Hz", "% Difference", "Allowable Difference (%)", "Result"};

        for (int i = 0; i < headerName.length; i++) {
            cell = new PdfPCell();
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            cell.setBorderColor(BaseColor.BLACK);
            cell.setBackgroundColor(new BaseColor(0x66, 0x66, 0x66));
            cell.setPadding(5);
            cell.setPaddingTop(0);
            paragraph = new Paragraph(headerName[i], headerFont);
            paragraph.setAlignment(Element.ALIGN_CENTER);
            cell.addElement(paragraph);
            table.addCell(cell);
        }

        document.add(table);

        // Content
        String[] numberName = new String[] {"1.", "2.", "3."};
        int[] expectedHz = new int[] {20, 50, 100};

        for (int k = 0; k < numberName.length; k++) {
            table = new PdfPTable(6);
            table.setWidthPercentage(tablePercentage);
            table.setSpacingBefore(0f);
            table.setSpacingAfter(0f);

            table.setWidths(columnWidths);

            double difference = (actualHz[k] - expectedHz[k]) / expectedHz[k] * 100f;

            for (int i = 0; i < headerName.length; i++) {
                cell = new PdfPCell();
                cell.setHorizontalAlignment(Element.ALIGN_CENTER);
                cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
                cell.setBorderColor(BaseColor.BLACK);
                cell.setPadding(5);
                cell.setPaddingTop(0);

                if (i == 0) {
                    paragraph = new Paragraph(numberName[k], contentFont);
                    paragraph.setAlignment(Element.ALIGN_CENTER);
                    cell.addElement(paragraph);
                }
                else if (i == 1) {
                    paragraph = new Paragraph(String.format("%.6f", actualHz[k]), contentFont);
                    paragraph.setAlignment(Element.ALIGN_CENTER);
                    cell.addElement(paragraph);
                }
                else if (i == 2) {
                    paragraph = new Paragraph(String.valueOf(expectedHz[k]), contentFont);
                    paragraph.setAlignment(Element.ALIGN_CENTER);
                    cell.addElement(paragraph);
                }
                else if (i == 3) {
                    paragraph = new Paragraph(String.format("%.6f", difference), contentFont);
                    paragraph.setAlignment(Element.ALIGN_CENTER);
                    cell.addElement(paragraph);
                }
                else if (i == 4) {
                    paragraph = new Paragraph("±1%", contentFont);
                    paragraph.setAlignment(Element.ALIGN_CENTER);
                    cell.addElement(paragraph);
                }
                else {
                    if (Math.abs(difference) < 1)
                        paragraph = new Paragraph("OK", contentFont);
                    else
                        paragraph = new Paragraph("NOT OK", contentFont);

                    paragraph.setAlignment(Element.ALIGN_CENTER);
                    cell.addElement(paragraph);
                }

                table.addCell(cell);
            }

            document.add(table);
        }
    }

    public static void addAmplitudeCalibration(Document document, double[] actualg) throws Exception {
        Font titleFont = FontFactory.getFont(FontFactory.HELVETICA, 12, Font.NORMAL, BaseColor.WHITE);
        Font unitFont = FontFactory.getFont(FontFactory.HELVETICA, 10, Font.NORMAL, BaseColor.WHITE);
        Font headerFont = FontFactory.getFont(FontFactory.HELVETICA, 10, Font.NORMAL, BaseColor.WHITE);
        Font contentFont = FontFactory.getFont(FontFactory.HELVETICA, 10, Font.NORMAL, BaseColor.BLACK);

        int tablePercentage = 80;

        PdfPTable table = new PdfPTable(2); // 2 columns.
        table.setWidthPercentage(tablePercentage);
        table.setSpacingBefore(0f);
        table.setSpacingAfter(0f);

        float[] headerColumnWidths = {1f, 1f};
        table.setWidths(headerColumnWidths);

        PdfPCell cell;
        Paragraph paragraph;

        // Title
        cell = new PdfPCell();
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setBorderColor(BaseColor.BLACK);
        cell.setPaddingBottom(6);
        cell.setPaddingLeft(10);
        cell.setPaddingTop(0);
        cell.setBackgroundColor(BaseColor.BLACK);
        paragraph = new Paragraph("Amplitude Calibration", titleFont);
        paragraph.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(paragraph);
        table.addCell(cell);

        cell = new PdfPCell();
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setBorderColor(BaseColor.BLACK);
        cell.setPaddingBottom(5);
        cell.setPaddingRight(10);
        cell.setPaddingTop(0);
        cell.setBackgroundColor(BaseColor.BLACK);
        paragraph = new Paragraph("Unit: g pk", unitFont);
        paragraph.setAlignment(Element.ALIGN_RIGHT);
        cell.addElement(paragraph);
        table.addCell(cell);

        document.add(table);

        // Header
        table = new PdfPTable(6);
        table.setWidthPercentage(tablePercentage);
        float[] columnWidths = {10f, 18f, 18f, 18f, 18f, 18f};
        table.setSpacingBefore(0f);
        table.setSpacingAfter(0f);

        table.setWidths(columnWidths);

        String[] headerName = new String[] {"No.", "Actual g", "Expected g", "% Difference", "Allowable Difference (%)", "Result"};

        for (int i = 0; i < headerName.length; i++) {
            cell = new PdfPCell();
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            cell.setBorderColor(BaseColor.BLACK);
            cell.setBackgroundColor(new BaseColor(0x66, 0x66, 0x66));
            cell.setPadding(5);
            cell.setPaddingTop(0);
            paragraph = new Paragraph(headerName[i], headerFont);
            paragraph.setAlignment(Element.ALIGN_CENTER);
            cell.addElement(paragraph);
            table.addCell(cell);
        }

        document.add(table);

        // Content
        String[] numberName = new String[] {"1.", "2.", "3."};

        for (int k = 0; k < numberName.length; k++) {
            table = new PdfPTable(6);
            table.setWidthPercentage(tablePercentage);
            table.setSpacingBefore(0f);
            table.setSpacingAfter(0f);

            table.setWidths(columnWidths);

            double difference = ((actualg[k] - 1) / 1) * 100f;

            for (int i = 0; i < headerName.length; i++) {
                cell = new PdfPCell();
                cell.setHorizontalAlignment(Element.ALIGN_CENTER);
                cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
                cell.setBorderColor(BaseColor.BLACK);
                cell.setPadding(5);
                cell.setPaddingTop(0);

                if (i == 0) {
                    paragraph = new Paragraph(numberName[k], contentFont);
                    paragraph.setAlignment(Element.ALIGN_CENTER);
                    cell.addElement(paragraph);
                }
                else if (i == 1) {
                    paragraph = new Paragraph(String.format("%.6f", actualg[k]), contentFont);
                    paragraph.setAlignment(Element.ALIGN_CENTER);
                    cell.addElement(paragraph);
                }
                else if (i == 2) {
                    paragraph = new Paragraph("1", contentFont);
                    paragraph.setAlignment(Element.ALIGN_CENTER);
                    cell.addElement(paragraph);
                }
                else if (i == 3) {
                    paragraph = new Paragraph(String.format("%.6f", difference), contentFont);
                    paragraph.setAlignment(Element.ALIGN_CENTER);
                    cell.addElement(paragraph);
                }
                else if (i == 4) {
                    paragraph = new Paragraph("±1%", contentFont);
                    paragraph.setAlignment(Element.ALIGN_CENTER);
                    cell.addElement(paragraph);
                }
                else {
                    if (Math.abs(difference) < 1)
                        paragraph = new Paragraph("OK", contentFont);
                    else
                        paragraph = new Paragraph("NOT OK", contentFont);

                    paragraph.setAlignment(Element.ALIGN_CENTER);
                    cell.addElement(paragraph);
                }

                table.addCell(cell);
            }

            document.add(table);
        }
    }

    public static void addOffsetsDetected(Document document, double[] xyz) throws Exception {
        Font titleFont = FontFactory.getFont(FontFactory.HELVETICA, 12, Font.NORMAL, BaseColor.WHITE);
        Font unitFont = FontFactory.getFont(FontFactory.HELVETICA, 10, Font.NORMAL, BaseColor.WHITE);
        Font headerFont = FontFactory.getFont(FontFactory.HELVETICA, 10, Font.NORMAL, BaseColor.WHITE);
        Font contentFont = FontFactory.getFont(FontFactory.HELVETICA, 10, Font.NORMAL, BaseColor.BLACK);

        int tablePercentage = 80;

        PdfPTable tmptable = new PdfPTable(2); // 2 columns.
        tmptable.setWidthPercentage(tablePercentage);

        float[] headerColumnWidths = {6.5f, 3.5f};
        tmptable.setWidths(headerColumnWidths);

        PdfPCell tmpcell;
        tmpcell = new PdfPCell();

        tmpcell.setHorizontalAlignment(Element.ALIGN_LEFT);
        tmpcell.setVerticalAlignment(Element.ALIGN_TOP);
        tmpcell.setBorderColor(BaseColor.WHITE);
        tmpcell.setPadding(0);
        tmptable.addCell(tmpcell);

        tmpcell = new PdfPCell();
        tmpcell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        tmpcell.setVerticalAlignment(Element.ALIGN_TOP);
        tmpcell.setBorderColor(BaseColor.WHITE);
        tmpcell.setPadding(0);

        PdfPCell cell;
        PdfPTable table = new PdfPTable(1); // 2 columns.
        table.setWidthPercentage(100);
        table.setSpacingBefore(0f);
        table.setSpacingAfter(0f);

        table.setWidths(new float[] {1f});

        Paragraph paragraph;

        // Title
        cell = new PdfPCell();
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setBorderColor(BaseColor.BLACK);
        cell.setPaddingBottom(6);
        cell.setPaddingLeft(10);
        cell.setPaddingTop(0);
        cell.setBackgroundColor(BaseColor.BLACK);
        paragraph = new Paragraph("Offsets Detected", titleFont);
        paragraph.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(paragraph);
        table.addCell(cell);

        tmpcell.addElement(table);

        float[] columnWidths = {10f, 18f};
        // Content
        String[] numberName = new String[] {"X", "Y", "Z"};

        for (int k = 0; k < numberName.length; k++) {
            table = new PdfPTable(2);
            table.setWidthPercentage(100);
            table.setSpacingBefore(0f);
            table.setSpacingAfter(0f);

            table.setWidths(columnWidths);

            cell = new PdfPCell();
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            cell.setBorderColor(BaseColor.BLACK);
            cell.setBackgroundColor(new BaseColor(0x66, 0x66, 0x66));
            cell.setPadding(5);
            cell.setPaddingTop(0);

            paragraph = new Paragraph(numberName[k], contentFont);
            paragraph.setAlignment(Element.ALIGN_CENTER);
            cell.addElement(paragraph);

            table.addCell(cell);

            cell = new PdfPCell();
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            cell.setBorderColor(BaseColor.BLACK);
            cell.setPadding(5);
            cell.setPaddingTop(0);

            paragraph = new Paragraph(String.format("%.6f", xyz[k]) + "g", contentFont);
            paragraph.setAlignment(Element.ALIGN_CENTER);
            cell.addElement(paragraph);

            table.addCell(cell);

            tmpcell.addElement(table);
        }

        tmptable.addCell(tmpcell);
        document.add(tmptable);
    }

    public static void addCorrectedFrequencyCalibration(Document document, double actualHz) throws Exception {
        Font titleFont = FontFactory.getFont(FontFactory.HELVETICA, 12, Font.NORMAL, BaseColor.WHITE);
        Font unitFont = FontFactory.getFont(FontFactory.HELVETICA, 10, Font.NORMAL, BaseColor.WHITE);
        Font headerFont = FontFactory.getFont(FontFactory.HELVETICA, 10, Font.NORMAL, BaseColor.WHITE);
        Font contentFont = FontFactory.getFont(FontFactory.HELVETICA, 10, Font.NORMAL, BaseColor.BLACK);

        int tablePercentage = 80;

        PdfPTable table = new PdfPTable(2); // 2 columns.
        table.setWidthPercentage(tablePercentage);
        table.setSpacingBefore(0f);
        table.setSpacingAfter(0f);

        float[] headerColumnWidths = {1f, 1f};
        table.setWidths(headerColumnWidths);

        PdfPCell cell;
        Paragraph paragraph;

        // Title
        cell = new PdfPCell();
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setBorderColor(BaseColor.BLACK);
        cell.setPaddingBottom(6);
        cell.setPaddingLeft(10);
        cell.setPaddingTop(0);
        cell.setBackgroundColor(BaseColor.BLACK);
        paragraph = new Paragraph("Corrected Frequency Calibration", titleFont);
        paragraph.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(paragraph);
        table.addCell(cell);

        cell = new PdfPCell();
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setBorderColor(BaseColor.BLACK);
        cell.setPaddingBottom(5);
        cell.setPaddingRight(10);
        cell.setPaddingTop(0);
        cell.setBackgroundColor(BaseColor.BLACK);
        paragraph = new Paragraph("Unit: Hz", unitFont);
        paragraph.setAlignment(Element.ALIGN_RIGHT);
        cell.addElement(paragraph);
        table.addCell(cell);

        document.add(table);

        // Header
        table = new PdfPTable(6);
        table.setWidthPercentage(tablePercentage);
        float[] columnWidths = {10f, 18f, 18f, 18f, 18f, 18f};
        table.setSpacingBefore(0f);
        table.setSpacingAfter(0f);

        table.setWidths(columnWidths);

        String[] headerName = new String[] {"No.", "Actual Hz", "Expected Hz", "% Difference", "Allowable Difference (%)", "Result"};

        for (int i = 0; i < headerName.length; i++) {
            cell = new PdfPCell();
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            cell.setBorderColor(BaseColor.BLACK);
            cell.setBackgroundColor(new BaseColor(0x66, 0x66, 0x66));
            cell.setPadding(5);
            cell.setPaddingTop(0);
            paragraph = new Paragraph(headerName[i], headerFont);
            paragraph.setAlignment(Element.ALIGN_CENTER);
            cell.addElement(paragraph);
            table.addCell(cell);
        }

        document.add(table);

        // Content
        table = new PdfPTable(6);
        table.setWidthPercentage(tablePercentage);
        table.setSpacingBefore(0f);
        table.setSpacingAfter(0f);

        table.setWidths(columnWidths);

        double difference = ((actualHz - 150f) / 150f) * 100f;
        for (int i = 0; i < headerName.length; i++) {
            cell = new PdfPCell();
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            cell.setBorderColor(BaseColor.BLACK);
            cell.setPadding(5);
            cell.setPaddingTop(0);

            if (i == 0) {
                paragraph = new Paragraph("4.", contentFont);
                paragraph.setAlignment(Element.ALIGN_CENTER);
                cell.addElement(paragraph);
            }
            else if (i == 1) {
                paragraph = new Paragraph(String.format("%.6f", actualHz), contentFont);
                paragraph.setAlignment(Element.ALIGN_CENTER);
                cell.addElement(paragraph);
            }
            else if (i == 2) {
                paragraph = new Paragraph("150", contentFont);
                paragraph.setAlignment(Element.ALIGN_CENTER);
                cell.addElement(paragraph);
            }
            else if (i == 3) {
                paragraph = new Paragraph(String.format("%.6f", difference), contentFont);
                paragraph.setAlignment(Element.ALIGN_CENTER);
                cell.addElement(paragraph);
            }
            else if (i == 4) {
                paragraph = new Paragraph("±1%", contentFont);
                paragraph.setAlignment(Element.ALIGN_CENTER);
                cell.addElement(paragraph);
            }
            else {
                if (Math.abs(difference) < 1)
                    paragraph = new Paragraph("OK", contentFont);
                else
                    paragraph = new Paragraph("NOT OK", contentFont);

                paragraph.setAlignment(Element.ALIGN_CENTER);
                cell.addElement(paragraph);
            }

            table.addCell(cell);
        }

        document.add(table);
    }

    public static void addCorrectedAmplitudeCalibration(Document document, double actualg) throws Exception {
        Font titleFont = FontFactory.getFont(FontFactory.HELVETICA, 12, Font.NORMAL, BaseColor.WHITE);
        Font unitFont = FontFactory.getFont(FontFactory.HELVETICA, 10, Font.NORMAL, BaseColor.WHITE);
        Font headerFont = FontFactory.getFont(FontFactory.HELVETICA, 10, Font.NORMAL, BaseColor.WHITE);
        Font contentFont = FontFactory.getFont(FontFactory.HELVETICA, 10, Font.NORMAL, BaseColor.BLACK);

        int tablePercentage = 80;

        PdfPTable table = new PdfPTable(2); // 2 columns.
        table.setWidthPercentage(tablePercentage);
        table.setSpacingBefore(0f);
        table.setSpacingAfter(0f);

        float[] headerColumnWidths = {1f, 1f};
        table.setWidths(headerColumnWidths);

        PdfPCell cell;
        Paragraph paragraph;

        // Title
        cell = new PdfPCell();
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setBorderColor(BaseColor.BLACK);
        cell.setPaddingBottom(6);
        cell.setPaddingLeft(10);
        cell.setPaddingTop(0);
        cell.setBackgroundColor(BaseColor.BLACK);
        paragraph = new Paragraph("Corrected Amplitude Calibration", titleFont);
        paragraph.setAlignment(Element.ALIGN_LEFT);
        cell.addElement(paragraph);
        table.addCell(cell);

        cell = new PdfPCell();
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setBorderColor(BaseColor.BLACK);
        cell.setPaddingBottom(5);
        cell.setPaddingRight(10);
        cell.setPaddingTop(0);
        cell.setBackgroundColor(BaseColor.BLACK);
        paragraph = new Paragraph("Unit: g pk", unitFont);
        paragraph.setAlignment(Element.ALIGN_RIGHT);
        cell.addElement(paragraph);
        table.addCell(cell);

        document.add(table);

        // Header
        table = new PdfPTable(6);
        table.setWidthPercentage(tablePercentage);
        float[] columnWidths = {10f, 18f, 18f, 18f, 18f, 18f};
        table.setSpacingBefore(0f);
        table.setSpacingAfter(0f);

        table.setWidths(columnWidths);

        String[] headerName = new String[] {"No.", "Actual g", "Expected g", "% Difference", "Allowable Difference (%)", "Result"};

        for (int i = 0; i < headerName.length; i++) {
            cell = new PdfPCell();
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            cell.setBorderColor(BaseColor.BLACK);
            cell.setBackgroundColor(new BaseColor(0x66, 0x66, 0x66));
            cell.setPadding(5);
            cell.setPaddingTop(0);
            paragraph = new Paragraph(headerName[i], headerFont);
            paragraph.setAlignment(Element.ALIGN_CENTER);
            cell.addElement(paragraph);
            table.addCell(cell);
        }

        document.add(table);

        // Content
        table = new PdfPTable(6);
        table.setWidthPercentage(tablePercentage);
        table.setSpacingBefore(0f);
        table.setSpacingAfter(0f);

        table.setWidths(columnWidths);

        double difference = (actualg - 1f) / 1f * 100f;

        for (int i = 0; i < headerName.length; i++) {
            cell = new PdfPCell();
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            cell.setBorderColor(BaseColor.BLACK);
            cell.setPadding(5);
            cell.setPaddingTop(0);

            if (i == 0) {
                paragraph = new Paragraph("4.", contentFont);
                paragraph.setAlignment(Element.ALIGN_CENTER);
                cell.addElement(paragraph);
            }
            else if (i == 1) {
                paragraph = new Paragraph(String.format("%.6f", actualg), contentFont);
                paragraph.setAlignment(Element.ALIGN_CENTER);
                cell.addElement(paragraph);
            }
            else if (i == 2) {
                paragraph = new Paragraph("1", contentFont);
                paragraph.setAlignment(Element.ALIGN_CENTER);
                cell.addElement(paragraph);
            }
            else if (i == 3) {
                paragraph = new Paragraph(String.format("%.6f", difference), contentFont);
                paragraph.setAlignment(Element.ALIGN_CENTER);
                cell.addElement(paragraph);
            }
            else if (i == 4) {
                paragraph = new Paragraph("±1%", contentFont);
                paragraph.setAlignment(Element.ALIGN_CENTER);
                cell.addElement(paragraph);
            }
            else {
                if (Math.abs(difference) < 1)
                    paragraph = new Paragraph("OK", contentFont);
                else
                    paragraph = new Paragraph("NOT OK", contentFont);

                paragraph.setAlignment(Element.ALIGN_CENTER);
                cell.addElement(paragraph);
            }

            table.addCell(cell);
        }

        document.add(table);
    }

    public static void addPdfFooter(Document document) throws Exception {
        Font titleFont = FontFactory.getFont(FontFactory.HELVETICA, 10, Font.NORMAL, BaseColor.BLACK);
        Font contentFont = FontFactory.getFont(FontFactory.HELVETICA, 10, Font.BOLD, BaseColor.BLACK);

        PdfPTable table = new PdfPTable(2); // 2 columns.
        table.setWidthPercentage(100);

        float[] headerColumnWidths = {4.5f, 5.5f};
        table.setWidths(headerColumnWidths);

        float[] columnWidths = {1f, 1f};
        PdfPCell cell;
        cell = new PdfPCell();

        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(Element.ALIGN_TOP);
        cell.setBorderColor(BaseColor.WHITE);
        cell.setPaddingTop(10);
        table.addCell(cell);

        cell = new PdfPCell();
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(Element.ALIGN_TOP);
        cell.setBorderColor(BaseColor.WHITE);

        PdfPTable infoTable;
        PdfPCell infoCell;

        String[] labelName = new String[] {"Calibrated By :", "Certificate # :", "Uncertainty :"};
        String[] labelContent = new String[] {" ____________", " ____________", " 95% Confidence"};

        for (int i = 0; i < labelName.length; i++) {
            infoTable = new PdfPTable(2); // 2 columns.
            infoTable.setWidthPercentage(100);
            infoTable.setWidths(columnWidths);
            infoTable.setSpacingAfter(0);
            infoTable.setSpacingBefore(0);

            infoCell = new PdfPCell();
            Paragraph paragraph = new Paragraph(labelName[i], titleFont);
            paragraph.setAlignment(Element.ALIGN_RIGHT);
            infoCell.addElement(paragraph);
            infoCell.setBorderColor(BaseColor.WHITE);
            infoCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
            infoCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            infoCell.setPadding(0);
            infoCell.setFixedHeight(15);
            infoTable.addCell(infoCell);

            infoCell = new PdfPCell();
            infoCell.addElement(new Paragraph(labelContent[i], contentFont));
            infoCell.setBorderColor(BaseColor.WHITE);
            infoCell.setHorizontalAlignment(Element.ALIGN_LEFT);
            infoCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
            infoCell.setPadding(0);
            infoCell.setFixedHeight(15);
            infoTable.addCell(infoCell);

            cell.addElement(infoTable);
        }

        Paragraph paragraph = new Paragraph();
        paragraph.setSpacingAfter(10);
        paragraph.setSpacingBefore(10);
        paragraph.setAlignment(Element.ALIGN_CENTER);
        cell.addElement(paragraph);

        infoTable = new PdfPTable(1);
        infoTable.setWidthPercentage(100);
        infoTable.setWidths(new float[] {1f});
        infoTable.setSpacingAfter(0);
        infoTable.setSpacingBefore(0);

        infoCell = new PdfPCell();
        paragraph = new Paragraph("©Infinite Uptime, INC 2016", titleFont);
        paragraph.setAlignment(Element.ALIGN_RIGHT);
        infoCell.addElement(paragraph);
        infoCell.setBorderColor(BaseColor.WHITE);
        infoCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        infoCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        infoCell.setPadding(0);
        infoCell.setPaddingRight(40);
        infoCell.setFixedHeight(15);
        infoTable.addCell(infoCell);
        cell.addElement(infoTable);

        infoTable = new PdfPTable(1);
        infoTable.setWidthPercentage(100);
        infoTable.setWidths(new float[] {1f});
        infoTable.setSpacingAfter(0);
        infoTable.setSpacingBefore(0);

        infoCell = new PdfPCell();
        paragraph = new Paragraph("Refer to infinite-uptime.com/product/throughput", titleFont);
        paragraph.setAlignment(Element.ALIGN_RIGHT);
        infoCell.addElement(paragraph);
        infoCell.setBorderColor(BaseColor.WHITE);
        infoCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        infoCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        infoCell.setPadding(0);
        infoCell.setPaddingRight(30);
        infoCell.setFixedHeight(15);
        infoTable.addCell(infoCell);
        cell.addElement(infoTable);

        table.addCell(cell);

        document.add(table);
    }
}
