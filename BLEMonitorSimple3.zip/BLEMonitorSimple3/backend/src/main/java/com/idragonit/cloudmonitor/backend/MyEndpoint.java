/*
   For step-by-step instructions on connecting your Android application to this backend module,
   see "App Engine Java Endpoints Module" template documentation at
   https://github.com/GoogleCloudPlatform/gradle-appengine-templates/tree/master/HelloEndpoints
*/

package com.idragonit.cloudmonitor.backend;

import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiNamespace;
import com.google.api.services.bigquery.Bigquery;
import com.google.api.services.bigquery.model.GetQueryResultsResponse;
import com.google.api.services.bigquery.model.QueryRequest;
import com.google.api.services.bigquery.model.QueryResponse;
import com.google.api.services.bigquery.model.TableCell;
import com.google.api.services.bigquery.model.TableDataInsertAllRequest;
import com.google.api.services.bigquery.model.TableRow;
import com.google.appengine.api.utils.SystemProperty;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.TimeZone;

import javax.inject.Named;

/** An endpoint class we are exposing */
@Api(
  name = "myApi",
  version = "v1",
  namespace = @ApiNamespace(
    ownerDomain = "backend.cloudmonitor.idragonit.com",
    ownerName = "backend.cloudmonitor.idragonit.com",
    packagePath=""
  )
)

public class MyEndpoint {
    public String database_url = "jdbc:google:mysql://infinite-uptime-1232:server0/InfiniteUptime?user=root";
    public String database_information_url = "jdbc:google:mysql://infinite-uptime-1232:server0/Hub_Dictionary?user=root";
    public String database_url_format = "jdbc:google:mysql://infinite-uptime-1232:%s/%s?user=%s";
    public String database_calibration_url = "jdbc:google:mysql://infinite-uptime-1232:server0/calibration_data?user=root";

    public String instanceUrl = "jdbc:google:mysql://infinite-uptime-1232:server0?user=root";
    public String bleMonitorDBName = "infinite_uptime";

    public static final String gProjectID = "infinite-uptime-1232";

    @ApiMethod(name = "getDBNameList") // BLESimpleMonitor3 (infinite_uptime)
    public final DatabaseName getDBNameList() throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = instanceUrl;
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(database_information_url);
        PreparedStatement stmt = conn.prepareStatement("SELECT Database_Name FROM Hub_Mapping");
        ResultSet rs =  stmt.executeQuery();
        DatabaseName info = new DatabaseName();

        ArrayList<String> nameList = new ArrayList<>();

        while (rs.next()) {
            nameList.add(rs.getString(1));
        }

        conn.close();

        info.setDbNameList(nameList);

        return info;
    }


    @ApiMethod(name = "getThresholdData") // BLESimpleMonitor3
    public final IUDeviceData getThresholdData(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username,
                                               @Named("address") String address) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            //url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
            url = String.format(database_url_format, server, dbname, username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);

        String query = "SELECT Feature_ID, Threshold_1, Threshold_2, Threshold_3 FROM Feature_Dictionary WHERE MAC_ADDRESS = ?";
        PreparedStatement stmt1 = conn.prepareStatement(query);
        stmt1.setString(1, address);

        ResultSet rs =  stmt1.executeQuery();

        int[] threshold1 = new int[6];
        int[] threshold2 = new int[6];
        int[] threshold3 = new int[6];

        boolean isResult = false;

        while (rs.next()) {
            isResult = true;
            int feature = rs.getInt(1);
            threshold1[feature] = rs.getInt(2);
            threshold2[feature] = rs.getInt(3);
            threshold3[feature] = rs.getInt(4);
        }

        if (!isResult)
            return null;

        IUDeviceData data = new IUDeviceData();

        data.setThreshold1(threshold1);
        data.setThreshold2(threshold2);
        data.setThreshold3(threshold3);

        return data;
    }

    @ApiMethod(name = "getMachineName") // BLESimpleMonitor3
    public final MachineNameData getMachineName(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username,
                                                @Named("address") String address) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            //url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
            url = String.format(database_url_format, server, dbname, username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);

        String query = "SELECT Machine_Name FROM Feature_Dictionary WHERE MAC_ADDRESS = ?";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setString(1, address);
        ResultSet rs =  stmt.executeQuery();

        MachineNameData data = new MachineNameData();

        if (rs.next()) {
            data.setMachine(rs.getString(1));
        }
        else {
            stmt = conn.prepareStatement("Insert Into Feature_Dictionary (MAC_ADDRESS, Tool_ID, Tool_Status, Feature_ID, Feature_Name, Threshold_1, Threshold_2, Threshold_3, Device_Status, Machine_Name) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);");

            stmt.setString(1, address);
            stmt.setInt(2, 1);
            stmt.setInt(3, 1);
            stmt.setInt(4, 0);
            stmt.setString(5, "Signal Energy");
            stmt.setInt(6, 30);
            stmt.setInt(7, 600);
            stmt.setInt(8, 1200);
            stmt.setInt(9, 1);
            stmt.setString(10, address);

            stmt.executeUpdate();

            stmt = conn.prepareStatement("Insert Into Feature_Dictionary (MAC_ADDRESS, Tool_ID, Tool_Status, Feature_ID, Feature_Name, Threshold_1, Threshold_2, Threshold_3, Device_Status, Machine_Name) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);");

            stmt.setString(1, address);
            stmt.setInt(2, 1);
            stmt.setInt(3, 1);
            stmt.setInt(4, 1);
            stmt.setString(5, "Mean Crossing Rate");
            stmt.setInt(6, 100);
            stmt.setInt(7, 500);
            stmt.setInt(8, 1000);
            stmt.setInt(9, 1);
            stmt.setString(10, address);

            stmt.executeUpdate();

            stmt = conn.prepareStatement("Insert Into Feature_Dictionary (MAC_ADDRESS, Tool_ID, Tool_Status, Feature_ID, Feature_Name, Threshold_1, Threshold_2, Threshold_3, Device_Status, Machine_Name) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);");

            stmt.setString(1, address);
            stmt.setInt(2, 1);
            stmt.setInt(3, 1);
            stmt.setInt(4, 2);
            stmt.setString(5, "Spectral Centroid");
            stmt.setInt(6, 6);
            stmt.setInt(7, 7);
            stmt.setInt(8, 8);
            stmt.setInt(9, 1);
            stmt.setString(10, address);

            stmt.executeUpdate();

            stmt = conn.prepareStatement("Insert Into Feature_Dictionary (MAC_ADDRESS, Tool_ID, Tool_Status, Feature_ID, Feature_Name, Threshold_1, Threshold_2, Threshold_3, Device_Status, Machine_Name) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);");

            stmt.setString(1, address);
            stmt.setInt(2, 1);
            stmt.setInt(3, 1);
            stmt.setInt(4, 3);
            stmt.setString(5, "Spectral Flatness");
            stmt.setInt(6, 40);
            stmt.setInt(7, 42);
            stmt.setInt(8, 45);
            stmt.setInt(9, 1);
            stmt.setString(10, address);

            stmt.executeUpdate();

            stmt = conn.prepareStatement("Insert Into Feature_Dictionary (MAC_ADDRESS, Tool_ID, Tool_Status, Feature_ID, Feature_Name, Threshold_1, Threshold_2, Threshold_3, Device_Status, Machine_Name) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);");

            stmt.setString(1, address);
            stmt.setInt(2, 1);
            stmt.setInt(3, 1);
            stmt.setInt(4, 4);
            stmt.setString(5, "Accel Spectral Spread");
            stmt.setInt(6, 200);
            stmt.setInt(7, 205);
            stmt.setInt(8, 210);
            stmt.setInt(9, 1);
            stmt.setString(10, address);

            stmt.executeUpdate();

            stmt = conn.prepareStatement("Insert Into Feature_Dictionary (MAC_ADDRESS, Tool_ID, Tool_Status, Feature_ID, Feature_Name, Threshold_1, Threshold_2, Threshold_3, Device_Status, Machine_Name) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);");

            stmt.setString(1, address);
            stmt.setInt(2, 1);
            stmt.setInt(3, 1);
            stmt.setInt(4, 5);
            stmt.setString(5, "Audio Spectral Spread");
            stmt.setInt(6, 500);
            stmt.setInt(7, 1000);
            stmt.setInt(8, 1500);
            stmt.setInt(9, 1);
            stmt.setString(10, address);

            stmt.executeUpdate();

            data.setMachine(address);
        }

        return data;
    }

    @ApiMethod(name = "createDBByDeviceID") // BLESimpleMonitor3 BigQuery
    public final DatabaseInfo createDBByDeviceID(@Named("deviceID") String deviceID, @Named("dbName") String dbName, @Named("userName") String userName, @Named("password") String password) throws SQLException, ClassNotFoundException, IOException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            Connection conn = DriverManager.getConnection(instanceUrl);
            PreparedStatement stmt = conn.prepareStatement("CREATE DATABASE IF NOT EXISTS " + dbName);
            stmt.execute();

            conn.close();
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(database_information_url);
        PreparedStatement stmt = conn.prepareStatement("Insert Into Hub_Mapping (Hub_ID, Database_Name) VALUES (?, ?);");
        stmt.setString(1, deviceID);
        stmt.setString(2, dbName);

        stmt.executeUpdate();

        conn.close();

        conn = DriverManager.getConnection(database_url);
        stmt = conn.prepareStatement("Insert Into UserInformation (user_name, password, dbname) VALUES (?, ?, ?);");

        stmt.setString(1, userName);
        stmt.setString(2, password);
        stmt.setString(3, dbName);

        stmt.executeUpdate();

        conn.close();

        url = String.format(database_url_format, "server0", dbName, "root");
        conn = DriverManager.getConnection(url);

        conn.createStatement().executeUpdate("CREATE TABLE IF NOT EXISTS Feature_Dictionary ( " +
                "MAC_ADDRESS varchar(255) DEFAULT NULL, " +
                "Tool_ID int(11) DEFAULT 1, " +
                "Tool_Status int(11) DEFAULT 1, " +
                "Tool_Name varchar(45) DEFAULT NULL, " +
                "Feature_ID int(11) DEFAULT NULL, " +
                "Feature_Name varchar(255) DEFAULT NULL, " +
                "Threshold_1 float DEFAULT NULL, " +
                "Threshold_2 float DEFAULT NULL, " +
                "Threshold_3 float DEFAULT NULL, " +
                "Device_Status int(11) DEFAULT NULL, " +
                "Machine_Name varchar(255) DEFAULT NULL)");

        conn.createStatement().executeUpdate("CREATE TABLE Env_variables (reset_value int(11) DEFAULT NULL)");

        conn.close();

        BigQueryManager.createDataset(dbName);

        DatabaseInfo info = new DatabaseInfo();

        info.setDbName(dbName);

        return info;
    }

    @ApiMethod(name = "createTempDBByDeviceID") // BLESimpleMonitor3 BigQuery
    public final DatabaseInfo createTempDBByDeviceID(@Named("dbName") String dbName) throws SQLException, ClassNotFoundException, IOException {
        BigQueryManager.createDataset(dbName);

        DatabaseInfo info = new DatabaseInfo();

        info.setDbName(dbName);

        return info;
    }

    @ApiMethod(name = "addIUDataMultiRow") // BLESimpleMonitor3 BigQuery
    public final void addIUDataMultiRow(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username,
                                   @Named("macAddress") String macAddress, @Named("toolID") Integer toolID, @Named("multiData") String multiData) throws SQLException, ClassNotFoundException, IOException {
        Bigquery bigquery = BigQueryManager.createAuthorizedClient();
        long lastId = System.currentTimeMillis();

        String[] dataList = multiData.split(";");
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
        format.setTimeZone(TimeZone.getTimeZone("gmt"));
        long[] timestamplist = new long[dataList.length];

        for (int i = 0; i < dataList.length; i++) {
            String data = dataList[i];
            String[] msg = data.split(",");
            String stime = msg[15].substring(0, 10) + msg[15].substring(11, 13) + "0";

            timestamplist[i] = Long.valueOf(stime);
        }

        long lastTimestamp = 0;
        String lastTimestamp_Pi = "";
        int lastStatus = 0;
        long id = -1;

        String sQuery = String.format("SELECT Id, Timestamp_Pi, Timestamp, State FROM [infinite-uptime-1232:%s.IU_device_data] WHERE MAC_ADDRESS = '%s' ORDER BY Id DESC LIMIT 1", dbname, macAddress);
        QueryResponse query = bigquery.jobs().query(gProjectID, new QueryRequest().setQuery(sQuery)).execute();
        GetQueryResultsResponse queryResult = bigquery.jobs().getQueryResults(query.getJobReference().getProjectId(), query.getJobReference().getJobId()).execute();
        List<TableRow> rows = queryResult.getRows();
        TableRow tableRow;

        if (rows != null) {
            for (TableRow row : rows) {
                List<TableCell> fields = row.getF();
                id = Long.valueOf((String) fields.get(0).getV());
                lastTimestamp_Pi = (String) fields.get(1).getV();
                lastTimestamp = Long.valueOf((String) fields.get(2).getV());
                lastStatus = Integer.valueOf((String) fields.get(3).getV());
            }
        }

        if (id != -1) {
            long duration = timestamplist[0] - lastTimestamp;

            if (duration < 0)
                duration = 0;

            tableRow = new TableRow();
            tableRow.set("Id", id);
            tableRow.set("Timestamp_Pi", lastTimestamp_Pi);
            tableRow.set("Row_Duration", duration);
            tableRow.set("MAC_ADDRESS", macAddress);
            tableRow.set("Tool_ID", toolID);
            tableRow.set("State", lastStatus);

            TableDataInsertAllRequest.Rows row = new TableDataInsertAllRequest.Rows();
            row.setInsertId(String.valueOf(id));
            row.setJson(tableRow);

            TableDataInsertAllRequest request = new TableDataInsertAllRequest();
            request.setRows(Arrays.asList(row));
            bigquery.tabledata().insertAll(MyEndpoint.gProjectID, dbname, "IU_device_duration_data", request).execute();
        }

        List<TableDataInsertAllRequest.Rows> rowList = new ArrayList<>();
        List<TableDataInsertAllRequest.Rows> durationRowList = new ArrayList<>();

        for (int i = 0; i < dataList.length; i++) {
            String data = dataList[i];
            String[] msg = data.split(",");
            Date date = new Date();
            date.setTime(timestamplist[i]);
            String time = format.format(date);

            int status = 0;

            if (msg[1].contains("00")) {
                status = 0;
            } else if (msg[1].contains("01")) {
                status = 1;
            } else if (msg[1].contains("02")) {
                status = 2;
            } else if (msg[1].contains("03")) {
                status = 3;
            }

            String batteryLevel = msg[2];
            int battery = Integer.valueOf(batteryLevel);

            float featureValue[] = new float[6];
            int index = 0;
            for (int j = 4; j < 15; j += 2) {
                featureValue[index] = Float.valueOf(msg[j]);
                index++;
            }

            if (i < dataList.length - 1) {
                long duration = timestamplist[i + 1] - timestamplist[i];

                if (duration < 0)
                    duration = 0;

                tableRow = new TableRow();
                tableRow.set("Id", lastId);
                tableRow.set("Timestamp_Pi", time);
                tableRow.set("Row_Duration", duration);
                tableRow.set("MAC_ADDRESS", macAddress);
                tableRow.set("Tool_ID", toolID);
                tableRow.set("State", status);

                TableDataInsertAllRequest.Rows row = new TableDataInsertAllRequest.Rows();
                row.setInsertId(String.valueOf(lastId));
                row.setJson(tableRow);
                durationRowList.add(row);
            }

            tableRow = new TableRow();
            tableRow.set("Id", lastId);
            tableRow.set("Timestamp_Pi", time);
            tableRow.set("Timestamp", timestamplist[i]);
            tableRow.set("MAC_ADDRESS", macAddress);
            tableRow.set("Tool_ID", toolID);
            tableRow.set("State", status);
            tableRow.set("Battery_Level", (float) battery);
            tableRow.set("Feature_Value_0", featureValue[0]);
            tableRow.set("Feature_Value_1", featureValue[1]);
            tableRow.set("Feature_Value_2", featureValue[2]);
            tableRow.set("Feature_Value_3", featureValue[3]);
            tableRow.set("Feature_Value_4", featureValue[4]);
            tableRow.set("Feature_Value_5", featureValue[5]);

            TableDataInsertAllRequest.Rows row = new TableDataInsertAllRequest.Rows();
            row.setInsertId(String.valueOf(lastId));
            row.setJson(tableRow);
            rowList.add(row);

            lastId++;
        }

        TableDataInsertAllRequest request = new TableDataInsertAllRequest();
        request.setRows(rowList);
        bigquery.tabledata().insertAll(MyEndpoint.gProjectID, dbname, "IU_device_data", request).execute();

        if (durationRowList.size() > 0) {
            request = new TableDataInsertAllRequest();
            request.setRows(durationRowList);
            bigquery.tabledata().insertAll(MyEndpoint.gProjectID, dbname, "IU_device_duration_data", request).execute();
        }
    }

    @ApiMethod(name = "addFeatureRow") // BLESimpleMonitor3 SQL
    public final void addFeatureRow(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username,
                                    @Named("macAddress") String macAddress, @Named("toolID") Integer toolID, @Named("toolStatus") Integer toolStatus,
                                    @Named("featureId") Integer featureId, @Named("featureName") String featureName,
                                    @Named("threshold1") Integer threshold1, @Named("threshold2") Integer threshold2, @Named("threshold3") Integer threshold3,
                                    @Named("deviceStatus") Integer deviceStatus, @Named("machineName") String machineName) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            //url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
            url = String.format(database_url_format, server, dbname, username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);

        PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Feature_Dictionary WHERE MAC_ADDRESS = ? and Feature_ID = ? and Tool_ID = ?");
        stmt.setString(1, macAddress);
        stmt.setInt(2, featureId);
        stmt.setInt(3, toolID);

        ResultSet rs =  stmt.executeQuery();

        if (rs.next()) {
            conn.close();
            return;
        }

        stmt = conn.prepareStatement("Insert Into Feature_Dictionary (MAC_ADDRESS, Tool_ID, Tool_Status, Feature_ID, Feature_Name, Threshold_1, Threshold_2, Threshold_3, Device_Status, Machine_Name) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);");

        stmt.setString(1, macAddress);
        stmt.setInt(2, toolID);
        stmt.setInt(3, toolStatus);
        stmt.setInt(4, featureId);
        stmt.setString(5, featureName);
        stmt.setInt(6, threshold1);
        stmt.setInt(7, threshold2);
        stmt.setInt(8, threshold3);
        stmt.setInt(9, deviceStatus);
        stmt.setString(10, machineName);

        stmt.executeUpdate();
        conn.close();
    }

    @ApiMethod(name = "setMachineNameByDevice") //BLEMonitorSimple
    public final void setMachineNameByDevice(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username,
                                             @Named("macAddress") String macAddress, @Named("machineName") String machineName) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            //url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
            url = String.format(database_url_format, server, dbname, username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);
        PreparedStatement stmt = conn.prepareStatement("Update Feature_Dictionary SET MAC_ADDRESS = ?, Machine_Name = ? WHERE MAC_ADDRESS = ?;");

        stmt.setString(1, macAddress);
        stmt.setString(2, machineName);
        stmt.setString(3, macAddress);

        stmt.executeUpdate();
        conn.close();
    }

    @ApiMethod(name = "setThresholdDataByDevice") //BLEMonitorSimple
    public final void setThresholdDataByDevice(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username,
                                               @Named("macAddress") String macAddress, @Named("featureId") Integer featureId, @Named("featureIndex") Integer featureIndex,
                                               @Named("featureValue") Integer featureValue) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            //url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
            url = String.format(database_url_format, server, dbname, username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);
        PreparedStatement stmt = conn.prepareStatement("Update Feature_Dictionary SET MAC_ADDRESS = ?, Feature_ID = ?, Threshold_" + featureIndex + " = ? WHERE MAC_ADDRESS = ? AND Feature_ID = ?;");

        stmt.setString(1, macAddress);
        stmt.setInt(2, featureId);
        stmt.setInt(3, featureValue);
        stmt.setString(4, macAddress);
        stmt.setInt(5, featureId);

        stmt.executeUpdate();
        conn.close();
    }

    @ApiMethod(name = "getWholeMacAddressList")
    public final ArrayList<MacAddressInfo> getWholeMacAddressList(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);
        PreparedStatement stmt = conn.prepareStatement("SELECT MAC_ADDRESS, Device_Status, Machine_Name FROM Feature_Dictionary GROUP BY MAC_ADDRESS");
        ResultSet rs =  stmt.executeQuery();

        ArrayList<MacAddressInfo> listMacAddress = new ArrayList<MacAddressInfo>();

        while (rs.next()) {
            MacAddressInfo address = new MacAddressInfo();

            address.setMacAddress(rs.getString(1));
            address.setStatus(rs.getInt(2));
            address.setMachineName(rs.getString(3));

            listMacAddress.add(address);
        }

        conn.close();

        return listMacAddress;
    }

    @ApiMethod(name = "userLogin")
    public final UserInfo userLogin(@Named("userName") String userName, @Named("password") String password) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = database_url;
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);
        PreparedStatement stmt = conn.prepareStatement("SELECT * FROM UserInformation WHERE user_name = ? and password = ?");
        stmt.setString(1, userName);
        stmt.setString(2, password);

        ResultSet rs =  stmt.executeQuery();
        UserInfo userInfo = new UserInfo();

        if (rs.next()) {
            userInfo.setUserName(rs.getString(2));
            userInfo.setDbName(Utils.encodeDBName(rs.getString(4)));
        }

        conn.close();

        return userInfo;
    }

    @ApiMethod(name = "getDataListByDB") // BigQuery
    public final List<IUDeviceData> getDataListByDB(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username,
                                                @Named("id") Long id, @Named("address") String address) throws SQLException, ClassNotFoundException, IOException {
        Bigquery bigquery = BigQueryManager.createAuthorizedClient();
        String sQuery = String.format("SELECT Id, Timestamp_Pi, Timestamp, MAC_ADDRESS, Tool_ID, State, Battery_Level, " +
                "Feature_Value_0, Feature_Value_1, Feature_Value_2, Feature_Value_3, Feature_Value_4, Feature_Value_5 " +
                "FROM [infinite-uptime-1232:%s.IU_device_data] WHERE MAC_ADDRESS = '%s' and Id > %d", Utils.decodeDBName(dbname), address, id);
        QueryResponse query = bigquery.jobs().query(gProjectID, new QueryRequest().setQuery(sQuery)).execute();
        GetQueryResultsResponse queryResult = bigquery.jobs().getQueryResults(query.getJobReference().getProjectId(), query.getJobReference().getJobId()).execute();
        List<TableRow> rows = queryResult.getRows();

        List<IUDeviceData> listData = new ArrayList<IUDeviceData>();

        if (rows != null) {
            for (TableRow row : rows) {
                List<TableCell> fields = row.getF();
                IUDeviceData value = new IUDeviceData();

                value.setId(Long.valueOf((String) fields.get(0).getV()));
                value.setTimeStampPi((String) fields.get(1).getV());
                value.setMacAddress((String) fields.get(3).getV());
                value.setState(Integer.valueOf((String) fields.get(5).getV()));
                value.setBatteryLevel(Float.valueOf((String) fields.get(6).getV()));
                value.setFeatureValue0(Float.valueOf((String) fields.get(7).getV()));
                value.setFeatureValue1(Float.valueOf((String) fields.get(8).getV()));
                value.setFeatureValue2(Float.valueOf((String) fields.get(9).getV()));
                value.setFeatureValue3(Float.valueOf((String) fields.get(10).getV()));
                value.setFeatureValue4(Float.valueOf((String) fields.get(11).getV()));
                value.setFeatureValue5(Float.valueOf((String) fields.get(12).getV()));

                listData.add(value);
            }
        }

        return listData;
    }

    @ApiMethod(name = "getDataListLast25")
    public final List<IUDeviceData> getDataListLast25(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username,
                                                    @Named("address") String address) throws SQLException, ClassNotFoundException, IOException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);

        String fQuery = "SELECT MAC_ADDRESS, Feature_ID, Feature_Name, Threshold_1, Threshold_2, Threshold_3, Device_Status, Machine_Name FROM Feature_Dictionary WHERE MAC_ADDRESS = ?";
        PreparedStatement stmt1 = conn.prepareStatement(fQuery);
        stmt1.setString(1, address);
        ResultSet rs1 =  stmt1.executeQuery();
        int[] threshold1 = new int[6];
        int[] threshold2 = new int[6];
        int[] threshold3 = new int[6];

        while (rs1.next()) {
            int feature = rs1.getInt(2);
            threshold1[feature] = rs1.getInt(4);
            threshold2[feature] = rs1.getInt(5);
            threshold3[feature] = rs1.getInt(6);
        }

        conn.close();

        Bigquery bigquery = BigQueryManager.createAuthorizedClient();
        String sQuery = String.format("SELECT Id, Timestamp_Pi, Timestamp, MAC_ADDRESS, Tool_ID, State, Battery_Level, " +
                "Feature_Value_0, Feature_Value_1, Feature_Value_2, Feature_Value_3, Feature_Value_4, Feature_Value_5 " +
                "FROM [infinite-uptime-1232:%s.IU_device_data] WHERE MAC_ADDRESS = '%s' ORDER BY Timestamp_Pi DESC LIMIT 25", Utils.decodeDBName(dbname), address);
        QueryResponse query = bigquery.jobs().query(gProjectID, new QueryRequest().setQuery(sQuery)).execute();
        GetQueryResultsResponse queryResult = bigquery.jobs().getQueryResults(query.getJobReference().getProjectId(), query.getJobReference().getJobId()).execute();
        List<TableRow> rows = queryResult.getRows();

        List<IUDeviceData> listData = new ArrayList<IUDeviceData>();

        if (rows != null) {
            for (TableRow row : rows) {
                List<TableCell> fields = row.getF();
                IUDeviceData value = new IUDeviceData();

                value.setId(Long.valueOf((String) fields.get(0).getV()));
                value.setTimeStampPi((String) fields.get(1).getV());
                value.setMacAddress((String) fields.get(3).getV());
                value.setState(Integer.valueOf((String) fields.get(5).getV()));
                value.setBatteryLevel(Float.valueOf((String) fields.get(6).getV()));
                value.setFeatureValue0(Float.valueOf((String) fields.get(7).getV()));
                value.setFeatureValue1(Float.valueOf((String) fields.get(8).getV()));
                value.setFeatureValue2(Float.valueOf((String) fields.get(9).getV()));
                value.setFeatureValue3(Float.valueOf((String) fields.get(10).getV()));
                value.setFeatureValue4(Float.valueOf((String) fields.get(11).getV()));
                value.setFeatureValue5(Float.valueOf((String) fields.get(12).getV()));

                value.setThreshold1(threshold1);
                value.setThreshold2(threshold2);
                value.setThreshold3(threshold3);

                listData.add(value);
            }
        }

        return listData;
    }

    @ApiMethod(name = "getIUDataList")
    public final List<IUDeviceDataWeb> getIUDataList(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username,
                                                     @Named("from") String from, @Named("to") String to, @Named("address") String address) throws SQLException, ClassNotFoundException, IOException {
        Bigquery bigquery = BigQueryManager.createAuthorizedClient();
        String sQuery = String.format("SELECT Id, Timestamp_Pi, Timestamp, MAC_ADDRESS, Tool_ID, State, Battery_Level, " +
                "Feature_Value_0, Feature_Value_1, Feature_Value_2, Feature_Value_3, Feature_Value_4, Feature_Value_5 " +
                "FROM [infinite-uptime-1232:%s.IU_device_data] WHERE Id >= 0", Utils.decodeDBName(dbname), address);

        if (address != null && !address.equalsIgnoreCase("all")) {
            sQuery += " AND MAC_ADDRESS = '" + address + "'";
        }

        if (from != null && !from.equalsIgnoreCase("all")) {
            sQuery += " AND Timestamp_Pi >= '" + from + "'";
        }

        if (to != null && !to.equalsIgnoreCase("all")) {
            sQuery += " AND Timestamp_Pi <= '" + to + "'";
        }

        QueryResponse query = bigquery.jobs().query(gProjectID, new QueryRequest().setQuery(sQuery)).execute();
        GetQueryResultsResponse queryResult = bigquery.jobs().getQueryResults(query.getJobReference().getProjectId(), query.getJobReference().getJobId()).execute();
        List<TableRow> rows = queryResult.getRows();

        List<IUDeviceDataWeb> listData = new ArrayList<IUDeviceDataWeb>();

        if (rows != null) {
            for (TableRow row : rows) {
                List<TableCell> fields = row.getF();
                IUDeviceDataWeb value = new IUDeviceDataWeb();

                value.setId(Long.valueOf((String) fields.get(0).getV()));
                value.setTimeStampDB((String) fields.get(1).getV());
                value.setTimeStampPi((String) fields.get(1).getV());
                value.setMacAddress((String) fields.get(3).getV());
                value.setState(Integer.valueOf((String) fields.get(5).getV()));
                value.setBatteryLevel(Float.valueOf((String) fields.get(6).getV()));
                value.setFeatureValue0(Float.valueOf((String) fields.get(7).getV()));
                value.setFeatureValue1(Float.valueOf((String) fields.get(8).getV()));
                value.setFeatureValue2(Float.valueOf((String) fields.get(9).getV()));
                value.setFeatureValue3(Float.valueOf((String) fields.get(10).getV()));
                value.setFeatureValue4(Float.valueOf((String) fields.get(11).getV()));
                value.setFeatureValue5(Float.valueOf((String) fields.get(12).getV()));

                listData.add(value);
            }
        }

        return listData;
    }

    @ApiMethod(name = "getFeatureList")
    public final List<FeatureDictionary> getFeatureList(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username, @Named("address") String address, @Named("featureId") Integer featureId) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);

        String query = "SELECT MAC_ADDRESS, Feature_ID, Feature_Name, Threshold_1, Threshold_2, Threshold_3, Device_Status, Machine_Name FROM Feature_Dictionary";
        boolean existsMacAddress = false;

        if (address != null && !address.equalsIgnoreCase("all")) {
            query += " WHERE MAC_ADDRESS = ?";
            existsMacAddress = true;
        }

        if (featureId > 0) {
            if (existsMacAddress)
                query += " and Feature_ID = ?";
            else
                query += " WHERE Feature_ID = ?";
        }

        PreparedStatement stmt = conn.prepareStatement(query);
        int index = 1;

        if (address != null && !address.equalsIgnoreCase("all")) {
            stmt.setString(index, address);
            index++;
        }

        if (featureId > 0) {
            stmt.setInt(index, featureId - 1);
            index++;
        }

        ResultSet rs =  stmt.executeQuery();

        List<FeatureDictionary> listData = new ArrayList<FeatureDictionary>();

        while (rs.next()) {
            FeatureDictionary value = new FeatureDictionary();

            value.setMacAddress(rs.getString(1));
            value.setFeatureID(rs.getInt(2));
            value.setFeatureName(rs.getString(3));
            value.setThreshold1(rs.getInt(4));
            value.setThreshold2(rs.getInt(5));
            value.setThreshold3(rs.getInt(6));
            value.setStatus(rs.getInt(7));
            value.setMachineName(rs.getString(8));

            listData.add(value);
        }

        conn.close();

        return listData;
    }

    @ApiMethod(name = "addFeature")
    public final void addFeature(@Named("macAddress") String macAddress, @Named("featureId") Integer featureId, @Named("featureName") String featureName,
                                 @Named("threshold1") Integer threshold1, @Named("threshold2") Integer threshold2, @Named("threshold3") Integer threshold3) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = database_url;
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);
        PreparedStatement stmt = conn.prepareStatement("Insert Into Feature_Dictionary (MAC_ADDRESS, Feature_ID, Feature_Name, Threshold_1, Threshold_2, Threshold_3) VALUES (?, ?, ?, ?, ?, ?);");

        stmt.setString(1, macAddress);
        stmt.setInt(2, featureId);
        stmt.setString(3, featureName);
        stmt.setInt(4, threshold1);
        stmt.setInt(5, threshold2);
        stmt.setInt(6, threshold3);

        stmt.executeUpdate();
        conn.close();
    }

    @ApiMethod(name = "updateFeature")
    public final void updateFeature(@Named("macAddress") String macAddress, @Named("featureId") Integer featureId, @Named("featureName") String featureName,
                                 @Named("threshold1") Integer threshold1, @Named("threshold2") Integer threshold2, @Named("threshold3") Integer threshold3) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = database_url;
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);
        PreparedStatement stmt = conn.prepareStatement("Update Feature_Dictionary SET MAC_ADDRESS = ?, Feature_ID = ?, Feature_Name = ?, Threshold_1 = ?, Threshold_2 = ?, Threshold_3 = ? WHERE MAC_ADDRESS = ? AND Feature_ID = ?;");

        stmt.setString(1, macAddress);
        stmt.setInt(2, featureId);
        stmt.setString(3, featureName);
        stmt.setInt(4, threshold1);
        stmt.setInt(5, threshold2);
        stmt.setInt(6, threshold3);
        stmt.setString(7, macAddress);
        stmt.setInt(8, featureId);

        stmt.executeUpdate();
        conn.close();
    }

    @ApiMethod(name = "setThresholdData")
    public final void setThresholdData(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username,
                                       @Named("macAddress") String macAddress, @Named("featureId") Integer featureId, @Named("featureIndex") Integer featureIndex,
                                       @Named("featureValue") Integer featureValue) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);
        PreparedStatement stmt = conn.prepareStatement("Update Feature_Dictionary SET MAC_ADDRESS = ?, Feature_ID = ?, Threshold_" + featureIndex + " = ? WHERE MAC_ADDRESS = ? AND Feature_ID = ?;");

        stmt.setString(1, macAddress);
        stmt.setInt(2, featureId);
        stmt.setInt(3, featureValue);
        stmt.setString(4, macAddress);
        stmt.setInt(5, featureId);

        stmt.executeUpdate();
        conn.close();
    }

    @ApiMethod(name = "setMachineName")
    public final void setMachineName(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username,
                                       @Named("macAddress") String macAddress, @Named("machineName") String machineName) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);
        PreparedStatement stmt = conn.prepareStatement("Update Feature_Dictionary SET MAC_ADDRESS = ?, Machine_Name = ? WHERE MAC_ADDRESS = ?;");

        stmt.setString(1, macAddress);
        stmt.setString(2, machineName);
        stmt.setString(3, macAddress);

        stmt.executeUpdate();
        conn.close();
    }
    //httpMethod = "GET"
    @ApiMethod(name = "setMachineToolName")
    public final void setMachineToolName(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username,
                                     @Named("macAddress") String macAddress, @Named("toolID") Integer toolID, @Named("toolName") String toolName) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);
        PreparedStatement stmt = conn.prepareStatement("Update Feature_Dictionary SET Tool_Name = ? WHERE MAC_ADDRESS = ? and Tool_ID = ?;");

        stmt.setString(1, toolName);
        stmt.setString(2, macAddress);
        stmt.setInt(3, toolID);

        stmt.executeUpdate();
        conn.close();
    }

    @ApiMethod(name = "updateFeatureStatus")
    public final void updateFeatureStatus(@Named("macAddress") String macAddress, @Named("status") Integer status) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = database_url;
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);
        PreparedStatement stmt = conn.prepareStatement("Update Feature_Dictionary SET Status = ? WHERE MAC_ADDRESS = ?;");

        stmt.setInt(1, status);
        stmt.setString(2, macAddress);

        stmt.executeUpdate();
        conn.close();
    }

    @ApiMethod(name = "setSync")
    public final void setSync(@Named("resetValue") Integer resetValue) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = database_url;
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);
        PreparedStatement stmt = conn.prepareStatement("Update Env_variables SET reset_value = ?;");

        stmt.setInt(1, resetValue);

        stmt.executeUpdate();
        conn.close();
    }

    @ApiMethod(name = "setSyncByDB")
    public final void setSyncByDB(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username, @Named("resetValue") Integer resetValue) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);
        PreparedStatement stmt = conn.prepareStatement("Update Env_variables SET reset_value = ?;");

        stmt.setInt(1, resetValue);

        stmt.executeUpdate();
        conn.close();
    }

    @ApiMethod(name = "getSyncValue")
    public final SyncValue getSyncValue() throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = database_url;
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);
        PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Env_variables");

        ResultSet rs =  stmt.executeQuery();
        List<IUDeviceDataWeb> listData = new ArrayList<IUDeviceDataWeb>();

        SyncValue value = new SyncValue();

        if (rs.next()) {
            value.setResetValue(rs.getInt(1));
        }

        conn.close();

        return value;
    }

    @ApiMethod(name = "getSyncValueByDB")
    public final SyncValue getSyncValueByDB(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);
        PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Env_variables");

        ResultSet rs =  stmt.executeQuery();
        List<IUDeviceDataWeb> listData = new ArrayList<IUDeviceDataWeb>();

        SyncValue value = new SyncValue();

        if (rs.next()) {
            value.setResetValue(rs.getInt(1));
        }

        conn.close();

        return value;
    }

    @ApiMethod(name = "getDeviceStatusList")
    public final List<DeviceStatus> getDeviceStatusList(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username, @Named("address") String address) throws SQLException, ClassNotFoundException, IOException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);

        String fQuery = "SELECT MAC_ADDRESS, Device_Status, Machine_Name FROM Feature_Dictionary";

        if (address != null && !address.equalsIgnoreCase("all")) {
            fQuery += " WHERE MAC_ADDRESS = ?";
        }

        fQuery += " GROUP BY MAC_ADDRESS";

        PreparedStatement stmt = conn.prepareStatement(fQuery);

        if (address != null && !address.equalsIgnoreCase("all")) {
            stmt.setString(1, address);
        }

        ResultSet rs =  stmt.executeQuery();

        List<DeviceStatus> listData = new ArrayList<DeviceStatus>();

        while (rs.next()) {
            DeviceStatus value = new DeviceStatus();

            value.setMacAddress(rs.getString(1));
            value.setStatus(rs.getInt(2));
            value.setMachineName(rs.getString(3));

            listData.add(value);
        }

        conn.close();

        Bigquery bigquery = BigQueryManager.createAuthorizedClient();

        if (address != null && !address.equalsIgnoreCase("all") && listData.size() == 1) {
            String sQuery = String.format("SELECT Battery_Level FROM [infinite-uptime-1232:%s.IU_device_data] WHERE MAC_ADDRESS = '%s' ORDER BY Id DESC LIMIT %d", Utils.decodeDBName(dbname), address, listData.size());
            QueryResponse query = bigquery.jobs().query(gProjectID, new QueryRequest().setQuery(sQuery)).execute();
            GetQueryResultsResponse queryResult = bigquery.jobs().getQueryResults(query.getJobReference().getProjectId(), query.getJobReference().getJobId()).execute();
            List<TableRow> rows = queryResult.getRows();

            if (rows != null) {
                for (TableRow row : rows) {
                    List<TableCell> fields = row.getF();
                    DeviceStatus value = listData.get(0);
                    value.setBatteryLevel(Float.valueOf((String) fields.get(0).getV()));
                }
            }
        }
        else {
            for (int i = 0; i < listData.size(); i++) {
                DeviceStatus value = listData.get(i);

                String sQuery = String.format("SELECT MAC_ADDRESS, Battery_Level FROM [infinite-uptime-1232:%s.IU_device_data] WHERE MAC_ADDRESS = '%s' ORDER BY Id DESC LIMIT %d", Utils.decodeDBName(dbname), address, listData.size());
                QueryResponse query = bigquery.jobs().query(gProjectID, new QueryRequest().setQuery(sQuery)).execute();
                GetQueryResultsResponse queryResult = bigquery.jobs().getQueryResults(query.getJobReference().getProjectId(), query.getJobReference().getJobId()).execute();
                List<TableRow> rows = queryResult.getRows();

                if (rows != null) {
                    for (TableRow row : rows) {
                        List<TableCell> fields = row.getF();
                        value.setBatteryLevel(Float.valueOf((String) fields.get(0).getV()));
                    }
                }
            }
        }

        return listData;
    }

    @ApiMethod(name = "getProductivityDataList")
    public final List<ProductivityData> getProductivityDataList(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username,
                                                                @Named("from") String from, @Named("to") String to, @Named("address") String address) throws SQLException, ClassNotFoundException, IOException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);

        PreparedStatement stmtMacAddress = conn.prepareStatement("SELECT MAC_ADDRESS, Machine_Name FROM Feature_Dictionary GROUP BY MAC_ADDRESS");
        ResultSet rsMacAddress =  stmtMacAddress.executeQuery();

        ArrayList<String> listMacAddress = new ArrayList<String>();
        ArrayList<String> listMachineName = new ArrayList<String>();

        while (rsMacAddress.next()) {
            listMacAddress.add(rsMacAddress.getString(1));
            listMachineName.add(rsMacAddress.getString(2));
        }

        List<ProductivityData> listData = new ArrayList<ProductivityData>();
        HashMap<String, ProductivityData> mapData = new HashMap<String, ProductivityData>();

        if (address != null && !address.equalsIgnoreCase("all")) {
            ProductivityData data = new ProductivityData();
            data.setMacAddress(address);
            data.setTotalTime(0L);

            mapData.put(address, data);
            listData.add(data);

            for (int i = 0; i < listMacAddress.size(); i++) {
                if (listMacAddress.get(i).contentEquals(address)) {
                    data.setMachineName(listMachineName.get(i));
                    break;
                }
            }
        }
        else {
            for (int i = 0; i < listMacAddress.size(); i++) {
                ProductivityData data = new ProductivityData();
                data.setMacAddress(listMacAddress.get(i));
                data.setMachineName(listMachineName.get(i));
                data.setTotalTime(0L);

                mapData.put(listMacAddress.get(i), data);
                listData.add(data);
            }
        }

        conn.close();

        Bigquery bigquery = BigQueryManager.createAuthorizedClient();

        String sQuery = String.format("SELECT Id, Timestamp_Pi, MAC_ADDRESS, State, Battery_Level, Feature_Value_0, Feature_Value_1, Feature_Value_2, Feature_Value_3, Feature_Value_4, Feature_Value_5 " +
                "FROM [infinite-uptime-1232:%s.IU_device_data] WHERE Id > -1", Utils.decodeDBName(dbname));

        if (address != null && !address.equalsIgnoreCase("all")) {
            sQuery += " and MAC_ADDRESS = '" + address + "'";
        }

        if (from != null && !from.equalsIgnoreCase("all")) {
            sQuery += " and Timestamp_Pi >= '" + from + "'";
        }

        if (to != null && !to.equalsIgnoreCase("all")) {
            sQuery += " and Timestamp_Pi <= '" + to + "'";
        }

        sQuery += " ORDER BY Timestamp_Pi";

        QueryResponse query = bigquery.jobs().query(gProjectID, new QueryRequest().setQuery(sQuery)).execute();
        GetQueryResultsResponse queryResult = bigquery.jobs().getQueryResults(query.getJobReference().getProjectId(), query.getJobReference().getJobId()).execute();
        List<TableRow> rows = queryResult.getRows();

        if (rows != null) {
            for (TableRow row : rows) {
                List<TableCell> fields = row.getF();

                String time = (String) fields.get(1).getV();
                String macAddress = (String) fields.get(2).getV();
                int state = Integer.valueOf((String) fields.get(3).getV());

                long milliseconds = Utils.convertDateToMilliseconds(time);

                if (milliseconds == -1L)
                    continue;

                ProductivityData data = mapData.get(macAddress);

                if (data == null) {
                    continue;
                }

                ProductivityInfo info;

                if (data.getProductivityInfo().size() == 0) {
                    info = new ProductivityInfo();
                    info.setState(state);
                    info.setStartTime(milliseconds);
                    info.setEndTime(milliseconds);

                    info.setStartTimePi(time);
                    info.setEndTimePi(time);

                    data.getProductivityInfo().add(info);
                } else {
                    info = data.getProductivityInfo().get(data.getProductivityInfo().size() - 1);
                    info.setEndTime(milliseconds);
                    info.setEndTimePi(time);

                    if (info.getState() != state) {
                        info = new ProductivityInfo();
                        info.setState(state);
                        info.setStartTime(milliseconds);
                        info.setEndTime(milliseconds);

                        info.setStartTimePi(time);
                        info.setEndTimePi(time);

                        data.getProductivityInfo().add(info);
                    }
                }
            }
        }

        for (int i = 0; i < listData.size(); i++) {
            ProductivityData data = listData.get(i);

            for (int j = 0; j < data.getProductivityInfo().size(); j++) {
                ProductivityInfo info = data.getProductivityInfo().get(j);
                data.setTotalTime(data.getTotalTime() + info.getDuration());
                info.setTimeLabel(Utils.convertTimeToString(info.getDuration()));
            }

            data.setTimeLabel(Utils.convertTimeToString(data.getTotalTime()));
        }

        return listData;
    }

    @ApiMethod(name = "getMonitoringDataList")
    public final List<MonitoringData> getMonitoringDataList(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username,
                                                            @Named("from") String from, @Named("to") String to, @Named("address") String address, @Named("featureId") Integer featureId) throws SQLException, ClassNotFoundException, IOException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);

        String fQuery = "SELECT MAC_ADDRESS, Feature_ID, Feature_Name, Threshold_1, Threshold_2, Threshold_3, Device_Status, Machine_Name FROM Feature_Dictionary";
        boolean existsMacAddress = false;

        if (address != null && !address.equalsIgnoreCase("all")) {
            fQuery += " WHERE MAC_ADDRESS = ?";
            existsMacAddress = true;
        }

        if (featureId > 0) {
            if (existsMacAddress)
                fQuery += " and Feature_ID = ?";
            else
                fQuery += " WHERE Feature_ID = ?";
        }

        PreparedStatement stmt = conn.prepareStatement(fQuery);
        int index = 1;

        if (address != null && !address.equalsIgnoreCase("all")) {
            stmt.setString(index, address);
            index++;
        }

        if (featureId > 0) {
            stmt.setInt(index, featureId - 1);
            index++;
        }

        ResultSet rs =  stmt.executeQuery();

        List<MonitoringData> listData = new ArrayList<MonitoringData>();
        HashMap<String, MonitoringData> mapData = new HashMap<String, MonitoringData>();

        while (rs.next()) {
            MonitoringData data = new MonitoringData();

            data.getFeatureDictionary().setMacAddress(rs.getString(1));
            data.getFeatureDictionary().setFeatureID(rs.getInt(2));
            data.getFeatureDictionary().setFeatureName(rs.getString(3));
            data.getFeatureDictionary().setThreshold1(rs.getInt(4));
            data.getFeatureDictionary().setThreshold2(rs.getInt(5));
            data.getFeatureDictionary().setThreshold3(rs.getInt(6));
            data.getFeatureDictionary().setStatus(rs.getInt(7));
            data.getFeatureDictionary().setMachineName(rs.getString(8));

            listData.add(data);
            mapData.put(data.getFeatureDictionary().getMacAddress() + "_" + data.getFeatureDictionary().getFeatureID(), data);
        }

        Bigquery bigquery = BigQueryManager.createAuthorizedClient();

        String sQuery = String.format("SELECT Id, Timestamp_Pi, MAC_ADDRESS, State, Battery_Level, Feature_Value_0, Feature_Value_1, Feature_Value_2, Feature_Value_3, Feature_Value_4, Feature_Value_5 " +
                "FROM [infinite-uptime-1232:%s.IU_device_data] WHERE Id > -1", Utils.decodeDBName(dbname));

        if (address != null && !address.equalsIgnoreCase("all")) {
            sQuery += " and MAC_ADDRESS = '" + address + "'";
        }

        if (from != null && !from.equalsIgnoreCase("all")) {
            sQuery += " and Timestamp_Pi >= '" + from + "'";
        }

        if (to != null && !to.equalsIgnoreCase("all")) {
            sQuery += " and Timestamp_Pi <= '" + to + "'";
        }

        sQuery += " ORDER BY Timestamp_Pi";

        QueryResponse query = bigquery.jobs().query(gProjectID, new QueryRequest().setQuery(sQuery)).execute();
        GetQueryResultsResponse queryResult = bigquery.jobs().getQueryResults(query.getJobReference().getProjectId(), query.getJobReference().getJobId()).execute();
        List<TableRow> rows = queryResult.getRows();

        if (rows != null) {
            for (TableRow row : rows) {
                List<TableCell> fields = row.getF();

                String time = (String) fields.get(1).getV();
                String macAddress = (String) fields.get(2).getV();
                int state = Integer.valueOf((String) fields.get(3).getV());

                long milliseconds = Utils.convertDateToMilliseconds(time);

                if (milliseconds == -1L)
                    continue;

                for (int i = 0; i < 6; i++) {
                    MonitoringData data = mapData.get(macAddress + "_" + i);

                    if (data == null)
                        continue;

                    FeatureInfo info;
                    Float featureValue = Float.valueOf((String) fields.get(5 + i).getV());

                    if (data.getFeatureInfo().size() == 0) {
                        info = new FeatureInfo();
                        info.setState(state);
                        info.setFeatureValue(featureValue);
                        info.setStartTime(milliseconds);
                        info.setEndTime(milliseconds);

                        info.setStartTimePi(time);
                        info.setEndTimePi(time);

                        data.setMaxValue(info.getFeatureValue());
                        data.setMinValue(info.getFeatureValue());

                        data.addFeatureInfo(info);
                    } else {
                        info = data.getFeatureInfo().get(data.getFeatureInfo().size() - 1);
                        info.setEndTime(milliseconds);
                        info.setEndTimePi(time);

                        if (info.getState() != state || info.getFeatureValue() != featureValue) {
                            info = new FeatureInfo();
                            info.setState(state);
                            info.setFeatureValue(featureValue);
                            info.setStartTime(milliseconds);
                            info.setEndTime(milliseconds);

                            info.setStartTimePi(time);
                            info.setEndTimePi(time);

                            if (data.getMaxValue() < info.getFeatureValue())
                                data.setMaxValue(info.getFeatureValue());

                            if (data.getMinValue() > info.getFeatureValue())
                                data.setMinValue(info.getFeatureValue());

                            data.addFeatureInfo(info);
                        }
                    }
                }
            }
        }

        conn.close();

        for (int i = 0; i < listData.size(); i++) {
            MonitoringData data = listData.get(i);

            long curTime = 0L;
            for (int j = 0; j < data.getFeatureInfo().size(); j++) {
                FeatureInfo info = data.getFeatureInfo().get(j);
                long duration = info.getDuration();
                curTime = curTime + duration;
                info.setTimeLabel(Utils.convertTimeToString(curTime));
            }

            if (data.getMaxValue() < data.getFeatureDictionary().getThreshold1())
                data.setMaxValue(data.getFeatureDictionary().getThreshold1().floatValue());
            if (data.getMinValue() > data.getFeatureDictionary().getThreshold1())
                data.setMinValue(data.getFeatureDictionary().getThreshold1().floatValue());
            if (data.getMaxValue() < data.getFeatureDictionary().getThreshold2())
                data.setMaxValue(data.getFeatureDictionary().getThreshold2().floatValue());
            if (data.getMinValue() > data.getFeatureDictionary().getThreshold2())
                data.setMinValue(data.getFeatureDictionary().getThreshold2().floatValue());
            if (data.getMaxValue() < data.getFeatureDictionary().getThreshold3())
                data.setMaxValue(data.getFeatureDictionary().getThreshold3().floatValue());
            if (data.getMinValue() > data.getFeatureDictionary().getThreshold3())
                data.setMinValue(data.getFeatureDictionary().getThreshold3().floatValue());

            data.setMaxValue(data.getMaxValue() + 50f);
            data.setMinValue(data.getMinValue() - 50f);
            if (data.getMinValue() > 0f)
                data.setMinValue(0f);
        }

        return listData;
    }

    @ApiMethod(name = "getMachineInfoList")
    public final List<MachineInfo> getMachineInfoList(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username,
                                                      @Named("from") String from, @Named("to") String to) throws SQLException, ClassNotFoundException, ParseException, IOException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        Date date = format.parse(to);
        long toTime = date.getTime();

        date = format.parse(from);
        long fromTime = date.getTime();
        long beforeTime = fromTime - (toTime - fromTime);
        date.setTime(beforeTime);
        String before = format.format(date);

        Connection conn = DriverManager.getConnection(url);

        PreparedStatement stmtMacAddress = conn.prepareStatement("SELECT MAC_ADDRESS, Machine_Name FROM Feature_Dictionary GROUP BY MAC_ADDRESS");
        ResultSet rsMacAddress =  stmtMacAddress.executeQuery();

        ArrayList<String> listMacAddress = new ArrayList<String>();
        ArrayList<String> listMachineName = new ArrayList<String>();

        while (rsMacAddress.next()) {
            listMacAddress.add(rsMacAddress.getString(1));
            listMachineName.add(rsMacAddress.getString(2));
        }

        MachineInfo totalData = new MachineInfo();
        MachineInfo totalBeforeData = new MachineInfo();

        MachineInfo data;
        MachineInfo beforeData;
        long totalTime;

        List<MachineInfo> listData = new ArrayList<MachineInfo>();
        HashMap<String, MachineInfo> mapData = new HashMap<String, MachineInfo>();
        List<MachineInfo> listBeforeData = new ArrayList<MachineInfo>();
        HashMap<String, MachineInfo> mapBeforeData = new HashMap<String, MachineInfo>();

        for (int i = 0; i < listMacAddress.size(); i++) {
            data = new MachineInfo();
            data.setMacAddress(listMacAddress.get(i));
            data.setMachineName(listMachineName.get(i));
            data.setStartTime(from);
            data.setEndTime(to);
            data.setTotalLastCount(0L);
            data.setBatteryState(0);

            mapData.put(listMacAddress.get(i), data);
            listData.add(data);


            data = new MachineInfo();
            data.setMacAddress(listMacAddress.get(i));

            data.setStateIdle(0F);
            data.setStateNormal(0F);
            data.setStateWarning(0F);
            data.setStateDanger(0F);

            mapBeforeData.put(listMacAddress.get(i), data);
            listBeforeData.add(data);
        }

        Bigquery bigquery = BigQueryManager.createAuthorizedClient();

        // Total Before Count
        String sQuery = String.format("SELECT COUNT(*) FROM [infinite-uptime-1232:%s.IU_device_data] WHERE Timestamp_Pi >= '%s' and Timestamp_Pi < '%s' and State = %d", Utils.decodeDBName(dbname), before, from, 3);
        QueryResponse query = bigquery.jobs().query(gProjectID, new QueryRequest().setQuery(sQuery)).execute();
        GetQueryResultsResponse queryResult = bigquery.jobs().getQueryResults(query.getJobReference().getProjectId(), query.getJobReference().getJobId()).execute();
        List<TableRow> rows = queryResult.getRows();

        if (rows != null) {
            for (TableRow row : rows) {
                List<TableCell> fields = row.getF();
                totalData.setTotalBeforeCount(Long.valueOf((String) fields.get(0).getV()));
            }
        }

        // Last Count by Mac Address
        sQuery = String.format("SELECT MAC_ADDRESS, COUNT(*) FROM [infinite-uptime-1232:%s.IU_device_data] WHERE Timestamp_Pi >= '%s' and Timestamp_Pi < '%s' and State = %d GROUP BY MAC_ADDRESS", Utils.decodeDBName(dbname), from, to, 3);
        query = bigquery.jobs().query(gProjectID, new QueryRequest().setQuery(sQuery)).execute();
        queryResult = bigquery.jobs().getQueryResults(query.getJobReference().getProjectId(), query.getJobReference().getJobId()).execute();
        rows = queryResult.getRows();

        if (rows != null) {
            for (TableRow row : rows) {
                List<TableCell> fields = row.getF();
                data = mapData.get((String) fields.get(0).getV());
                data.setTotalLastCount(Long.valueOf((String) fields.get(1).getV()));
                totalData.setTotalLastCount(totalData.getTotalLastCount() + data.getTotalLastCount());
            }
        }

        // Battery State by Mac Address
        sQuery = String.format("SELECT MAC_ADDRESS, Battery_Level FROM [infinite-uptime-1232:%s.IU_device_data] WHERE Id IN (SELECT max(Id) as max_id from [infinite-uptime-1232:%s.IU_device_data] GROUP BY MAC_ADDRESS)", Utils.decodeDBName(dbname), Utils.decodeDBName(dbname));
        query = bigquery.jobs().query(gProjectID, new QueryRequest().setQuery(sQuery)).execute();
        queryResult = bigquery.jobs().getQueryResults(query.getJobReference().getProjectId(), query.getJobReference().getJobId()).execute();
        rows = queryResult.getRows();

        if (rows != null) {
            for (TableRow row : rows) {
                List<TableCell> fields = row.getF();
                data = mapData.get((String) fields.get(0).getV());
                data.setBatteryState(Float.valueOf((String) fields.get(1).getV()).intValue());
            }
        }

        // Before Duration By Mac Address, State
        sQuery = String.format("SELECT Sum(Row_Duration), State, MAC_ADDRESS FROM [infinite-uptime-1232:%s.IU_device_duration_data] WHERE Timestamp_Pi >= '%s' and Timestamp_Pi < '%s' GROUP BY MAC_ADDRESS, State", Utils.decodeDBName(dbname), before, from);
        query = bigquery.jobs().query(gProjectID, new QueryRequest().setQuery(sQuery)).execute();
        queryResult = bigquery.jobs().getQueryResults(query.getJobReference().getProjectId(), query.getJobReference().getJobId()).execute();
        rows = queryResult.getRows();

        if (rows != null) {
            for (TableRow row : rows) {
                List<TableCell> fields = row.getF();

                String macAddress = (String) fields.get(2).getV();
                int state = Integer.valueOf((String) fields.get(1).getV());
                long rowDuration = Long.valueOf((String) fields.get(0).getV());
                data = mapBeforeData.get(macAddress);

                if (state == 0) {
                    data.setDurationIdle(rowDuration);
                    totalBeforeData.setDurationIdle(totalBeforeData.getDurationIdle() + rowDuration);
                } else if (state == 1) {
                    data.setDurationNormal(rowDuration);
                    totalBeforeData.setDurationNormal(totalBeforeData.getDurationNormal() + rowDuration);
                } else if (state == 2) {
                    data.setDurationWarning(rowDuration);
                    totalBeforeData.setDurationWarning(totalBeforeData.getDurationWarning() + rowDuration);
                } else if (state == 3) {
                    data.setDurationDanger(rowDuration);
                    totalBeforeData.setDurationDanger(totalBeforeData.getDurationDanger() + rowDuration);
                }
            }
        }

        // Last Duration By Mac Address, State
        sQuery = String.format("SELECT Sum(Row_Duration), State, MAC_ADDRESS FROM [infinite-uptime-1232:%s.IU_device_duration_data] WHERE Timestamp_Pi >= '%s' and Timestamp_Pi <= '%s' GROUP BY MAC_ADDRESS, State", Utils.decodeDBName(dbname), from, to);
        query = bigquery.jobs().query(gProjectID, new QueryRequest().setQuery(sQuery)).execute();
        queryResult = bigquery.jobs().getQueryResults(query.getJobReference().getProjectId(), query.getJobReference().getJobId()).execute();
        rows = queryResult.getRows();

        if (rows != null) {
            for (TableRow row : rows) {
                List<TableCell> fields = row.getF();

                String macAddress = (String) fields.get(2).getV();
                int state = Integer.valueOf((String) fields.get(1).getV());
                long rowDuration = Long.valueOf((String) fields.get(0).getV());
                data = mapBeforeData.get(macAddress);

                if (state == 0) {
                    data.setDurationIdle(rowDuration);
                    totalData.setDurationIdle(totalData.getDurationIdle() + rowDuration);
                } else if (state == 1) {
                    data.setDurationNormal(rowDuration);
                    totalData.setDurationNormal(totalData.getDurationNormal() + rowDuration);
                } else if (state == 2) {
                    data.setDurationWarning(rowDuration);
                    totalData.setDurationWarning(totalData.getDurationWarning() + rowDuration);
                } else if (state == 3) {
                    data.setDurationDanger(rowDuration);
                    totalData.setDurationDanger(totalData.getDurationDanger() + rowDuration);
                }
            }
        }

        // Productivity Trend by Mac Address
        for (int i = 0; i < listData.size(); i++) {
            beforeData = listBeforeData.get(i);
            totalTime = beforeData.getDurationIdle() + beforeData.getDurationNormal() + beforeData.getDurationWarning() + beforeData.getDurationDanger();

            if (totalTime != 0L) {
                beforeData.setStateIdle(((float)beforeData.getDurationIdle() * 100 / totalTime));
                beforeData.setStateNormal(((float) beforeData.getDurationNormal() * 100 / totalTime));
                beforeData.setStateWarning(((float) beforeData.getDurationWarning() * 100 / totalTime));
                beforeData.setStateDanger(((float)beforeData.getDurationDanger() * 100 / totalTime));
            }

            data = listData.get(i);
            totalTime = data.getDurationIdle() + data.getDurationNormal() + data.getDurationWarning() + data.getDurationDanger();

            if (totalTime != 0L) {
                data.setStateIdle(((float)data.getDurationIdle() * 100 / totalTime));
                data.setStateNormal(((float) data.getDurationNormal() * 100 / totalTime));
                data.setStateWarning(((float) data.getDurationWarning() * 100 / totalTime));
                data.setStateDanger(((float)data.getDurationDanger() * 100 / totalTime));

                float lastTrend = data.getStateNormal();
                float beforeTrend = beforeData.getStateNormal();

                if (Math.abs(lastTrend - beforeTrend) < 1f) {
                    data.setProductivityTrend(0L);
                }
                else {
                    if (lastTrend < beforeTrend) {
                        data.setProductivityTrend(-1L);
                    }
                    else {
                        data.setProductivityTrend(1L);
                    }
                }
            }
            else {
                data.setProductivityTrend(0L);
            }
        }

        totalTime = totalData.getDurationIdle() + totalData.getDurationNormal() + totalData.getDurationWarning() + totalData.getDurationDanger();

        if (totalTime != 0L) {
            totalData.setStateIdle(((float) totalData.getDurationIdle() * 100 / totalTime));
            totalData.setStateNormal(((float) totalData.getDurationNormal() * 100 / totalTime));
            totalData.setStateWarning(((float) totalData.getDurationWarning() * 100 / totalTime));
            totalData.setStateDanger(((float) totalData.getDurationDanger() * 100 / totalTime));
        }

        conn.close();

        listData.add(0, totalData);

        return listData;
    }

    @ApiMethod(name = "getCurrentMachineInfo")
    public final MachineInfo getCurrentMachineInfo(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username,
                                                   @Named("from") String from, @Named("to") String to, @Named("macAddress") String macAddress) throws SQLException, ClassNotFoundException, ParseException, IOException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        Date date = format.parse(to);
        long toTime = date.getTime();

        date = format.parse(from);
        long fromTime = date.getTime();
        long beforeTime = fromTime - (toTime - fromTime);
        date.setTime(beforeTime);
        String before = format.format(date);

        Connection conn = DriverManager.getConnection(url);

        String fQuery = "SELECT Tool_ID, Tool_Status, Tool_Name FROM Feature_Dictionary WHERE MAC_ADDRESS = ? GROUP BY Tool_ID";
        PreparedStatement stmt = conn.prepareStatement(fQuery);
        stmt.setString(1, macAddress);

        ResultSet rs =  stmt.executeQuery();

        MachineInfo data = new MachineInfo();
        MachineInfo beforeData = new MachineInfo();
        ToolInfo info;
        ToolInfo beforeInfo;
        long totalTime;

        List<ToolInfo> listData = new ArrayList<ToolInfo>();
        HashMap<Integer, ToolInfo> mapData = new HashMap<Integer, ToolInfo>();
        List<ToolInfo> listBeforeData = new ArrayList<ToolInfo>();
        HashMap<Integer, ToolInfo> mapBeforeData = new HashMap<Integer, ToolInfo>();

        while (rs.next()) {
            int toolID = rs.getInt(1);
            int toolStatus = rs.getInt(2);
            String toolName = rs.getString(3);

            info = new ToolInfo();
            info.setToolID(toolID);
            info.setToolStatus(toolStatus);
            info.setToolName(toolName);

            listData.add(info);
            mapData.put(toolID, info);

            info = new ToolInfo();
            info.setToolID(toolID);
            info.setToolStatus(toolStatus);
            info.setToolName(toolName);

            listBeforeData.add(info);
            mapBeforeData.put(toolID, info);
        }

        Bigquery bigquery = BigQueryManager.createAuthorizedClient();

        // Total Before Count
        String sQuery = String.format("SELECT COUNT(*) FROM [infinite-uptime-1232:%s.IU_device_data] WHERE Timestamp_Pi >= '%s' and Timestamp_Pi <= '%s' and State = %d and MAC_ADDRESS = '%s'", Utils.decodeDBName(dbname), before, from, 3, macAddress);
        QueryResponse query = bigquery.jobs().query(gProjectID, new QueryRequest().setQuery(sQuery)).execute();
        GetQueryResultsResponse queryResult = bigquery.jobs().getQueryResults(query.getJobReference().getProjectId(), query.getJobReference().getJobId()).execute();
        List<TableRow> rows = queryResult.getRows();

        if (rows != null) {
            for (TableRow row : rows) {
                List<TableCell> fields = row.getF();
                data.setTotalBeforeCount(Long.valueOf((String) fields.get(0).getV()));
            }
        }

        // Last Count by Tool ID
        sQuery = String.format("SELECT Tool_ID, COUNT(*) FROM [infinite-uptime-1232:%s.IU_device_data] WHERE Timestamp_Pi >= '%s' and Timestamp_Pi <= '%s' and State = %d and MAC_ADDRESS = '%s' GROUP BY Tool_ID", Utils.decodeDBName(dbname), from, to, 3, macAddress);
        query = bigquery.jobs().query(gProjectID, new QueryRequest().setQuery(sQuery)).execute();
        queryResult = bigquery.jobs().getQueryResults(query.getJobReference().getProjectId(), query.getJobReference().getJobId()).execute();
        rows = queryResult.getRows();

        if (rows != null) {
            for (TableRow row : rows) {
                List<TableCell> fields = row.getF();
                info = mapData.get(Integer.valueOf((String) fields.get(0).getV()));
                info.setTotalLastCount(Long.valueOf((String) fields.get(1).getV()));
                data.setTotalLastCount(data.getTotalLastCount() + info.getTotalLastCount());
            }
        }

        // Before Duration By Tool ID, State
        sQuery = String.format("SELECT Sum(Row_Duration), State, Tool_ID FROM [infinite-uptime-1232:%s.IU_device_duration_data] WHERE Timestamp_Pi >= '%s' and Timestamp_Pi <= '%s' and MAC_ADDRESS = '%s' GROUP BY Tool_ID, State", Utils.decodeDBName(dbname), before, from, macAddress);
        query = bigquery.jobs().query(gProjectID, new QueryRequest().setQuery(sQuery)).execute();
        queryResult = bigquery.jobs().getQueryResults(query.getJobReference().getProjectId(), query.getJobReference().getJobId()).execute();
        rows = queryResult.getRows();

        if (rows != null) {
            for (TableRow row : rows) {
                List<TableCell> fields = row.getF();

                info = mapBeforeData.get(Integer.valueOf((String) fields.get(2).getV()));
                int state = Integer.valueOf((String) fields.get(1).getV());
                long rowDuration = Long.valueOf((String) fields.get(0).getV());

                if (state == 0) {
                    info.setDurationIdle(rowDuration);
                    beforeData.setDurationIdle(beforeData.getDurationIdle() + rowDuration);
                } else if (state == 1) {
                    info.setDurationNormal(rowDuration);
                    beforeData.setDurationNormal(beforeData.getDurationNormal() + rowDuration);
                } else if (state == 2) {
                    info.setDurationWarning(rowDuration);
                    beforeData.setDurationWarning(beforeData.getDurationWarning() + rowDuration);
                } else if (state == 3) {
                    info.setDurationDanger(rowDuration);
                    beforeData.setDurationDanger(beforeData.getDurationDanger() + rowDuration);
                }
            }
        }

        // Last Duration By Tool ID, State
        sQuery = String.format("SELECT Sum(Row_Duration), State, Tool_ID FROM [infinite-uptime-1232:%s.IU_device_duration_data] WHERE Timestamp_Pi >= '%s' and Timestamp_Pi <= '%s' and MAC_ADDRESS = '%s' GROUP BY Tool_ID, State", Utils.decodeDBName(dbname), from, to, macAddress);
        query = bigquery.jobs().query(gProjectID, new QueryRequest().setQuery(sQuery)).execute();
        queryResult = bigquery.jobs().getQueryResults(query.getJobReference().getProjectId(), query.getJobReference().getJobId()).execute();
        rows = queryResult.getRows();

        if (rows != null) {
            for (TableRow row : rows) {
                List<TableCell> fields = row.getF();

                info = mapBeforeData.get(Integer.valueOf((String) fields.get(2).getV()));
                int state = Integer.valueOf((String) fields.get(1).getV());
                long rowDuration = Long.valueOf((String) fields.get(0).getV());

                if (state == 0) {
                    info.setDurationIdle(rowDuration);
                    data.setDurationIdle(data.getDurationIdle() + rowDuration);
                } else if (state == 1) {
                    info.setDurationNormal(rowDuration);
                    data.setDurationNormal(data.getDurationNormal() + rowDuration);
                } else if (state == 2) {
                    info.setDurationWarning(rowDuration);
                    data.setDurationWarning(data.getDurationWarning() + rowDuration);
                } else if (state == 3) {
                    info.setDurationDanger(rowDuration);
                    data.setDurationDanger(data.getDurationDanger() + rowDuration);
                }
            }
        }

        // Productivity Trend by Tool ID
        for (int i = 0; i < listData.size(); i++) {
            beforeInfo = listBeforeData.get(i);
            totalTime = beforeInfo.getDurationIdle() + beforeInfo.getDurationNormal() + beforeInfo.getDurationWarning() + beforeInfo.getDurationDanger();

            if (totalTime != 0L) {
                beforeInfo.setStateIdle(((float)beforeInfo.getDurationIdle() * 100 / totalTime));
                beforeInfo.setStateNormal(((float) beforeInfo.getDurationNormal() * 100 / totalTime));
                beforeInfo.setStateWarning(((float) beforeInfo.getDurationWarning() * 100 / totalTime));
                beforeInfo.setStateDanger(((float)beforeInfo.getDurationDanger() * 100 / totalTime));
            }

            info = listData.get(i);
            totalTime = info.getDurationIdle() + info.getDurationNormal() + info.getDurationWarning() + info.getDurationDanger();

            if (totalTime != 0L) {
                info.setStateIdle(((float)info.getDurationIdle() * 100 / totalTime));
                info.setStateNormal(((float) info.getDurationNormal() * 100 / totalTime));
                info.setStateWarning(((float) info.getDurationWarning() * 100 / totalTime));
                info.setStateDanger(((float)info.getDurationDanger() * 100 / totalTime));

                float lastTrend = info.getStateNormal();
                float beforeTrend = beforeInfo.getStateNormal();

                if (Math.abs(lastTrend - beforeTrend) < 1f) {
                    info.setProductivityTrend(0);
                }
                else {
                    if (lastTrend < beforeTrend) {
                        info.setProductivityTrend(-1);
                    }
                    else {
                        info.setProductivityTrend(1);
                    }
                }
            }
            else {
                info.setProductivityTrend(0);
            }
        }

        totalTime = data.getDurationIdle() + data.getDurationNormal() + data.getDurationWarning() + data.getDurationDanger();

        if (totalTime != 0L) {
            data.setStateIdle(((float) data.getDurationIdle() * 100 / totalTime));
            data.setStateNormal(((float) data.getDurationNormal() * 100 / totalTime));
            data.setStateWarning(((float) data.getDurationWarning() * 100 / totalTime));
            data.setStateDanger(((float) data.getDurationDanger() * 100 / totalTime));
        }

        conn.close();

        data.setToolInfos(listData);

        return data;
    }

    @ApiMethod(name = "getRedAlertInfoList")
    public final List<RedAlertInfo> getRedAlertInfoList(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username) throws SQLException, ClassNotFoundException, ParseException, IOException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        long toTime = System.currentTimeMillis();

        PreparedStatement stmtMacAddress = conn.prepareStatement("SELECT MAC_ADDRESS, Machine_Name FROM Feature_Dictionary GROUP BY MAC_ADDRESS");
        ResultSet rsMacAddress =  stmtMacAddress.executeQuery();

        ArrayList<String> listMacAddress = new ArrayList<String>();
        ArrayList<String> listMachineName = new ArrayList<String>();

        while (rsMacAddress.next()) {
            listMacAddress.add(rsMacAddress.getString(1));
            listMachineName.add(rsMacAddress.getString(2));
        }

        List<RedAlertInfo> listData = new ArrayList<RedAlertInfo>();
        HashMap<String, RedAlertInfo> mapData = new HashMap<String, RedAlertInfo>();

        for (int i = 0; i < listMacAddress.size(); i++) {
            RedAlertInfo data = new RedAlertInfo();
            data.setMacAddress(listMacAddress.get(i));
            data.setMachineName(listMachineName.get(i));

            mapData.put(listMacAddress.get(i), data);
            listData.add(data);
        }

        RedAlertInfo data;

        Bigquery bigquery = BigQueryManager.createAuthorizedClient();

        for (int i = 6; i >= 0; i--) {
            String to = format.format(new Date(toTime - 1000L * 60L * 60L * 24L * i));
            String from = format.format(new Date(toTime - 1000L * 60L * 60L * 24L * (i + 1)));

            String sQuery = String.format("SELECT Sum(Row_Duration), MAC_ADDRESS FROM [infinite-uptime-1232:%s.IU_device_duration_data] WHERE Timestamp_Pi >= '%s' and Timestamp_Pi <= '%s' and State = %d GROUP BY MAC_ADDRESS", Utils.decodeDBName(dbname), from, to, 3);
            QueryResponse query = bigquery.jobs().query(gProjectID, new QueryRequest().setQuery(sQuery)).execute();
            GetQueryResultsResponse queryResult = bigquery.jobs().getQueryResults(query.getJobReference().getProjectId(), query.getJobReference().getJobId()).execute();
            List<TableRow> rows = queryResult.getRows();

            if (rows != null) {
                for (TableRow row : rows) {
                    List<TableCell> fields = row.getF();
                    long trend = Long.valueOf((String) fields.get(0).getV());
                    data = mapData.get((String) fields.get(1).getV());
                    data.setTrends(6 - i, trend);
                    data.setSpan(data.getSpan() + trend);
                }
            }
        }

        for (int i = 0; i < listData.size(); i++) {
            data = listData.get(i);

            if (data.getSpan() != 0L) {
                for (int k = 0; k < 7; k++) {
                    int percent = (int) (data.getTrends(k) * 100 / data.getSpan());

                    if (percent == 0)
                        percent = 1;

                    data.setTrendsPercent(k, percent);
                }
            }
        }

        conn.close();

        return listData;
    }

    @ApiMethod(name = "getDeviceStatus")
    public final DeviceStatus getDeviceStatus(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username, @Named("address") String address) throws SQLException, ClassNotFoundException, IOException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);

        String fQuery = "SELECT MAC_ADDRESS, Device_Status, Machine_Name FROM Feature_Dictionary";

        fQuery += " WHERE MAC_ADDRESS = ?";
        fQuery += " GROUP BY MAC_ADDRESS";

        PreparedStatement stmt = conn.prepareStatement(fQuery);

        stmt.setString(1, address);

        ResultSet rs =  stmt.executeQuery();

        DeviceStatus value = new DeviceStatus();

        while (rs.next()) {
            value.setMacAddress(rs.getString(1));
            value.setStatus(rs.getInt(2));
            value.setMachineName(rs.getString(3));
        }

        Bigquery bigquery = BigQueryManager.createAuthorizedClient();
        String sQuery = String.format("SELECT Battery_Level FROM [infinite-uptime-1232:%s.IU_device_data] WHERE MAC_ADDRESS = '%s' ORDER BY Id DESC LIMIT 1", Utils.decodeDBName(dbname), address);
        QueryResponse query = bigquery.jobs().query(gProjectID, new QueryRequest().setQuery(sQuery)).execute();
        GetQueryResultsResponse queryResult = bigquery.jobs().getQueryResults(query.getJobReference().getProjectId(), query.getJobReference().getJobId()).execute();
        List<TableRow> rows = queryResult.getRows();

        value.setBatteryLevel(0F);

        if (rows != null) {
            for (TableRow row : rows) {
                List<TableCell> fields = row.getF();
                value.setBatteryLevel(Float.valueOf((String) fields.get(0).getV()));
            }
        }

        fQuery = "SELECT Tool_ID, Tool_Status FROM Feature_Dictionary WHERE MAC_ADDRESS = ? GROUP BY Tool_ID";
        stmt = conn.prepareStatement(fQuery);
        stmt.setString(1, address);

        rs =  stmt.executeQuery();

        int toolCount = 0;
        int toolActiveCount = 0;

        while (rs.next()) {
            int toolID = rs.getInt(1);
            int toolStatus = rs.getInt(2);

            toolCount++;
            if (toolStatus == 1)
                toolActiveCount++;
        }

        value.setToolCount(toolCount);
        value.setToolActiveCount(toolActiveCount);

        conn.close();

        return value;
    }

    @ApiMethod(name = "getMonitoringDataListByRealTime")
    public final List<MonitoringData> getMonitoringDataListByRealTime(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username, @Named("address") String address, @Named("featureId") Integer featureId) throws SQLException, ClassNotFoundException, IOException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);

        String fQuery = "SELECT MAC_ADDRESS, Feature_ID, Feature_Name, Threshold_1, Threshold_2, Threshold_3, Device_Status, Machine_Name FROM Feature_Dictionary WHERE MAC_ADDRESS = ? and Feature_ID = ?";
        PreparedStatement stmt = conn.prepareStatement(fQuery);
        stmt.setString(1, address);
        stmt.setInt(2, featureId);

        ResultSet rs =  stmt.executeQuery();

        List<MonitoringData> listData = new ArrayList<MonitoringData>();
        HashMap<String, MonitoringData> mapData = new HashMap<String, MonitoringData>();

        while (rs.next()) {
            MonitoringData data = new MonitoringData();

            data.getFeatureDictionary().setMacAddress(rs.getString(1));
            data.getFeatureDictionary().setFeatureID(rs.getInt(2));
            data.getFeatureDictionary().setFeatureName(rs.getString(3));
            data.getFeatureDictionary().setThreshold1(rs.getInt(4));
            data.getFeatureDictionary().setThreshold2(rs.getInt(5));
            data.getFeatureDictionary().setThreshold3(rs.getInt(6));
            data.getFeatureDictionary().setStatus(rs.getInt(7));
            data.getFeatureDictionary().setMachineName(rs.getString(8));

            listData.add(data);
            mapData.put(data.getFeatureDictionary().getMacAddress() + "_" + data.getFeatureDictionary().getFeatureID(), data);
        }

        conn.close();

        Bigquery bigquery = BigQueryManager.createAuthorizedClient();
        String sQuery = String.format("SELECT Id, Timestamp_Pi, Timestamp, MAC_ADDRESS, Tool_ID, State, Battery_Level, " +
                "Feature_Value_0, Feature_Value_1, Feature_Value_2, Feature_Value_3, Feature_Value_4, Feature_Value_5 " +
                "FROM [infinite-uptime-1232:%s.IU_device_data] WHERE MAC_ADDRESS = '%s' ORDER BY Id DESC LIMIT 25", Utils.decodeDBName(dbname), address);
        QueryResponse query = bigquery.jobs().query(gProjectID, new QueryRequest().setQuery(sQuery)).execute();
        GetQueryResultsResponse queryResult = bigquery.jobs().getQueryResults(query.getJobReference().getProjectId(), query.getJobReference().getJobId()).execute();
        List<TableRow> rows = queryResult.getRows();

        if (rows != null) {
            for (TableRow row : rows) {
                List<TableCell> fields = row.getF();
                IUDeviceData value = new IUDeviceData();

                value.setId(Long.valueOf((String) fields.get(0).getV()));

                String time = (String) fields.get(1).getV();
                String macAddress = (String) fields.get(3).getV();
                int state = Integer.valueOf((String) fields.get(5).getV());
                long milliseconds = Utils.convertDateToMilliseconds(time);

                if (milliseconds == -1L)
                    continue;

                for (int i = 0; i < 6; i++) {
                    MonitoringData data = mapData.get(macAddress + "_" + i);

                    if (data == null)
                        continue;

                    FeatureInfo info;
                    Float featureValue = Float.valueOf((String) fields.get(7 + i).getV());

                    if (data.getFeatureInfo().size() == 0) {
                        info = new FeatureInfo();
                        info.setState(state);
                        info.setFeatureValue(featureValue);
                        info.setStartTime(milliseconds);
                        info.setEndTime(milliseconds);

                        info.setStartTimePi(time);
                        info.setEndTimePi(time);

                        data.setMaxValue(info.getFeatureValue());
                        data.setMinValue(info.getFeatureValue());

                        data.getFeatureInfo().add(0, info);
                    } else {
                        info = data.getFeatureInfo().get(0);
                        info.setEndTime(milliseconds);
                        info.setEndTimePi(time);

                        if (info.getState() != state || info.getFeatureValue() != featureValue) {
                            info = new FeatureInfo();
                            info.setState(state);
                            info.setFeatureValue(featureValue);
                            info.setStartTime(milliseconds);
                            info.setEndTime(milliseconds);

                            info.setStartTimePi(time);
                            info.setEndTimePi(time);

                            if (data.getMaxValue() < info.getFeatureValue())
                                data.setMaxValue(info.getFeatureValue());

                            if (data.getMinValue() > info.getFeatureValue())
                                data.setMinValue(info.getFeatureValue());

                            data.getFeatureInfo().add(0, info);
                        }
                    }
                }
            }
        }

        for (int i = 0; i < listData.size(); i++) {
            MonitoringData data = listData.get(i);

            long curTime = 0L;
            for (int j = 0; j < data.getFeatureInfo().size(); j++) {
                FeatureInfo info = data.getFeatureInfo().get(j);
                long duration = info.getDuration();
                curTime = curTime + duration;
                info.setTimeLabel(Utils.convertTimeToString(-curTime));
            }

            if (data.getMaxValue() < data.getFeatureDictionary().getThreshold1())
                data.setMaxValue(data.getFeatureDictionary().getThreshold1().floatValue());
            if (data.getMinValue() > data.getFeatureDictionary().getThreshold1())
                data.setMinValue(data.getFeatureDictionary().getThreshold1().floatValue());
            if (data.getMaxValue() < data.getFeatureDictionary().getThreshold2())
                data.setMaxValue(data.getFeatureDictionary().getThreshold2().floatValue());
            if (data.getMinValue() > data.getFeatureDictionary().getThreshold2())
                data.setMinValue(data.getFeatureDictionary().getThreshold2().floatValue());
            if (data.getMaxValue() < data.getFeatureDictionary().getThreshold3())
                data.setMaxValue(data.getFeatureDictionary().getThreshold3().floatValue());
            if (data.getMinValue() > data.getFeatureDictionary().getThreshold3())
                data.setMinValue(data.getFeatureDictionary().getThreshold3().floatValue());

            data.setMaxValue(data.getMaxValue() + 50f);
            data.setMinValue(data.getMinValue() - 50f);
            if (data.getMinValue() > 0f)
                data.setMinValue(0f);
        }

        return listData;
    }

    @ApiMethod(name = "setMaterialData")
    public final void setMaterialData(@Named("Material") String Material, @Named("Tool_Diameter") String Tool_Diameter, @Named("Flutes") String Flutes,
                                       @Named("Tool_Type") String Tool_Type, @Named("RPM") String RPM, @Named("Feed_Rate") String Feed_Rate,
                                       @Named("Other") String Other) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = String.format(database_url_format, "server0", "MLS", "root");
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);
        PreparedStatement stmt = conn.prepareStatement("Insert Into Tagged_Data (Timestamp_Pi, Material, Tool_Diameter, Flutes, Tool_Type, RPM, Feed_Rate, Other) VALUES (?, ?, ?, ?, ?, ?, ?, ?);");

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.S");
        String time = format.format(new java.util.Date());

        stmt.setString(1, time);
        stmt.setString(2, Material);
        stmt.setString(3, Tool_Diameter);
        stmt.setString(4, Flutes);
        stmt.setString(5, Tool_Type);
        stmt.setString(6, RPM);
        stmt.setString(7, Feed_Rate);
        stmt.setString(8, Other);

        stmt.executeUpdate();
        conn.close();
    }

    /////////////// Calibration Data Start ////////////////

    @ApiMethod(name = "startCollectingData")
    public final CalibrationStatus startCollectingData(@Named("portName") String portName, @Named("testingCycle") Integer testingCycle) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = database_calibration_url;
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);
        PreparedStatement stmt = conn.prepareStatement("Insert Into tb_status (timestamp, port_num, testing_cycle, status) VALUES (?, ?, ?, ?);", Statement.RETURN_GENERATED_KEYS);

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.S");
        format.setTimeZone(TimeZone.getTimeZone("gmt"));
        String time = format.format(new java.util.Date());

        stmt.setString(1, time);
        stmt.setString(2, portName);
        stmt.setInt(3, testingCycle);
        stmt.setInt(4, 0);

        stmt.executeUpdate();

        CalibrationStatus status = new CalibrationStatus();

        ResultSet generatedKeys = stmt.getGeneratedKeys();
        generatedKeys.next();

        status.setId(generatedKeys.getInt(1));

        return status;
    }

    @ApiMethod(name = "checkingRequest")
    public final CalibrationStatus checkingRequest(@Named("id") Integer id) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = database_calibration_url;
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);

        PreparedStatement stmt;

        if (id == -1) {
            String query = "SELECT id, timestamp, device_id, port_num, testing_cycle, status, status_msg, audio_id, accel_id FROM tb_status ORDER BY id DESC LIMIT 1";
            stmt = conn.prepareStatement(query);
        }
        else {
            String query = "SELECT id, timestamp, device_id, port_num, testing_cycle, status, status_msg, audio_id, accel_id FROM tb_status WHERE id = ?";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, id);
        }

        ResultSet rs =  stmt.executeQuery();
        CalibrationStatus status = new CalibrationStatus();

        if (rs.next()) {
            status.setId(rs.getInt(1));
            status.setTimestamp(rs.getString(2));
            status.setDevice_id(rs.getString(3));
            status.setPort_num(rs.getString(4));
            status.setTesting_cycle(rs.getInt(5));
            status.setStatus(rs.getInt(6));
            status.setStatus_msg(rs.getString(7));
            status.setAudioId(rs.getInt(8));
            status.setAccelId(rs.getInt(9));
        }
        else {
            status.setId(-1);
        }

        if (status.getId() != -1 && id == -1 && status.getStatus() == 0) {
            stmt = conn.prepareStatement("Update tb_status SET status = ? WHERE id = ?;");

            stmt.setInt(1, 1);
            stmt.setInt(2, status.getId());

            stmt.executeUpdate();
        }

        return status;
    }

    @ApiMethod(name = "changeRequestStatus")
    public final void changeRequestStatus(@Named("id") Integer id, @Named("status") Integer status, @Named("statusMsg") String statusMsg) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = database_calibration_url;
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        if (status == 3) {
            Connection conn = DriverManager.getConnection(url);

            PreparedStatement stmt;

            stmt = conn.prepareStatement("Update tb_status SET status = ?, status_msg = ? WHERE id = ?;");

            stmt.setInt(1, status);
            stmt.setString(2, statusMsg);
            stmt.setInt(3, id);

            stmt.executeUpdate();
        }
    }

    @ApiMethod(name = "sendBlobData")
    public final FileData sendBlobData(@Named("id") Integer id, @Named("status") Integer status, @Named("deviceId") String deviceId, @Named("portNum") String portNum, @Named("timestamp") String timestamp, FileData file) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = database_calibration_url;
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);

        PreparedStatement stmt;

        String audioData = file.getAudioFileData();

        stmt = conn.prepareStatement("Insert Into tb_audio_data (timestamp, audio, device_id, port_num, audio_data_length, audio_data) VALUES (?, ?, ?, ?, ?, ?);", Statement.RETURN_GENERATED_KEYS);

        stmt.setString(1, timestamp);
        stmt.setInt(2, 0);
        stmt.setString(3, deviceId);
        stmt.setString(4, portNum);
        stmt.setInt(5, audioData.getBytes().length);

        Blob blob = conn.createBlob();
        byte[] bData = audioData.getBytes();
        blob.setBytes(1, bData);
        int audioLen = 0;
        try {
            audioLen = new String(blob.getBytes(1, (int) blob.length()), "UTF-8").length();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        stmt.setBlob(6, blob);
        stmt.executeUpdate();

        ResultSet generatedKeys = stmt.getGeneratedKeys();
        generatedKeys.next();

        int audioId = generatedKeys.getInt(1);

        String accelData = file.getAccelFileData();

        stmt = conn.prepareStatement("Insert Into tb_accel_data (timestamp, accel_x, accel_y, accel_z, device_id, port_num, accel_data_length, accel_data) VALUES (?, ?, ?, ?, ?, ?, ?, ?);", Statement.RETURN_GENERATED_KEYS);

        stmt.setString(1, timestamp);
        stmt.setFloat(2, 0);
        stmt.setFloat(3, 0);
        stmt.setFloat(4, 0);
        stmt.setString(5, deviceId);
        stmt.setString(6, portNum);
        stmt.setInt(7, accelData.getBytes().length);

        blob = conn.createBlob();
        bData = accelData.getBytes();
        blob.setBytes(1, bData);
        int accelLen = 0;
        try {
            accelLen = new String(blob.getBytes(1, (int) blob.length()), "UTF-8").length();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        stmt.setBlob(8, blob);
        stmt.executeUpdate();

        generatedKeys = stmt.getGeneratedKeys();
        generatedKeys.next();

        int accelId = generatedKeys.getInt(1);

        stmt = conn.prepareStatement("Update tb_status SET status = ?, audio_id = ?, accel_id = ? WHERE id = ?;");
        stmt.setInt(1, 2);
        stmt.setInt(2, audioId);
        stmt.setInt(3, accelId);
        stmt.setInt(4, id);

        stmt.executeUpdate();

        conn.close();

        FileData data = new FileData();
        data.setAudioFileSize(audioLen);
        data.setAccelFileSize(accelLen);

        return data;
    }

    @ApiMethod(name = "generateReport")
    public final FileData generateReport(@Named("audioId1") Integer audioId1, @Named("accelId1") Integer accelId1, @Named("cycle1") Integer cycle1,
                                         @Named("audioId2") Integer audioId2, @Named("accelId2") Integer accelId2, @Named("cycle2") Integer cycle2,
                                         @Named("audioId3") Integer audioId3, @Named("accelId3") Integer accelId3, @Named("cycle3") Integer cycle3,
                                         @Named("audioId4") Integer audioId4, @Named("accelId4") Integer accelId4, @Named("cycle4") Integer cycle4) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = database_calibration_url;
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);

        PreparedStatement stmt;
        String query;
        ResultSet rs;

        String[] accelData = new String[4];
        int[] accelDataLength = new int[4];

        accelDataLength[0] = cycle1 * 1000;
        accelDataLength[1] = cycle2 * 1000;
        accelDataLength[2] = cycle3 * 1000;
        accelDataLength[3] = cycle4 * 1000;

        query = "SELECT id, timestamp, device_id, port_num, accel_data_length, accel_data FROM tb_accel_data WHERE id = ?";
        stmt = conn.prepareStatement(query);
        stmt.setInt(1, accelId1);

        rs =  stmt.executeQuery();

        if (rs.next()) {
            try {
                Blob blob = rs.getBlob(6);
                accelData[0] = new String(blob.getBytes(1, (int) blob.length()), "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }

        query = "SELECT id, timestamp, device_id, port_num, accel_data_length, accel_data FROM tb_accel_data WHERE id = ?";
        stmt = conn.prepareStatement(query);
        stmt.setInt(1, accelId2);

        rs =  stmt.executeQuery();

        if (rs.next()) {
            try {
                Blob blob = rs.getBlob(6);
                accelData[1] = new String(blob.getBytes(1, (int) blob.length()), "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }


        query = "SELECT id, timestamp, device_id, port_num, accel_data_length, accel_data FROM tb_accel_data WHERE id = ?";
        stmt = conn.prepareStatement(query);
        stmt.setInt(1, accelId3);

        rs =  stmt.executeQuery();

        if (rs.next()) {
            try {
                Blob blob = rs.getBlob(6);
                accelData[2] = new String(blob.getBytes(1, (int) blob.length()), "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }


        query = "SELECT id, timestamp, device_id, port_num, accel_data_length, accel_data FROM tb_accel_data WHERE id = ?";
        stmt = conn.prepareStatement(query);
        stmt.setInt(1, accelId4);

        rs =  stmt.executeQuery();

        if (rs.next()) {
            try {
                Blob blob = rs.getBlob(6);
                accelData[3] = new String(blob.getBytes(1, (int) blob.length()), "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
        }

        FileData retData = new FileData();

        String[] accelData1 = accelData[0].split(";");
        String[] accelData2 = accelData[1].split(";");
        String[] accelData3 = accelData[2].split(";");
        String[] accelData4 = accelData[3].split(";");

        retData.setDataCount1(accelData1.length);
        retData.setDataCount2(accelData2.length);
        retData.setDataCount3(accelData3.length);
        retData.setDataCount4(accelData4.length);

        accelDataLength[0] = Math.min(accelDataLength[0], accelData1.length) / 2 * 2;
        accelDataLength[1] = Math.min(accelDataLength[1], accelData2.length) / 2 * 2;
        accelDataLength[2] = Math.min(accelDataLength[2], accelData3.length) / 2 * 2;
        accelDataLength[3] = Math.min(accelDataLength[3], accelData4.length) / 2 * 2;

        for (int i = 0; i < accelDataLength.length; i++) {
            accelDataLength[i] = (int) Math.pow(2, (int) (Math.log(accelDataLength[i]) / Math.log(2)));
        }

        retData.setFftCount1(accelDataLength[0]);
        retData.setFftCount2(accelDataLength[1]);
        retData.setFftCount3(accelDataLength[2]);
        retData.setFftCount4(accelDataLength[3]);

        double[][] dataR1 = new double[accelDataLength[0]][3];
        double[][] dataR2 = new double[accelDataLength[1]][3];
        double[][] dataR3 = new double[accelDataLength[2]][3];
        double[][] dataR4 = new double[accelDataLength[3]][3];

        double[] sqrData1 = new double[accelDataLength[0]];
        double[] sqrData2 = new double[accelDataLength[1]];
        double[] sqrData3 = new double[accelDataLength[2]];
        double[] sqrData4 = new double[accelDataLength[3]];

        FFT.Complex[] fftData1 = new FFT.Complex[accelDataLength[0]];
        FFT.Complex[] fftData2 = new FFT.Complex[accelDataLength[1]];
        FFT.Complex[] fftData3 = new FFT.Complex[accelDataLength[2]];
        FFT.Complex[] fftData4 = new FFT.Complex[accelDataLength[3]];
//        FFT.Complex[] fftData1 = new FFT.Complex[4096];
//        FFT.Complex[] fftData2 = new FFT.Complex[16384];
//        FFT.Complex[] fftData3 = new FFT.Complex[32768];
//        FFT.Complex[] fftData4 = new FFT.Complex[65536];

        //String[] tmp = new String[accelDataLength[2]];
        for (int i = 0; i < accelDataLength[0]; i++) {
            String[] values = accelData1[i].split(" ");

            for (int j = 0; j < 3; j++) {
                dataR1[i][j] = Double.valueOf(values[j]);
            }

            sqrData1[i] = (double) Math.sqrt(dataR1[i][0] * dataR1[i][0] + dataR1[i][1] * dataR1[i][1] + dataR1[i][2] * dataR1[i][2]);
            fftData1[i] = new FFT.Complex(sqrData1[i], 0);
        }

        //retData.setOrgdata(dataR3);
        //retData.setSqrData(sqrData3);

        for (int i = accelDataLength[0]; i < fftData1.length; i++) {
            fftData1[i] = new FFT.Complex(0, 0);
        }

        for (int i = 0; i < accelDataLength[1]; i++) {
            String[] values = accelData2[i].split(" ");

            for (int j = 0; j < 3; j++) {
                dataR2[i][j] = Double.valueOf(values[j]);
            }

            sqrData2[i] = (double) Math.sqrt(dataR2[i][0] * dataR2[i][0] + dataR2[i][1] * dataR2[i][1] + dataR2[i][2] * dataR2[i][2]);
            fftData2[i] = new FFT.Complex(sqrData2[i], 0);
        }

        for (int i = accelDataLength[1]; i < fftData2.length; i++) {
            fftData2[i] = new FFT.Complex(0, 0);
        }

        for (int i = 0; i < accelDataLength[2]; i++) {
            String[] values = accelData3[i].split(" ");

            for (int j = 0; j < 3; j++) {
                dataR3[i][j] = Double.valueOf(values[j]);
            }

            sqrData3[i] = (double) Math.sqrt(dataR3[i][0] * dataR3[i][0] + dataR3[i][1] * dataR3[i][1] + dataR3[i][2] * dataR3[i][2]);
            fftData3[i] = new FFT.Complex(sqrData3[i], 0);
            //tmp[i] = fftData3[i].toString();
        }

        for (int i = accelDataLength[2]; i < fftData3.length; i++) {
            fftData3[i] = new FFT.Complex(0, 0);
        }

        for (int i = 0; i < accelDataLength[3]; i++) {
            String[] values = accelData4[i].split(" ");

            for (int j = 0; j < 3; j++) {
                dataR4[i][j] = Double.valueOf(values[j]);
            }

            sqrData4[i] = (double) Math.sqrt(dataR4[i][0] * dataR4[i][0] + dataR4[i][1] * dataR4[i][1] + dataR4[i][2] * dataR4[i][2]);
            fftData4[i] = new FFT.Complex(sqrData4[i], 0);
        }

        for (int i = accelDataLength[3]; i < fftData4.length; i++) {
            fftData4[i] = new FFT.Complex(0, 0);
        }

        //retData.setFftDataOrg(tmp);

        fftData1 = FFT.Complex.fft(fftData1);
        fftData2 = FFT.Complex.fft(fftData2);
        fftData3 = FFT.Complex.fft(fftData3);
        fftData4 = FFT.Complex.fft(fftData4);

//        tmp = new String[fftData3.length];
//        for (int i = 0; i < tmp.length; i++)
//            tmp[i] = fftData3[i].toString();
//        retData.setFftData(tmp);

        double[] absData1 = new double[fftData1.length];
        double[] absData2 = new double[fftData2.length];
        double[] absData3 = new double[fftData3.length];
        double[] absData4 = new double[fftData4.length];
        double fs = 1000f;

        for (int i = 0; i < fftData1.length; i++) {
            absData1[i] = fftData1[i].times(1f / accelDataLength[0]).abs();
        }

        for (int i = 0; i < fftData2.length; i++) {
            absData2[i] = fftData2[i].times(1f / accelDataLength[1]).abs();
        }

        for (int i = 0; i < fftData3.length; i++) {
            absData3[i] = fftData3[i].times(1f / accelDataLength[2]).abs();
        }

        for (int i = 0; i < fftData4.length; i++) {
            absData4[i] = fftData4[i].times(1f / accelDataLength[3]).abs();
        }

        //retData.setAbsData(absData3);

        double[] halfData1 = new double[accelDataLength[0] / 2 + 1];
        double[] halfData2 = new double[accelDataLength[1] / 2 + 1];
        double[] halfData3 = new double[accelDataLength[2] / 2 + 1];
        double[] halfData4 = new double[accelDataLength[3] / 2 + 1];


        for (int i = 0; i < halfData1.length; i++) {
            if (i != 0 && i != halfData1.length - 1)
                halfData1[i] = absData1[i] * 2;
            else
                halfData1[i] = absData1[i];
        }

        for (int i = 0; i < halfData2.length; i++) {
            if (i != 0 && i != halfData2.length - 1)
                halfData2[i] = absData2[i] * 2;
            else
                halfData2[i] = absData2[i];
        }

        for (int i = 0; i < halfData3.length; i++) {
            if (i != 0 && i != halfData3.length - 1)
                halfData3[i] = absData3[i] * 2;
            else
                halfData3[i] = absData3[i];
        }

        for (int i = 0; i < halfData4.length; i++) {
            if (i != 0 && i != halfData4.length - 1)
                halfData4[i] = absData4[i] * 2;
            else
                halfData4[i] = absData4[i];
        }

        //retData.setHalfData(halfData3);

        double[] fData1 = new double[accelDataLength[0] / 2];
        double[] fData2 = new double[accelDataLength[1] / 2];
        double[] fData3 = new double[accelDataLength[2] / 2];
        double[] fData4 = new double[accelDataLength[3] / 2];

        for (int i = 0; i < fData1.length; i++) {
            fData1[i] = fs * i / accelDataLength[0];
        }

        for (int i = 0; i < fData2.length; i++) {
            fData2[i] = fs * i / accelDataLength[1];
        }

        for (int i = 0; i < fData3.length; i++) {
            fData3[i] = fs * i / accelDataLength[2];
        }

        for (int i = 0; i < fData4.length; i++) {
            fData4[i] = fs * i / accelDataLength[3];
        }

        //retData.setfData(fData3);

        double actualHz1 = halfData1[1];
        double actualHz2 = halfData2[1];
        double actualHz3 = halfData3[1];
        double actualHz4 = halfData4[1];
        int index;

        index = 1;
        for (int i = 2; i < halfData1.length; i++) {
            if (actualHz1 < halfData1[i]) {
                index = i;
                actualHz1 = halfData1[i];
            }
        }

        actualHz1 = fData1[index];

        index = 1;
        for (int i = 2; i < halfData2.length; i++) {
            if (actualHz2 < halfData2[i]) {
                index = i;
                actualHz2 = halfData2[i];
            }
        }

        actualHz2 = fData2[index];

        index = 1;
        for (int i = 2; i < halfData3.length; i++) {
            if (actualHz3 < halfData3[i]) {
                index = i;
                actualHz3 = halfData3[i];
            }
        }

        actualHz3 = fData3[index];

        index = 1;
        for (int i = 2; i < halfData4.length; i++) {
            if (actualHz4 < halfData4[i]) {
                index = i;
                actualHz4 = halfData4[i];
            }
        }

        actualHz4 = fData4[index];

        //retData.setActualHz(actualHz3);

        double[] sumActual1 = {0f, 0f, 0f};
        double[] sumActual2 = {0f, 0f, 0f};
        double[] sumActual3 = {0f, 0f, 0f};
        double[] sumActual4 = {0f, 0f, 0f};

        for (int i = 0; i < accelDataLength[0]; i++) {
            for (int j = 0; j < 3; j++)
                sumActual1[j] = sumActual1[j] + dataR1[i][j];
        }

        for (int i = 0; i < accelDataLength[1]; i++) {
            for (int j = 0; j < 3; j++)
                sumActual2[j] = sumActual2[j] + dataR2[i][j];
        }

        for (int i = 0; i < accelDataLength[2]; i++) {
            for (int j = 0; j < 3; j++)
                sumActual3[j] = sumActual3[j] + dataR3[i][j];
        }

        for (int i = 0; i < accelDataLength[3]; i++) {
            for (int j = 0; j < 3; j++)
                sumActual4[j] = sumActual4[j] + dataR4[i][j];
        }

        double[] avg1 = {0f, 0f, 0f};
        double[] avg2 = {0f, 0f, 0f};
        double[] avg3 = {0f, 0f, 0f};
        double[] avg4 = {0f, 0f, 0f};

        for (int i = 0; i < 3; i++) {
            avg1[i] = sumActual1[i] / accelDataLength[0];
            avg2[i] = sumActual2[i] / accelDataLength[1];
            avg3[i] = sumActual3[i] / accelDataLength[2];
            avg4[i] = sumActual4[i] / accelDataLength[3];
        }

        double[] xyz = {0f, 0f, 0f};

        for (int i = 0; i < 3; i++) {
            xyz[i] = (avg1[i] + avg2[i] + avg3[i]) / 3;
        }

        xyz[2] = xyz[2] - 1;

        double actualg1 = sumActual1[2] / accelDataLength[0];
        double actualg2 = sumActual2[2] / accelDataLength[1];
        double actualg3 = sumActual3[2] / accelDataLength[2];
        double actualg4 = 0f;

        for (int i = 0; i < accelDataLength[3]; i++) {
            actualg4 = actualg4 + (dataR4[i][2] - xyz[2]);
        }

        actualg4 = actualg4 / accelDataLength[3];

        String path = GenerateReport.generatePDFReport(new double[] {actualHz1, actualHz2, actualHz3}, new double[] {actualg1, actualg2, actualg3}, xyz, actualHz4, actualg4);

        retData.setAccelFileName(path);

        return retData;
    }

    /////////////// Calibration Data End ////////////////


}
