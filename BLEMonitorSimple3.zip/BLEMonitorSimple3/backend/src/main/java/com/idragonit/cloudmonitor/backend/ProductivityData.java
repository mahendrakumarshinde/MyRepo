package com.idragonit.cloudmonitor.backend;

import java.util.ArrayList;

/**
 * Created by idragon on 2/26/16.
 */
public class ProductivityData {

    private String macAddress;
    private Long totalTime = 0L;
    private ArrayList<ProductivityInfo> infos = new ArrayList<ProductivityInfo>();
    private String timeLabel;
    private String machineName;

    public String getMachineName() {
        return machineName;
    }

    public void setMachineName(String machineName) {
        this.machineName = machineName;

        if (this.machineName == null)
            this.machineName = macAddress;
    }

    public String getMacAddress() {
        return macAddress;
    }

    public void setMacAddress(String macAddress) {
        this.macAddress = macAddress;
    }

    public Long getTotalTime() {
        return totalTime;
    }

    public void setTotalTime(Long time) {
        totalTime = time;
    }

    public ArrayList<ProductivityInfo> getProductivityInfo() {
        return infos;
    }

    public void addProductivityInfo(ProductivityInfo info) {
        infos.add(info);
    }

    public String getTimeLabel() {
        return timeLabel;
    }

    public void setTimeLabel(String label) {
        this.timeLabel = label;
    }
}
