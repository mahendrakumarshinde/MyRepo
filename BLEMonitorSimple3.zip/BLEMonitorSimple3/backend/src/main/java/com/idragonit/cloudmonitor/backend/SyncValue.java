package com.idragonit.cloudmonitor.backend;

/**
 * Created by idragon on 2/26/16.
 */
public class SyncValue {
    private Integer reset_value;

    public Integer getResetValue() {
        return reset_value;
    }

    public void setResetValue(Integer value) {
        reset_value = value;
    }

}
