package com.idragonit.cloudmonitor.backend;

import java.util.ArrayList;
import java.util.List;

/** The object model for the data we are sending through endpoints */
public class MachineInfo {

    private String macAddress;

    private Integer state = 4;
    private Integer batteryState = 0;
    private Float stateIdle = 0F;
    private Float stateNormal = 0F;
    private Float stateWarning = 0F;
    private Float stateDanger = 0F;

    private Long durationIdle = 0L;
    private Long durationNormal = 0L;
    private Long durationWarning = 0L;
    private Long durationDanger = 0L;

    private String startTime;
    private String endTime;

    private String machineName;

    private Long totalLastCount = 0L;
    private Long totalBeforeCount = 0L;
    private Long productivityTrend = 0L;

    private ArrayList<ProductivityInfo> infos = new ArrayList<ProductivityInfo>();
    private List<ToolInfo> toolInfos = new ArrayList<ToolInfo>();

    public List<ToolInfo> getToolInfos() {
        return toolInfos;
    }

    public void setToolInfos(List<ToolInfo> toolInfos) {
        this.toolInfos = toolInfos;
    }

    public Long getProductivityTrend() {
        return productivityTrend;
    }

    public void setProductivityTrend(Long productivityTrend) {
        this.productivityTrend = productivityTrend;
    }

    public Long getTotalBeforeCount() {
        return totalBeforeCount;
    }

    public void setTotalBeforeCount(Long totalBeforeCount) {
        this.totalBeforeCount = totalBeforeCount;
    }

    public Long getTotalLastCount() {
        return totalLastCount;
    }

    public void setTotalLastCount(Long totalLastCount) {
        this.totalLastCount = totalLastCount;
    }

    public String getMachineName() {
        return machineName;
    }

    public void setMachineName(String machineName) {
        this.machineName = machineName;

        if (this.machineName == null)
            this.machineName = macAddress;
    }

    public String getMacAddress() {
        return macAddress;
    }

    public void setMacAddress(String macAddress) {
        this.macAddress = macAddress;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String time) {
        startTime = time;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String time) {
        endTime = time;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer value) {
        state = value;
    }

    public Integer getBatteryState() {
        return batteryState;
    }

    public void setBatteryState(Integer value) {
        batteryState = value;
    }

    public Float getStateIdle() {
        return stateIdle;
    }

    public void setStateIdle(Float value) {
        stateIdle = value;
    }

    public Float getStateNormal() {
        return stateNormal;
    }

    public void setStateNormal(Float value) {
        stateNormal = value;
    }

    public Float getStateWarning() {
        return stateWarning;
    }

    public void setStateWarning(Float value) {
        stateWarning = value;
    }

    public Float getStateDanger() {
        return stateDanger;
    }

    public void setStateDanger(Float value) {
        stateDanger = value;
    }

    public Long getDurationIdle() {
        return durationIdle;
    }

    public void setDurationIdle(Long value) {
        durationIdle = value;
    }

    public Long getDurationNormal() {
        return durationNormal;
    }

    public void setDurationNormal(Long value) {
        durationNormal = value;
    }

    public Long getDurationWarning() {
        return durationWarning;
    }

    public void setDurationWarning(Long value) {
        durationWarning = value;
    }

    public Long getDurationDanger() {
        return durationDanger;
    }

    public void setDurationDanger(Long value) {
        durationDanger = value;
    }

    public ArrayList<ProductivityInfo> getProductivityInfo() {
        return infos;
    }

    public void addProductivityInfo(ProductivityInfo info) {
        infos.add(info);
    }
}