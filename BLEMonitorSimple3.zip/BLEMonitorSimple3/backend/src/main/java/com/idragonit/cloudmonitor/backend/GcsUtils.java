package com.idragonit.cloudmonitor.backend;

import com.google.appengine.repackaged.com.google.common.collect.ImmutableList;
import com.google.cloud.storage.Acl;
import com.google.cloud.storage.Acl.User;
import com.google.cloud.storage.Blob;
import com.google.cloud.storage.BlobId;
import com.google.cloud.storage.BlobInfo;
import com.google.cloud.storage.Storage;
import com.google.cloud.storage.StorageOptions;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.channels.Channels;
import java.util.List;

import javax.annotation.Nullable;

import static com.google.cloud.storage.Acl.Role.READER;

public class GcsUtils {

    private static final List<Acl> ACL = ImmutableList.of(
            Acl.of(User.ofAllUsers(), READER));

    @Nullable
    public static byte[] read(String bucket, String filename) {
        Storage storage = StorageOptions.defaultInstance().service();
        BlobId blobId = BlobId.of(bucket, filename);
        Blob blob = storage.get(blobId);
        if (blob != null) {
            return blob.content();
        }
        return null;
    }

    @Nullable
    public static InputStream inputStream(String bucket, String filename) {
        Storage storage = StorageOptions.defaultInstance().service();
        BlobId blobId = BlobId.of(bucket, filename);
        Blob blob = storage.get(blobId);
        if (blob != null) {
            return Channels.newInputStream(blob.reader());
        }
        return null;
    }

    @Nullable
    public static String mediaLink(String bucket, String filename) {
        Storage storage = StorageOptions.defaultInstance().service();
        BlobId blobId = BlobId.of(bucket, filename);
        Blob blob = storage.get(blobId);
        if (blob != null) {
            return blob.mediaLink();
            //return blob.selfLink();
        }
        return null;
    }

    @Nullable
    public static BufferedReader bufferedReader(String bucket, String filename) {
        InputStream inputStream = inputStream(bucket, filename);
        if (inputStream != null) {
            return new BufferedReader(new InputStreamReader(inputStream));
        }
        return null;
    }

    @Nullable
    public static OutputStream outputStream(String bucket, String filename) {
        Storage storage = StorageOptions.defaultInstance().service();
        BlobId blobId = BlobId.of(bucket, filename);
        BlobInfo blobInfo = BlobInfo.builder(blobId).contentType("application/pdf").acl(ACL).build();
        Blob blob = storage.create(blobInfo);
        if (blob != null) {
            return Channels.newOutputStream(blob.writer());
        }
        return null;
    }

    @Nullable
    public static BufferedWriter bufferedWriter(String bucket, String filename) {
        OutputStream outputStream = outputStream(bucket, filename);
        if (outputStream != null) {
            return new BufferedWriter(new OutputStreamWriter(outputStream));
        }
        return null;
    }

}