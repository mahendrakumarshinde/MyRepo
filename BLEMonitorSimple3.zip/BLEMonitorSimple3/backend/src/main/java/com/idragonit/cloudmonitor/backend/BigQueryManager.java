package com.idragonit.cloudmonitor.backend;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.bigquery.Bigquery;
import com.google.api.services.bigquery.BigqueryScopes;
import com.google.api.services.bigquery.model.Dataset;
import com.google.api.services.bigquery.model.DatasetReference;
import com.google.api.services.bigquery.model.GetQueryResultsResponse;
import com.google.api.services.bigquery.model.QueryRequest;
import com.google.api.services.bigquery.model.QueryResponse;
import com.google.api.services.bigquery.model.Table;
import com.google.api.services.bigquery.model.TableFieldSchema;
import com.google.api.services.bigquery.model.TableReference;
import com.google.api.services.bigquery.model.TableRow;
import com.google.api.services.bigquery.model.TableSchema;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by idragon on 2/26/16.
 */
public class BigQueryManager {

    /**
     * Creates an authorized Bigquery client service using Application Default Credentials.
     *
     * @return an authorized Bigquery client
     * @throws IOException if there's an error getting the default credentials.
     */
    public static Bigquery createAuthorizedClient() throws IOException {
        // Create the credential
        HttpTransport transport = new NetHttpTransport();
        JsonFactory jsonFactory = new JacksonFactory();
        GoogleCredential credential = GoogleCredential.getApplicationDefault(transport, jsonFactory);

        // Depending on the environment that provides the default credentials (e.g. Compute Engine, App
        // Engine), the credentials may require us to specify the scopes we need explicitly.
        // Check for this case, and inject the Bigquery scope if required.
        if (credential.createScopedRequired()) {
            credential = credential.createScoped(BigqueryScopes.all());
        }

        return new Bigquery.Builder(transport, jsonFactory, credential)
                .setApplicationName("Infinite Uptime").build();
    }

    /**
     * Executes the given query synchronously.
     *
     * @param querySql the query to execute.
     * @param bigquery the Bigquery service object.
     * @param projectId the id of the project under which to run the query.
     * @return a list of the results of the query.
     * @throws IOException if there's an error communicating with the API.
     */
    public static List<TableRow> executeQuery(String querySql, Bigquery bigquery, String projectId)
            throws IOException {
        QueryResponse query = bigquery.jobs().query(
                projectId,
                new QueryRequest().setQuery(querySql))
                .execute();

        // Execute it
        GetQueryResultsResponse queryResult = bigquery.jobs().getQueryResults(
                query.getJobReference().getProjectId(),
                query.getJobReference().getJobId()).execute();

        return queryResult.getRows();
    }

    public static boolean createDataset(String dbName) throws IOException {
        Bigquery bigQuery = createAuthorizedClient();

        ///////////// Create Dataset //////////////
        Dataset dataset = new Dataset();
        DatasetReference datasetRef = new DatasetReference();
        datasetRef.setProjectId(MyEndpoint.gProjectID);
        datasetRef.setDatasetId(dbName);
        dataset.setDatasetReference(datasetRef);
        bigQuery.datasets().insert(MyEndpoint.gProjectID, dataset).execute();

        ///////////// Create IU_device_data Table //////////////
        TableSchema schema = new TableSchema();
        List<TableFieldSchema> tableFieldSchema = new ArrayList<TableFieldSchema>();

        ///////////// Add Fields //////////////
        TableFieldSchema schemaEntry = new TableFieldSchema();
        schemaEntry.setName("Id");
        schemaEntry.setType("INTEGER");
        tableFieldSchema.add(schemaEntry);

        schemaEntry = new TableFieldSchema();
        schemaEntry.setName("Timestamp_Pi");
        schemaEntry.setType("STRING");
        tableFieldSchema.add(schemaEntry);

        schemaEntry = new TableFieldSchema();
        schemaEntry.setName("Timestamp");
        schemaEntry.setType("INTEGER");
        tableFieldSchema.add(schemaEntry);

        schemaEntry = new TableFieldSchema();
        schemaEntry.setName("MAC_ADDRESS");
        schemaEntry.setType("STRING");
        tableFieldSchema.add(schemaEntry);

        schemaEntry = new TableFieldSchema();
        schemaEntry.setName("Tool_ID");
        schemaEntry.setType("INTEGER");
        tableFieldSchema.add(schemaEntry);

        schemaEntry = new TableFieldSchema();
        schemaEntry.setName("State");
        schemaEntry.setType("INTEGER");
        tableFieldSchema.add(schemaEntry);

        schemaEntry = new TableFieldSchema();
        schemaEntry.setName("Battery_Level");
        schemaEntry.setType("FLOAT");
        tableFieldSchema.add(schemaEntry);

        schemaEntry = new TableFieldSchema();
        schemaEntry.setName("Feature_Value_0");
        schemaEntry.setType("FLOAT");
        tableFieldSchema.add(schemaEntry);

        schemaEntry = new TableFieldSchema();
        schemaEntry.setName("Feature_Value_1");
        schemaEntry.setType("FLOAT");
        tableFieldSchema.add(schemaEntry);

        schemaEntry = new TableFieldSchema();
        schemaEntry.setName("Feature_Value_2");
        schemaEntry.setType("FLOAT");
        tableFieldSchema.add(schemaEntry);

        schemaEntry = new TableFieldSchema();
        schemaEntry.setName("Feature_Value_3");
        schemaEntry.setType("FLOAT");
        tableFieldSchema.add(schemaEntry);

        schemaEntry = new TableFieldSchema();
        schemaEntry.setName("Feature_Value_4");
        schemaEntry.setType("FLOAT");
        tableFieldSchema.add(schemaEntry);

        schemaEntry = new TableFieldSchema();
        schemaEntry.setName("Feature_Value_5");
        schemaEntry.setType("FLOAT");
        tableFieldSchema.add(schemaEntry);

        schema.setFields(tableFieldSchema);

        Table table = new Table();
        table.setSchema(schema);
        TableReference tableRef = new TableReference();
        tableRef.setDatasetId(dbName);
        tableRef.setProjectId(MyEndpoint.gProjectID);
        tableRef.setTableId("IU_device_data");
        table.setTableReference(tableRef);

        bigQuery.tables().insert(MyEndpoint.gProjectID, dbName, table).execute();

        ///////////// Create IU_device_duration_data Table //////////////
        schema = new TableSchema();
        tableFieldSchema = new ArrayList<TableFieldSchema>();

        ///////////// Add Fields //////////////
        schemaEntry = new TableFieldSchema();
        schemaEntry.setName("Id");
        schemaEntry.setType("INTEGER");
        tableFieldSchema.add(schemaEntry);

        schemaEntry = new TableFieldSchema();
        schemaEntry.setName("Timestamp_Pi");
        schemaEntry.setType("STRING");
        tableFieldSchema.add(schemaEntry);

        schemaEntry = new TableFieldSchema();
        schemaEntry.setName("Row_Duration");
        schemaEntry.setType("INTEGER");
        tableFieldSchema.add(schemaEntry);

        schemaEntry = new TableFieldSchema();
        schemaEntry.setName("MAC_ADDRESS");
        schemaEntry.setType("STRING");
        tableFieldSchema.add(schemaEntry);

        schemaEntry = new TableFieldSchema();
        schemaEntry.setName("Tool_ID");
        schemaEntry.setType("INTEGER");
        tableFieldSchema.add(schemaEntry);

        schemaEntry = new TableFieldSchema();
        schemaEntry.setName("State");
        schemaEntry.setType("INTEGER");
        tableFieldSchema.add(schemaEntry);

        schema.setFields(tableFieldSchema);

        table = new Table();
        table.setSchema(schema);
        tableRef = new TableReference();
        tableRef.setDatasetId(dbName);
        tableRef.setProjectId(MyEndpoint.gProjectID);
        tableRef.setTableId("IU_device_duration_data");
        table.setTableReference(tableRef);

        bigQuery.tables().insert(MyEndpoint.gProjectID, dbName, table).execute();

        ///////////// Create Controller_Data Table //////////////
        schema = new TableSchema();
        tableFieldSchema = new ArrayList<TableFieldSchema>();

        ///////////// Add Fields //////////////
        schemaEntry = new TableFieldSchema();
        schemaEntry.setName("Id");
        schemaEntry.setType("INTEGER");
        tableFieldSchema.add(schemaEntry);

        schemaEntry = new TableFieldSchema();
        schemaEntry.setName("MAC_ADDRESS");
        schemaEntry.setType("STRING");
        tableFieldSchema.add(schemaEntry);

        schemaEntry = new TableFieldSchema();
        schemaEntry.setName("Timestamp");
        schemaEntry.setType("STRING");
        tableFieldSchema.add(schemaEntry);

        schemaEntry = new TableFieldSchema();
        schemaEntry.setName("Tool_ID");
        schemaEntry.setType("INTEGER");
        tableFieldSchema.add(schemaEntry);

        schemaEntry = new TableFieldSchema();
        schemaEntry.setName("Block");
        schemaEntry.setType("STRING");
        tableFieldSchema.add(schemaEntry);

        schemaEntry = new TableFieldSchema();
        schemaEntry.setName("Execution");
        schemaEntry.setType("STRING");
        tableFieldSchema.add(schemaEntry);

        schema.setFields(tableFieldSchema);

        table = new Table();
        table.setSchema(schema);
        tableRef = new TableReference();
        tableRef.setDatasetId(dbName);
        tableRef.setProjectId(MyEndpoint.gProjectID);
        tableRef.setTableId("Controller_Data");
        table.setTableReference(tableRef);

        bigQuery.tables().insert(MyEndpoint.gProjectID, dbName, table).execute();

        return true;
    }

    public static boolean createControllerTable(String dbName) throws IOException {
        Bigquery bigQuery = createAuthorizedClient();

        ///////////// Create Controller_Data Table //////////////
        TableSchema schema = new TableSchema();
        List<TableFieldSchema> tableFieldSchema = new ArrayList<TableFieldSchema>();

        ///////////// Add Fields //////////////
        TableFieldSchema schemaEntry = new TableFieldSchema();
        schemaEntry.setName("Id");
        schemaEntry.setType("INTEGER");
        tableFieldSchema.add(schemaEntry);

        schemaEntry = new TableFieldSchema();
        schemaEntry.setName("MAC_ADDRESS");
        schemaEntry.setType("STRING");
        tableFieldSchema.add(schemaEntry);

        schemaEntry = new TableFieldSchema();
        schemaEntry.setName("Timestamp");
        schemaEntry.setType("STRING");
        tableFieldSchema.add(schemaEntry);

        schemaEntry = new TableFieldSchema();
        schemaEntry.setName("Tool_ID");
        schemaEntry.setType("INTEGER");
        tableFieldSchema.add(schemaEntry);

        schemaEntry = new TableFieldSchema();
        schemaEntry.setName("Block");
        schemaEntry.setType("STRING");
        tableFieldSchema.add(schemaEntry);

        schemaEntry = new TableFieldSchema();
        schemaEntry.setName("Execution");
        schemaEntry.setType("STRING");
        tableFieldSchema.add(schemaEntry);

        schema.setFields(tableFieldSchema);

        Table table = new Table();
        table.setSchema(schema);
        TableReference tableRef = new TableReference();
        tableRef.setDatasetId(dbName);
        tableRef.setProjectId(MyEndpoint.gProjectID);
        tableRef.setTableId("Controller_Data");
        table.setTableReference(tableRef);

        bigQuery.tables().insert(MyEndpoint.gProjectID, dbName, table).execute();

        return true;
    }
}
