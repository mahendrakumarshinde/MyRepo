package com.idragonit.cloudmonitor.backend;

import java.util.ArrayList;

/**
 * Created by idragon on 2/26/16.
 */
public class DailyPerformanceData {

    private Integer maxRedCount = 0;
    private Integer redCount = 0;

    private Float stateIdle = 0F;
    private Float stateNormal = 0F;
    private Float stateWarning = 0F;
    private Float stateDanger = 0F;

    private Long durationIdle = 0L;
    private Long durationNormal = 0L;
    private Long durationWarning = 0L;
    private Long durationDanger = 0L;

    private String startTime;

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    private String endTime;

    private ArrayList<ProductivityInfo> infos = new ArrayList<ProductivityInfo>();

    public Integer getMaxRedCount() {
        return maxRedCount;
    }

    public void setMaxRedCount(Integer value) {
        maxRedCount = value;
    }

    public Integer getRedCount() {
        return redCount;
    }

    public void setRedCount(Integer value) {
        redCount = value;
    }

    public Float getStateIdle() {
        return stateIdle;
    }

    public void setStateIdle(Float value) {
        stateIdle = value;
    }

    public Float getStateNormal() {
        return stateNormal;
    }

    public void setStateNormal(Float stateNormal) {
        this.stateNormal = stateNormal;
    }

    public ArrayList<ProductivityInfo> getInfos() {
        return infos;
    }

    public void setInfos(ArrayList<ProductivityInfo> infos) {
        this.infos = infos;
    }

    public Float getStateWarning() {
        return stateWarning;
    }

    public void setStateWarning(Float value) {
        stateWarning = value;
    }

    public Float getStateDanger() {
        return stateDanger;
    }

    public void setStateDanger(Float value) {
        stateDanger = value;
    }

    public Long getDurationIdle() {
        return durationIdle;
    }

    public void setDurationIdle(Long value) {
        durationIdle = value;
    }

    public Long getDurationNormal() {
        return durationNormal;
    }

    public void setDurationNormal(Long value) {
        durationNormal = value;
    }

    public Long getDurationWarning() {
        return durationWarning;
    }

    public void setDurationWarning(Long value) {
        durationWarning = value;
    }

    public Long getDurationDanger() {
        return durationDanger;
    }

    public void setDurationDanger(Long value) {
        durationDanger = value;
    }

    public ArrayList<ProductivityInfo> getProductivityInfo() {
        return infos;
    }

    public void addProductivityInfo(ProductivityInfo info) {
        infos.add(info);
    }
}
