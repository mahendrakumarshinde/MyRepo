package com.idragonit.cloudmonitor.backend;

/** The object model for the data we are sending through endpoints */
public class ProductivityInfo {

    private Integer state;
    private Long startTime;
    private Long endTime;
    private Long duration;
    private String timeLabel;

    private String startTimePi;
    private String endTimePi;

    public Integer getState() {
        return state;
    }

    public void setState(Integer value) {
        state = value;
    }

    public Long getStartTime() {
        return startTime;
    }

    public void setStartTime(Long value) {
        startTime = value;
    }

    public Long getEndTime() {
        return endTime;
    }

    public void setEndTime(Long value) {
        endTime = value;
        duration = endTime - startTime;

        if (duration < 0L)
            duration = 0L;
    }

    public Long getDuration() {
        return duration;
    }

    public void setDuration(Long value) {
        duration = value;
    }

    public String getTimeLabel() {
        return timeLabel;
    }

    public void setTimeLabel(String label) {
        this.timeLabel = label;
    }

    public String getStartTimePi() {
        return startTimePi;
    }

    public void setStartTimePi(String time) {
        this.startTimePi = time;
    }

    public String getEndTimePi() {
        return endTimePi;
    }
    public void setEndTimePi(String time) {
        this.endTimePi = time;
    }
}