package com.idragonit.cloudmonitor.backend;

import java.util.ArrayList;

/**
 * Created by idragon on 2/26/16.
 */
public class DatabaseName {

    private String id;
    private ArrayList<String> dbNameList;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public ArrayList<String> getDbNameList() {
        return dbNameList;
    }

    public void setDbNameList(ArrayList<String> dbNameList) {
        this.dbNameList = dbNameList;
    }
}
