package com.idragonit.cloudmonitor.backend;

/**
 * Created by idragon on 2/26/16.
 */
public class CalibrationStatus {

    private Integer id;
    private String timestamp;
    private String device_id;
    private String port_num;
    private Integer testing_cycle;
    private Integer status;
    private String status_msg;
    private Integer audioId;
    private Integer accelId;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getDevice_id() {
        return device_id;
    }

    public void setDevice_id(String device_id) {
        this.device_id = device_id;
    }

    public String getPort_num() {
        return port_num;
    }

    public void setPort_num(String port_num) {
        this.port_num = port_num;
    }

    public Integer getTesting_cycle() {
        return testing_cycle;
    }

    public void setTesting_cycle(Integer testing_cycle) {
        this.testing_cycle = testing_cycle;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getStatus_msg() {
        return status_msg;
    }

    public void setStatus_msg(String status_msg) {
        this.status_msg = status_msg;
    }

    public Integer getAudioId() {
        return audioId;
    }

    public void setAudioId(Integer audioId) {
        this.audioId = audioId;
    }

    public Integer getAccelId() {
        return accelId;
    }

    public void setAccelId(Integer accelId) {
        this.accelId = accelId;
    }
}
