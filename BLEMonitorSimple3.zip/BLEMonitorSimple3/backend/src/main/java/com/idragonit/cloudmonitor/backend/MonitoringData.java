package com.idragonit.cloudmonitor.backend;

import java.util.ArrayList;

/**
 * Created by idragon on 2/26/16.
 */
public class MonitoringData {

    private FeatureDictionary featureDictionary = new FeatureDictionary();
    private ArrayList<FeatureInfo> infos = new ArrayList<FeatureInfo>();
    private Float maxValue = 0F;
    private Float minValue = 0F;

    public FeatureDictionary getFeatureDictionary() {
        return featureDictionary;
    }

    public void setFeatureDictionary(FeatureDictionary featureDictionary) {
        this.featureDictionary = featureDictionary;
    }

    public ArrayList<FeatureInfo> getFeatureInfo() {
        return infos;
    }

    public void addFeatureInfo(FeatureInfo info) {
        infos.add(info);
    }

    public Float getMaxValue() {
        return maxValue;
    }

    public void setMaxValue(Float value) {
        this.maxValue = value;
    }

    public Float getMinValue() {
        return minValue;
    }

    public void setMinValue(Float value) {
        this.minValue = value;
    }
}
