package com.idragonit.cloudmonitor.backend;

import com.google.appengine.repackaged.com.google.api.client.util.Base64;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Utils {

	public static long convertDateToMilliseconds(String strDate) {
		SimpleDateFormat fmt;
		if (strDate.length() == 10)
			fmt = new SimpleDateFormat("yyyy-MM-dd");
		else if (strDate.length() == 19)
			fmt = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		else if (strDate.length() == 21)
			fmt = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.S");
		else if (strDate.length() == 22)
			fmt = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SS");
		else if (strDate.length() == 23)
			fmt = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS");
		else if (strDate.length() > 23) {
			strDate = strDate.substring(0, 23);
			fmt = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS");
		}
		else
			return -1L;

		Date date = null;

		try {
			date = fmt.parse(strDate);
			return date.getTime();
		} catch (ParseException e) {
			e.printStackTrace();
		}

		return -1L;
	}

	public static String convertTimeToString(long milliseconds) {
		milliseconds = milliseconds / 1000L;

		if (milliseconds < 60) {
			if (milliseconds <= 1)
				return milliseconds + " sec";
			else
				return milliseconds + " secs";
		}
		else if (milliseconds < 3600) {
			if ((milliseconds / 60) <= 1)
				return (milliseconds / 60) + " min";
			else
				return (milliseconds / 60) + " mins";
		}
		else if (milliseconds < 3600 * 24) {
			if ((milliseconds / 3600) <= 1)
				return (milliseconds / 3600) + " hr";
			else
				return (milliseconds / 3600) + " hrs";
		}

		if ((milliseconds / 3660 / 24) <= 1)
			return (milliseconds / 3660 / 24) + " day";

		return (milliseconds / 3660 / 24) + " days";
	}

	public static int getDayIndex(long milliseconds, long curMillisec) {
		long step = milliseconds - curMillisec;
		int index = 6 - (int) (step / 1000 / 3600 / 24);

		if (index < 0)
			index = 0;
		if (index > 6)
			index = 6;

		return index;
	}

	public static int getTimeIndex(long milliseconds, long curMillisec) {
		long step = milliseconds - curMillisec;
		int index = 11 - (int) (step / 1000 / 3600 / 2);

		if (index < 0)
			index = 0;
		if (index > 11)
			index = 11;

		return index;
	}

	public static int getDayIndexByDaily(long milliseconds, long curMillisec) {
		long step = milliseconds - curMillisec;
		int index = 24 - (int) (step / 1000 / 3600 / 24);

		if (index < 0)
			index = 0;
		if (index > 24)
			index = 24;

		return index;
	}

	public static String encodeDBName(String name) {
		byte[] bytesEncoded = Base64.encodeBase64(name.getBytes());
		return new String(bytesEncoded);
	}

	public static String decodeDBName(String name) {
		byte[] valueDecoded= Base64.decodeBase64(name);
		return new String(valueDecoded);
	}
}
