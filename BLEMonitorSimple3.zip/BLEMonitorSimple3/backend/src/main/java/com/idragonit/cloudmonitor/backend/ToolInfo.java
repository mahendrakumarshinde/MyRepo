package com.idragonit.cloudmonitor.backend;

import java.util.ArrayList;

/**
 * Created by idragon on 2/26/16.
 */
public class ToolInfo {

    private Integer toolID;
    private Integer toolStatus;
    private String toolName;
    private Integer totalLastCount = 0;

    private Float stateIdle = 0F;
    private Float stateNormal = 0F;
    private Float stateWarning = 0F;
    private Float stateDanger = 0F;

    private Long durationIdle = 0L;
    private Long durationNormal = 0L;
    private Long durationWarning = 0L;
    private Long durationDanger = 0L;

    private String startTime;
    private String endTime;

    private Integer productivityTrend = 0;

    private ArrayList<ProductivityInfo> infos = new ArrayList<ProductivityInfo>();

    public Integer getToolID() {
        return toolID;
    }

    public void setToolID(Integer toolID) {
        this.toolID = toolID;
    }

    public Integer getToolStatus() {
        return toolStatus;
    }

    public void setToolStatus(Integer toolStatus) {
        this.toolStatus = toolStatus;
    }

    public String getToolName() {
        return toolName;
    }

    public void setToolName(String toolName) {
        if (toolName == null)
            this.toolName = "Tool #" + toolID;
        else
            this.toolName = toolName;
    }

    public Integer getTotalLastCount() {
        return totalLastCount;
    }

    public void setTotalLastCount(Integer totalLastCount) {
        this.totalLastCount = totalLastCount;
    }

    public Float getStateIdle() {
        return stateIdle;
    }

    public void setStateIdle(Float stateIdle) {
        this.stateIdle = stateIdle;
    }

    public Float getStateNormal() {
        return stateNormal;
    }

    public void setStateNormal(Float stateNormal) {
        this.stateNormal = stateNormal;
    }

    public Float getStateWarning() {
        return stateWarning;
    }

    public void setStateWarning(Float stateWarning) {
        this.stateWarning = stateWarning;
    }

    public Float getStateDanger() {
        return stateDanger;
    }

    public void setStateDanger(Float stateDanger) {
        this.stateDanger = stateDanger;
    }

    public Long getDurationIdle() {
        return durationIdle;
    }

    public void setDurationIdle(Long durationIdle) {
        this.durationIdle = durationIdle;
    }

    public Long getDurationNormal() {
        return durationNormal;
    }

    public void setDurationNormal(Long durationNormal) {
        this.durationNormal = durationNormal;
    }

    public Long getDurationWarning() {
        return durationWarning;
    }

    public void setDurationWarning(Long durationWarning) {
        this.durationWarning = durationWarning;
    }

    public Long getDurationDanger() {
        return durationDanger;
    }

    public void setDurationDanger(Long durationDanger) {
        this.durationDanger = durationDanger;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public Integer getProductivityTrend() {
        return productivityTrend;
    }

    public void setProductivityTrend(Integer productivityTrend) {
        this.productivityTrend = productivityTrend;
    }

    public ArrayList<ProductivityInfo> getProductivityInfo() {
        return infos;
    }

    public void addProductivityInfo(ProductivityInfo info) {
        infos.add(info);
    }
}
