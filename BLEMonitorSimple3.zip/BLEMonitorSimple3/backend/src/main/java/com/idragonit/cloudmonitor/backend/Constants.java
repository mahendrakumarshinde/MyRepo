package com.idragonit.cloudmonitor.backend;

/**
 * Define all constant.
 *  
 * @author CJH
 *
 */

public class Constants {
	
	public static final String ERROR_CODE = "errCode";
	public static final String ERROR_MSG = "errMsg";

	public static final int ACTION_SUCCESS = 0;
	public static final int ACTION_FAILED = 1;
	

	public enum ResponseStatus {
		
		SUCCESS(0, "Success"),
		FAILED(1, "Failed"),
		
		BAD_REQUEST(-3, "Bad Request"),
		
		INVALID_SOURCE(10, "Invalid Source"),
		INVALID_LIMIT_NUMBER(11, "Invalid Limit Number"),
		INVALID_LATEST_HOUR(12, "Invalid Latest Hour"),

		INVALID_NEWS(20, "Invalid News"),

		;
		
		private int code;
		private String msg;
		
		private ResponseStatus(final int code, final String msg){
			this.code = code;
			this.msg = msg;
		}
		
		public int code(){
			return code;
		}
		
		public String msg(){
			return msg;
		}		
	};
	
}
