package com.idragonit.cloudmonitor.backend;

/**
 * Created by idragon on 2/26/16.
 */
public class FileData {

    private String audioFileName;
    private long audioFileSize;
    private String audioFileData;

    private String accelFileName;
    private long accelFileSize;
    private String accelFileData;

    private double[][] orgdata;
    private double[] sqrData;
    private String[] fftDataOrg;
    private String[] fftData;
    private double[] absData;
    private double[] halfData;
    private double[] fData;
    private double actualHz;

    private int dataCount1;
    private int fftCount1;
    private int dataCount2;
    private int fftCount2;
    private int dataCount3;
    private int fftCount3;
    private int dataCount4;
    private int fftCount4;

    public String getAudioFileName() {
        return audioFileName;
    }

    public void setAudioFileName(String audioFileName) {
        this.audioFileName = audioFileName;
    }

    public long getAudioFileSize() {
        return audioFileSize;
    }

    public void setAudioFileSize(long audioFileSize) {
        this.audioFileSize = audioFileSize;
    }

    public String getAccelFileName() {
        return accelFileName;
    }

    public void setAccelFileName(String accelFileName) {
        this.accelFileName = accelFileName;
    }

    public long getAccelFileSize() {
        return accelFileSize;
    }

    public void setAccelFileSize(long accelFileSize) {
        this.accelFileSize = accelFileSize;
    }

    public String getAudioFileData() {
        return audioFileData;
    }

    public void setAudioFileData(String audioFileData) {
        this.audioFileData = audioFileData;
    }

    public String getAccelFileData() {
        return accelFileData;
    }

    public void setAccelFileData(String accelFileData) {
        this.accelFileData = accelFileData;
    }


    public double[][] getOrgdata() {
        return orgdata;
    }

    public void setOrgdata(double[][] orgdata) {
        this.orgdata = orgdata;
    }

    public double[] getSqrData() {
        return sqrData;
    }

    public void setSqrData(double[] sqrData) {
        this.sqrData = sqrData;
    }

    public String[] getFftDataOrg() {
        return fftDataOrg;
    }

    public void setFftDataOrg(String[] fftDataOrg) {
        this.fftDataOrg = fftDataOrg;
    }

    public String[] getFftData() {
        return fftData;
    }

    public void setFftData(String[] fftData) {
        this.fftData = fftData;
    }

    public double[] getAbsData() {
        return absData;
    }

    public void setAbsData(double[] absData) {
        this.absData = absData;
    }

    public double[] getHalfData() {
        return halfData;
    }

    public void setHalfData(double[] halfData) {
        this.halfData = halfData;
    }

    public double[] getfData() {
        return fData;
    }

    public void setfData(double[] fData) {
        this.fData = fData;
    }

    public double getActualHz() {
        return actualHz;
    }

    public void setActualHz(double actualHz) {
        this.actualHz = actualHz;
    }

    public int getDataCount1() {
        return dataCount1;
    }

    public void setDataCount1(int dataCount1) {
        this.dataCount1 = dataCount1;
    }

    public int getFftCount1() {
        return fftCount1;
    }

    public void setFftCount1(int fftCount1) {
        this.fftCount1 = fftCount1;
    }

    public int getDataCount2() {
        return dataCount2;
    }

    public void setDataCount2(int dataCount2) {
        this.dataCount2 = dataCount2;
    }

    public int getFftCount2() {
        return fftCount2;
    }

    public void setFftCount2(int fftCount2) {
        this.fftCount2 = fftCount2;
    }

    public int getDataCount3() {
        return dataCount3;
    }

    public void setDataCount3(int dataCount3) {
        this.dataCount3 = dataCount3;
    }

    public int getFftCount3() {
        return fftCount3;
    }

    public void setFftCount3(int fftCount3) {
        this.fftCount3 = fftCount3;
    }

    public int getDataCount4() {
        return dataCount4;
    }

    public void setDataCount4(int dataCount4) {
        this.dataCount4 = dataCount4;
    }

    public int getFftCount4() {
        return fftCount4;
    }

    public void setFftCount4(int fftCount4) {
        this.fftCount4 = fftCount4;
    }
}
