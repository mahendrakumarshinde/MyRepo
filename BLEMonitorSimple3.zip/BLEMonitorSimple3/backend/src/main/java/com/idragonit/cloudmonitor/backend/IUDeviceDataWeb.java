package com.idragonit.cloudmonitor.backend;

/**
 * Created by idragon on 2/26/16.
 */
public class IUDeviceDataWeb {

    private long Id;
    private String Timestamp_DB;
    private String Timestamp_Pi;
    private String MAC_ADDRESS;
    private Integer State;
    private Float Battery_Level;
    private Float Feature_Value_0;
    private Float Feature_Value_1;
    private Float Feature_Value_2;
    private Float Feature_Value_3;
    private Float Feature_Value_4;
    private Float Feature_Value_5;

    public Long getId() {
        return Id;
    }

    public void setId(Long id) {
        Id = id;
    }

    public String getTimeStampDB() {
        return Timestamp_DB;
    }

    public void setTimeStampDB(String timestamp_DB) {
        Timestamp_DB = timestamp_DB;
    }

    public String getTimeStampPi() {
        return Timestamp_Pi;
    }

    public void setTimeStampPi(String timestamp_Pi) {
        Timestamp_Pi = timestamp_Pi;
    }

    public String getMacAddress() {
        return MAC_ADDRESS;
    }

    public void setMacAddress(String macAddress) {
        MAC_ADDRESS = macAddress;
    }

    public Integer getState() {
        return State;
    }

    public void setState(Integer state) {
        State = state;
    }

    public Float getBatteryLevel() {
        return Battery_Level;
    }

    public void setBatteryLevel(Float batteryLevel) {
        Battery_Level = batteryLevel;
    }

    public Float getFeatureValue0(){
        return Feature_Value_0;
    }

    public void setFeatureValue0(Float featureValue){
        Feature_Value_0 = featureValue;
    }

    public Float getFeatureValue1(){
        return Feature_Value_1;
    }

    public void setFeatureValue1(Float featureValue){
        Feature_Value_1 = featureValue;
    }

    public Float getFeatureValue2(){
        return Feature_Value_2;
    }

    public void setFeatureValue2(Float featureValue){
        Feature_Value_2 = featureValue;
    }

    public Float getFeatureValue3(){
        return Feature_Value_3;
    }

    public void setFeatureValue3(Float featureValue){
        Feature_Value_3 = featureValue;
    }

    public Float getFeatureValue4(){
        return Feature_Value_4;
    }

    public void setFeatureValue4(Float featureValue){
        Feature_Value_4 = featureValue;
    }

    public Float getFeatureValue5(){
        return Feature_Value_5;
    }

    public void setFeatureValue5(Float featureValue){
        Feature_Value_5 = featureValue;
    }
}
