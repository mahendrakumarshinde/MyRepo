package com.idragonit.cloudmonitor.backend;

/**
 * Created by idragon on 2/26/16.
 */
public class MacAddressInfo {
    private String MAC_ADDRESS;
    private String machineName;
    private Integer Status;

    public String getMachineName() {
        return machineName;
    }

    public void setMachineName(String machineName) {
        this.machineName = machineName;
        if (this.machineName == null)
            this.machineName = MAC_ADDRESS;
    }

    public String getMacAddress() {
        return MAC_ADDRESS;
    }

    public void setMacAddress(String macAddress) {
        MAC_ADDRESS = macAddress;
    }

    public Integer getStatus() {
        return Status;
    }

    public void setStatus(Integer status) {
        Status = status;
    }

}
