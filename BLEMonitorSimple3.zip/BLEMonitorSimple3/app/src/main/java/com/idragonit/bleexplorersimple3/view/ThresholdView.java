package com.idragonit.bleexplorersimple3.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

import com.idragonit.bleexplorersimple3.IReceiveData;
import com.idragonit.bleexplorersimple3.R;
import com.idragonit.bleexplorersimple3.ReadDataActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.TimeZone;

public class ThresholdView extends View implements IReceiveData {

    private static int MIN_VALUE = 1;
    private static int MAX_VALUE = 1800;

    Paint mPaint;

    public int mThresholdIndex = 0;
    int mLastX = 0;
    int mLastY = 0;
    int mSelectedIndex = 0;

    Rect[] mStatusRect = new Rect[4];
    public int[] mStatusThreshold = new int[4];
    public int[] defaultThreshold = new int[] {100, 750, 1500};
    int[] thresholdColors = new int[] {STATUS_IDLE_COLOR, STATUS_NORMAL_CUTTING_COLOR, STATUS_WARNING_COLOR, STATUS_DANGER_COLOR};
    String[] thresholdNames = new String[] {STATUS_IDLE_NAME, STATUS_NORMAL_CUTTING_NAME, STATUS_WARNING_NAME, STATUS_DANGER_NAME};

    int thresholdPadding = 72;
    int thresholdLine = 4;
    int thresholdRadius = 8;
    int thresholdFontsize = 12;

    boolean isInit = false;

    String abNormal;
    SimpleDateFormat mFormat = new SimpleDateFormat("MMddyy HH:mm");

    private OnTouchListener mListener;

    private ArrayList<ChartData> mChartData = new ArrayList<>();

    public static class ChartData {
        public int color = 0xFF000000;
        public float value = 0;
        public boolean isRedDot = false;
        public long timestamp = 0L;
    }

    public ThresholdView(Context context) {
        super(context);
        init();
    }

    public ThresholdView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public ThresholdView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        thresholdPadding = getResources().getDimensionPixelSize(R.dimen.threshold_padding);
        thresholdLine = getResources().getDimensionPixelSize(R.dimen.threshold_line);
        thresholdRadius = getResources().getDimensionPixelSize(R.dimen.threshold_radius);
        thresholdFontsize = getResources().getDimensionPixelSize(R.dimen.threshold_font_size);

        mPaint = new Paint();
        mPaint.setTextSize(thresholdFontsize);
        mPaint.setTextAlign(Paint.Align.CENTER);

        for (int i = 1; i < 4; i++) {
            mStatusThreshold[i] = defaultThreshold[i - 1];

            if (MAX_VALUE - MIN_VALUE < mStatusThreshold[i])
                MAX_VALUE = mStatusThreshold[i] + MIN_VALUE;
        }

        mStatusThreshold[0] = 0;

        for (int i = 0; i < 4; i++) {
            mStatusRect[i] = new Rect();
        }

        isInit = true;

        abNormal = getResources().getString(R.string.tag_abnormal);
        mFormat.setTimeZone(TimeZone.getTimeZone("gmt"));

        calcRects();
    }

    public void setData(ArrayList<ChartData> data) {
        mChartData.clear();

        if (data != null) {
            for (int i = 0; i < data.size(); i++) {
                mChartData.add(data.get(i));
            }
        }

        invalidate();
    }

    public void setMaxValue(float maxValue) {
        for (int i = 1; i < 4; i++) {
            if (maxValue < mStatusThreshold[i] + mStatusThreshold[i] / 30)
                maxValue = mStatusThreshold[i] + mStatusThreshold[i] / 30;
        }

        MAX_VALUE = (int) maxValue;
        calcRects();
    }

    public void setThresholds() {
        for (int i = 1; i < 4; i++) {
            mStatusThreshold[i] = defaultThreshold[i - 1];

            if (MAX_VALUE - MIN_VALUE < mStatusThreshold[i])
                MAX_VALUE = mStatusThreshold[i] + MIN_VALUE;
        }

        mStatusThreshold[0] = 0;

        calcRects();
    }

    private void calcRects() {
        int width = getWidth();
        int height = getHeight();

        if (width == 0 || height == 0 || !isInit)
            return;

        int top = thresholdRadius * 2;
        int bottom = 0;
        for (int i = 3; i >= 0; i--) {
            bottom = (height - thresholdRadius * 2) - (height - thresholdRadius * 4) * mStatusThreshold[i] / MAX_VALUE;
            mStatusRect[i].set(thresholdPadding, top, width - thresholdPadding, bottom);
            top = bottom;
        }
    }

    private void calcValues() {
        int height = getHeight();

        for (int i = 1; i < 4; i++) {
            mStatusThreshold[i] = ((height - thresholdRadius * 2) - mStatusRect[i].bottom) * MAX_VALUE / (height - thresholdRadius * 4);
            if (mStatusThreshold[i] - mStatusThreshold[i - 1] < MIN_VALUE)
                mStatusThreshold[i] = mStatusThreshold[i - 1] + MIN_VALUE;
        }
    }

    public void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);

        calcRects();
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int width = getWidth();

        onChartDraw(canvas);

        for (int i = 0; i < mStatusRect.length; i++) {
            mPaint.setStyle(Paint.Style.FILL_AND_STROKE);
            mPaint.setColor(thresholdColors[i]);
            mPaint.setAlpha(0xFF);

            Rect rc = new Rect(mStatusRect[i]);

            if (i == 0) {
                rc.top = (int) (rc.top + thresholdLine * 1.5f);
            }
            else if (i == 3) {
                rc.bottom = (int) (rc.bottom - thresholdLine * 1.5f);

                canvas.drawRect(mStatusRect[i].left, mStatusRect[i].bottom - thresholdLine / 2, width - thresholdPadding / 2, mStatusRect[i].bottom + thresholdLine / 2, mPaint);
            }
            else {
                rc.top = (int) (rc.top + thresholdLine * 1.5f);
                rc.bottom = (int) (rc.bottom - thresholdLine * 1.5f);

                canvas.drawRect(mStatusRect[i].left, mStatusRect[i].bottom - thresholdLine / 2, width - thresholdPadding / 2, mStatusRect[i].bottom + thresholdLine / 2, mPaint);
            }

            if (i != 0) {
                canvas.drawCircle(width - thresholdPadding / 2, mStatusRect[i].bottom, thresholdRadius, mPaint);
            }

            mPaint.setStyle(Paint.Style.FILL_AND_STROKE);
            mPaint.setAlpha(0xFF);
            mPaint.setColor(0xFF000000);

            if (i != 0) {
                canvas.drawText(String.valueOf(mStatusThreshold[i]), thresholdPadding / 2, mStatusRect[i].bottom + thresholdFontsize / 2, mPaint);
            }
        }

        onRedDot(canvas);
    }

    private void onChartDraw(Canvas canvas) {
        if (mChartData.size() == 0)
            return;

        Rect rcDraw = new Rect(thresholdPadding, thresholdRadius * 2, getWidth() - thresholdPadding, getHeight() - thresholdRadius * 2);
        int valueCount = mChartData.size();
        float gap = valueCount == 1 ? rcDraw.width() : rcDraw.width() / (valueCount - 1);
        float x1 = rcDraw.left;
        float y1 = rcDraw.bottom - mChartData.get(0).value * rcDraw.height() / MAX_VALUE;
        float x2 = 0f;
        float y2 = 0f;

        Paint paint = new Paint();
        paint.setStyle(Paint.Style.FILL_AND_STROKE);
        paint.setStrokeWidth(thresholdLine / 2);

        for (int i = 0; i < valueCount; i++) {
            x2 = gap * i + rcDraw.left;
            y2 = rcDraw.bottom - mChartData.get(i).value * rcDraw.height() / MAX_VALUE;

            paint.setColor(mChartData.get(i).color);
            paint.setAlpha(0x2F);
            canvas.drawRect(x1, rcDraw.top, x2, rcDraw.bottom, paint);

            paint.setAlpha(0xFF);
            canvas.drawLine(x1, rcDraw.top, x1, rcDraw.bottom, paint);
            canvas.drawLine(x2, rcDraw.top, x2, rcDraw.bottom, paint);

            canvas.drawLine(x1, y1, x2, y2, paint);

            x1 = x2;
            y1 = y2;
        }

        Paint circlePaint = new Paint();
        circlePaint.setStrokeWidth(thresholdLine);

        Paint valuePaint = new Paint();
        valuePaint.setTextSize(thresholdFontsize / 1.5f);
        valuePaint.setTextAlign(Paint.Align.CENTER);
        valuePaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));

        for (int i = 0; i < valueCount; i++) {
            x2 = gap * i + rcDraw.left;
            y2 = rcDraw.bottom - mChartData.get(i).value * rcDraw.height() / MAX_VALUE;

            circlePaint.setStyle(Paint.Style.FILL);
            circlePaint.setColor(0xFFFFFFFF);
            canvas.drawCircle(x2, y2, thresholdLine * 2f, circlePaint);

            circlePaint.setStyle(Paint.Style.STROKE);
            circlePaint.setColor(mChartData.get(i).color);
            canvas.drawCircle(x2, y2, thresholdLine * 2f, circlePaint);

            canvas.drawText(String.format("%.01f", mChartData.get(i).value), x2, y2 - thresholdLine * 3f, valuePaint);
        }
    }

    private void onRedDot(Canvas canvas) {
        if (mChartData.size() == 0)
            return;

        Rect rcDraw = new Rect(thresholdPadding, thresholdRadius * 2, getWidth() - thresholdPadding, getHeight() - thresholdRadius * 2);
        int valueCount = mChartData.size();
        float gap = valueCount == 1 ? rcDraw.width() : rcDraw.width() / (valueCount - 1);
        float x;
        float y;

        Paint circlePaint = new Paint();
        circlePaint.setStrokeWidth(thresholdLine);

        Paint valuePaint = new Paint();
        valuePaint.setTextSize(thresholdFontsize / 1.5f);
        valuePaint.setTextAlign(Paint.Align.CENTER);
        valuePaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));

        Paint paint = new Paint();
        paint.setColor(0xccffffff);
        paint.setStyle(Paint.Style.FILL);
        Paint paint1 = new Paint();
        paint1.setColor(0xcc000000);
        paint1.setStyle(Paint.Style.STROKE);

        Path path = new Path();

        for (int i = 0; i < valueCount; i++) {
            ChartData data = mChartData.get(i);

            if (data.isRedDot) {
                x = gap * i + rcDraw.left;
                y = rcDraw.bottom - data.value * rcDraw.height() / MAX_VALUE;

                circlePaint.setStyle(Paint.Style.FILL_AND_STROKE);
                circlePaint.setColor(data .color);
                canvas.drawCircle(x, y, thresholdLine * 2.5f, circlePaint);

                long timestamp = Long.valueOf(data.timestamp);
                Date date = new Date();
                date.setTime(timestamp);
                String time = mFormat.format(date);
                Rect bounds = new Rect();

                time = String.format(abNormal, time);
                valuePaint.getTextBounds(time, 0, time.length(), bounds);
                x = x - bounds.width() / 2;
                y = y - thresholdFontsize * 1.5f;

                path.reset();
                //path.addRect(x - bounds.height(), y - bounds.height() * 3 / 2, x + bounds.width() + bounds.height(), y + bounds.height() / 2, Path.Direction.CCW);
                path.moveTo(x - bounds.height(), y - bounds.height() * 3 / 2);
                path.lineTo(x - bounds.height(), y + bounds.height() / 2);
                path.lineTo(x + bounds.width() / 2 - bounds.height(), y + bounds.height() / 2);
                path.lineTo(x + bounds.width() / 2, y + bounds.height() / 2 + bounds.height());
                path.lineTo(x + bounds.width() / 2 + bounds.height(), y + bounds.height() / 2);
                path.lineTo(x + bounds.width() + bounds.height(), y + bounds.height() / 2);
                path.lineTo(x + bounds.width() + bounds.height(), y - bounds.height() * 3 / 2);
                path.lineTo(x - bounds.height(), y - bounds.height() * 3 / 2);

                canvas.drawPath(path, paint);
                canvas.drawPath(path, paint1);
                canvas.drawText(time, x + bounds.width() / 2, y, valuePaint);
            }
        }
    }

    private int getTouchIndex(int x, int y) {
        for (int i = mStatusRect.length - 1; i > 0; i--) {
            if (new Rect(0, mStatusRect[i].bottom - thresholdRadius, getWidth(), mStatusRect[i].bottom + thresholdRadius).contains(x, y))
                return i;
        }

        return 0;
    }

    public interface OnTouchListener {
        public abstract void onTouch();
    }

    public void setListener(OnTouchListener listener) {
        mListener = listener;
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        int x = (int) event.getX();
        int y = (int) event.getY();
        int action = event.getAction();

        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                mSelectedIndex = getTouchIndex(x, y);
                if (mSelectedIndex != 0 && mListener != null)
                    mListener.onTouch();
                break;
            case MotionEvent.ACTION_UP:
                if (mSelectedIndex != 0 && mListener != null)
                    mListener.onTouch();
                break;
        }
        return super.dispatchTouchEvent(event);
    }

    public boolean onTouchEvent(MotionEvent event) {
        int x = (int) event.getX();
        int y = (int) event.getY();
        int action = event.getAction();

        switch (action) {
            case MotionEvent.ACTION_DOWN:
                mSelectedIndex = getTouchIndex(x, y);
                mLastX = x;
                mLastY = y;
                break;
            case MotionEvent.ACTION_MOVE:
                if (mSelectedIndex != 0) {
                    calcPercent(x, y);
                }
                break;
            case MotionEvent.ACTION_UP:
                if (mSelectedIndex != 0) {
                    calcPercent(x, y);
                    Log.e("test", mStatusThreshold[1] + ":" + mStatusThreshold[2] + ":" + mStatusThreshold[3]);
                    sendData();
                }

                mSelectedIndex = 0;
                break;
        }

        return true;
    }

    private void calcPercent(int x, int y) {
        int step = y - mLastY;
        int curPos = mStatusRect[mSelectedIndex].bottom + step;
        int downLimit = mStatusRect[mSelectedIndex - 1].bottom - MIN_VALUE * (getHeight() - thresholdRadius * 2) / MAX_VALUE;
        int upLimit = mStatusRect[mSelectedIndex].top + MIN_VALUE * (getHeight() - thresholdRadius * 2) / MAX_VALUE;

        if (step > 0 && curPos > downLimit) {
            curPos = downLimit;
            mStatusRect[mSelectedIndex - 1].top = curPos;
            mStatusRect[mSelectedIndex].bottom = curPos;
        }
        else if (step <= 0 && curPos <= upLimit) {
            curPos = upLimit;
            mStatusRect[mSelectedIndex - 1].top = curPos;
            mStatusRect[mSelectedIndex].bottom = curPos;
        }
        else {
            mStatusRect[mSelectedIndex - 1].top = curPos;
            mStatusRect[mSelectedIndex].bottom = curPos;

            mLastX = x;
            mLastY = y;
        }

        calcValues();

        invalidate();
    }

    @Override
    public void readData(int status, long readTime) {

    }

    private void sendData() {
        ((ReadDataActivity)getContext()).sendData(mThresholdIndex, mStatusThreshold);
    }
}
