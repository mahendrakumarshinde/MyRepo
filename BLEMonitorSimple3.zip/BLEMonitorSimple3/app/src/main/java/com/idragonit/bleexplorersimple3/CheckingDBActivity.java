package com.idragonit.bleexplorersimple3;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import com.google.api.client.extensions.android.http.AndroidHttp;
import com.google.api.client.extensions.android.json.AndroidJsonFactory;
import com.idragonit.bleexplorersimple3.dialog.WaitingDialog;
import com.idragonit.cloudmonitor.backend.myApi.MyApi;
import com.idragonit.cloudmonitor.backend.myApi.model.DatabaseInfo;

import java.io.IOException;

@TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
public class CheckingDBActivity extends Activity {
    private static final String TAG = CheckingDBActivity.class.getSimpleName();

    WaitingDialog mWaitingDialog;

    TextView mTxtDatabaseName;
    TextView mTxtUserName;
    TextView mTxtPassword;
    TextView mTxtConfirmPassword;

    String mDeviceID;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);

        setContentView(R.layout.activity_checking_db);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        mDeviceID = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        String dbName = AppData.getDatabaseName(this);

        if (!TextUtils.isEmpty(dbName)) {
            Intent intent = new Intent(this, DeviceScanActivity.class);
            startActivity(intent);

            finish();
            return;
        }

        mTxtDatabaseName = (TextView) findViewById(R.id.txt_db_name);
        mTxtUserName = (TextView) findViewById(R.id.txt_username);
        mTxtPassword = (TextView) findViewById(R.id.txt_password);
        mTxtConfirmPassword = (TextView) findViewById(R.id.txt_confirm_password);

        findViewById(R.id.btn_create).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String dbName = mTxtDatabaseName.getText().toString();
                String userName = mTxtUserName.getText().toString();
                String password = mTxtPassword.getText().toString();
                String confirmPassword = mTxtConfirmPassword.getText().toString();

                if (TextUtils.isEmpty(dbName)) {
                    Toast.makeText(CheckingDBActivity.this, "Please input database name!", Toast.LENGTH_LONG).show();
                    return;
                }

                if (TextUtils.isEmpty(userName)) {
                    Toast.makeText(CheckingDBActivity.this, "Please input user name!", Toast.LENGTH_LONG).show();
                    return;
                }

                if (TextUtils.isEmpty(password)) {
                    Toast.makeText(CheckingDBActivity.this, "Please input password!", Toast.LENGTH_LONG).show();
                    return;
                }

                if (TextUtils.isEmpty(confirmPassword)) {
                    Toast.makeText(CheckingDBActivity.this, "Please input confirm password!", Toast.LENGTH_LONG).show();
                    return;
                }

                if (!TextUtils.equals(password, confirmPassword)) {
                    Toast.makeText(CheckingDBActivity.this, "Password do not match!", Toast.LENGTH_LONG).show();
                    return;
                }

                showLoading("Creating Database...");
                (new CreatingDBTask(dbName, userName, password)).execute(CheckingDBActivity.this);
            }
        });

        showLoading("Checking Database...");
        (new CheckingDBTask()).execute(CheckingDBActivity.this);
    }

    public void showLoading(String message){
        hideLoading();

        mWaitingDialog = new WaitingDialog(this, message);
        mWaitingDialog.show();
    }

    public void hideLoading(){
        if (mWaitingDialog!=null){
            try {
                mWaitingDialog.dismiss();
                mWaitingDialog = null;
            }catch (Exception e){}
        }
    }

    class CheckingDBTask extends AsyncTask<Context, Void, DatabaseInfo> {
        public CheckingDBTask() {

        }

        @Override
        protected DatabaseInfo doInBackground(Context... params) {
            if(DeviceScanActivity.myApiService == null) {  // Only do this once
                MyApi.Builder builder = new MyApi.Builder(AndroidHttp.newCompatibleTransport(), new AndroidJsonFactory(), null)
                        .setRootUrl("https://infinite-uptime-1232.appspot.com/_ah/api/");
                DeviceScanActivity.myApiService = builder.build();
            }

            try {
                DatabaseInfo info = DeviceScanActivity.myApiService.getDBName(mDeviceID).execute();
                return info;
            } catch (IOException e) {
                e.getMessage();
            }

            return null;
        }

        @Override
        protected void onPostExecute(DatabaseInfo result) {
            hideLoading();

            if (result != null) {
                AppData.setDatabaseName(CheckingDBActivity.this, result.getDbName());

                Intent intent = new Intent(CheckingDBActivity.this, DeviceScanActivity.class);
                intent.putExtra(DeviceScanActivity.DATABASE_NAME, result.getDbName());
                startActivity(intent);
                finish();
            }
            else {
                Toast.makeText(CheckingDBActivity.this, "There is no database. Please create new database!", Toast.LENGTH_LONG).show();
            }
        }
    }

    class CreatingDBTask extends AsyncTask<Context, Void, DatabaseInfo> {
        private Context context;
        private String mDBName;
        private String mUserName;
        private String mPassword;

        public CreatingDBTask(String dbName, String userName, String password) {
            mUserName = userName;
            mDBName = dbName;
            mPassword = password;
        }

        @Override
        protected DatabaseInfo doInBackground(Context... params) {
            if(DeviceScanActivity.myApiService == null) {  // Only do this once
                MyApi.Builder builder = new MyApi.Builder(AndroidHttp.newCompatibleTransport(), new AndroidJsonFactory(), null)
                        .setRootUrl("https://infinite-uptime-1232.appspot.com/_ah/api/");
                DeviceScanActivity.myApiService = builder.build();
            }

            context = params[0];

            try {
                DatabaseInfo info = DeviceScanActivity.myApiService.createDBByDeviceID(mDeviceID, mDBName, mUserName, mPassword).execute();
                return info;
            } catch (IOException e) {
                e.getMessage();
            }

            return null;
        }

        @Override
        protected void onPostExecute(DatabaseInfo result) {
            hideLoading();

            if (result != null) {
                AppData.setDatabaseName(CheckingDBActivity.this, result.getDbName());

                Intent intent = new Intent(CheckingDBActivity.this, DeviceScanActivity.class);
                intent.putExtra(DeviceScanActivity.DATABASE_NAME, result.getDbName());
                startActivity(intent);
                finish();
            }
            else {
                Toast.makeText(CheckingDBActivity.this, "Creating Database is failed!", Toast.LENGTH_LONG).show();
            }
        }
    }
}

