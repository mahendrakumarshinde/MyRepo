package com.idragonit.bleexplorersimple3;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.api.client.extensions.android.http.AndroidHttp;
import com.google.api.client.extensions.android.json.AndroidJsonFactory;
import com.idragonit.bleexplorersimple3.dialog.WaitingDialog;
import com.idragonit.cloudmonitor.backend.myApi.MyApi;
import com.idragonit.cloudmonitor.backend.myApi.model.DatabaseInfo;
import com.idragonit.cloudmonitor.backend.myApi.model.DatabaseName;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
public class SelectingDBActivity extends Activity {
    private static final String TAG = SelectingDBActivity.class.getSimpleName();

    WaitingDialog mWaitingDialog;
    ListView mListView;
    ArrayList<String> mDBList = new ArrayList();
    DatabaseAdapter mAdapter;
    String mDeviceID;

    TextView mTxtDatabaseName;
    TextView mTxtUserName;
    TextView mTxtPassword;
    TextView mTxtConfirmPassword;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);

        setContentView(R.layout.activity_selecting_db);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

//        new Thread() {
//            public void run() {
//                try {
//                    QueueService.readData();
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }
//        }.start();

        mDeviceID = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);

        mTxtDatabaseName = (TextView) findViewById(R.id.txt_db_name);
        mTxtUserName = (TextView) findViewById(R.id.txt_username);
        mTxtPassword = (TextView) findViewById(R.id.txt_password);
        mTxtConfirmPassword = (TextView) findViewById(R.id.txt_confirm_password);

        mListView = (ListView) findViewById(R.id.list_dbs);
        mAdapter = new DatabaseAdapter(this, R.layout.layout_database, mDBList);
        mListView.setAdapter(mAdapter);
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String dbName = mAdapter.getItem(position);

                Intent intent = new Intent(SelectingDBActivity.this, DeviceScanActivity.class);
                intent.putExtra(DeviceScanActivity.DATABASE_NAME, dbName);
                startActivity(intent);
            }
        });

        findViewById(R.id.btn_create).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String dbName = mTxtDatabaseName.getText().toString();
                String userName = mTxtUserName.getText().toString();
                String password = mTxtPassword.getText().toString();
                String confirmPassword = mTxtConfirmPassword.getText().toString();

                if (TextUtils.isEmpty(dbName)) {
                    Toast.makeText(SelectingDBActivity.this, "Please input database name!", Toast.LENGTH_LONG).show();
                    return;
                }

                if (TextUtils.isEmpty(userName)) {
                    Toast.makeText(SelectingDBActivity.this, "Please input user name!", Toast.LENGTH_LONG).show();
                    return;
                }

                if (TextUtils.isEmpty(password)) {
                    Toast.makeText(SelectingDBActivity.this, "Please input password!", Toast.LENGTH_LONG).show();
                    return;
                }

                if (TextUtils.isEmpty(confirmPassword)) {
                    Toast.makeText(SelectingDBActivity.this, "Please input confirm password!", Toast.LENGTH_LONG).show();
                    return;
                }

                if (!TextUtils.equals(password, confirmPassword)) {
                    Toast.makeText(SelectingDBActivity.this, "Password do not match!", Toast.LENGTH_LONG).show();
                    return;
                }

                boolean isExist = false;
                for (int i = 0; i < mDBList.size(); i++) {
                    if (TextUtils.equals(dbName, mDBList.get(i))) {
                        isExist = true;
                        break;
                    }
                }

                if (isExist) {
                    Toast.makeText(SelectingDBActivity.this, "There is same database! Please input other name.", Toast.LENGTH_LONG).show();
                    return;
                }

                showLoading("Creating Database...");
                (new CreatingDBTask(dbName, userName, password)).execute(SelectingDBActivity.this);
            }
        });

        findViewById(R.id.btn_connect).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String dbName = mTxtDatabaseName.getText().toString();

                if (TextUtils.isEmpty(dbName)) {
                    Toast.makeText(SelectingDBActivity.this, "Please input database name!", Toast.LENGTH_LONG).show();
                    return;
                }

                boolean isExist = false;
                for (int i = 0; i < mDBList.size(); i++) {
                    if (TextUtils.equals(dbName, mDBList.get(i))) {
                        isExist = true;
                        break;
                    }
                }

                if (isExist) {
                    Intent intent = new Intent(SelectingDBActivity.this, DeviceScanActivity.class);
                    intent.putExtra(DeviceScanActivity.DATABASE_NAME, dbName);
                    startActivity(intent);

                    return;
                }

                showLoading("Checking Database...");
                (new ExistDBTask(dbName)).execute(SelectingDBActivity.this);
            }
        });

//        showLoading("Checking Database...");
//        (new CheckingDBTask()).execute(SelectingDBActivity.this);
        String value = AppData.getDatabaseNameList(SelectingDBActivity.this);
        if (!TextUtils.isEmpty(value)) {
            String[] dblist = value.split(":");

            for (int i = 0; i < dblist.length; i++) {
                mDBList.add(dblist[i]);
            }

            mAdapter.notifyDataSetChanged();
        }
    }

    public void showLoading(String message){
        hideLoading();

        mWaitingDialog = new WaitingDialog(this, message);
        mWaitingDialog.show();
    }

    public void hideLoading(){
        if (mWaitingDialog!=null){
            try {
                mWaitingDialog.dismiss();
                mWaitingDialog = null;
            }catch (Exception e){}
        }
    }

    public class DatabaseAdapter extends ArrayAdapter<String> {

        private Context mContext;
        private int mId;

        public DatabaseAdapter(Context context, int textViewResourceId, List<String> objects) {
            super(context, textViewResourceId, objects);
            mContext = context;
            mId = textViewResourceId;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View v = convertView;
            ViewHolder holder;

            if (v == null) {
                LayoutInflater vi = (LayoutInflater) mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                v = vi.inflate(mId, null);
                holder = new ViewHolder();

                holder.txt_db_name = (TextView) v.findViewById(R.id.txt_db_name);
            }
            else {
                holder = (ViewHolder) v.getTag();
            }

            final String item = getItem(position);
            holder.txt_db_name.setText(item);

            v.setTag(holder);

            return v;
        }

        class ViewHolder {
            TextView txt_db_name;
        }
    }

    class CheckingDBTask extends AsyncTask<Context, Void, DatabaseName> {
        public CheckingDBTask() {

        }

        @Override
        protected DatabaseName doInBackground(Context... params) {
            if(DeviceScanActivity.myApiService == null) {  // Only do this once
                MyApi.Builder builder = new MyApi.Builder(AndroidHttp.newCompatibleTransport(), new AndroidJsonFactory(), null)
                        .setRootUrl("https://infinite-uptime-1232.appspot.com/_ah/api/");
                DeviceScanActivity.myApiService = builder.build();
            }

            try {
                DatabaseName info = DeviceScanActivity.myApiService.getDBNameList().execute();
                return info;
            } catch (IOException e) {
                e.getMessage();
            }

            return null;
        }

        @Override
        protected void onPostExecute(DatabaseName result) {
            hideLoading();

            if (result != null) {
                List<String> list = result.getDbNameList();

                if (list != null) {
                    for (int i = 0; i < list.size(); i++) {
                        mDBList.add(list.get(i));
                    }

                    mAdapter.notifyDataSetChanged();
                }
            }
            else {
                Toast.makeText(SelectingDBActivity.this, "There is no database. Please create new database!", Toast.LENGTH_LONG).show();
            }
        }
    }

    class CreatingDBTask extends AsyncTask<Context, Void, DatabaseInfo> {
        private String mDBName;
        private String mUserName;
        private String mPassword;

        public CreatingDBTask(String dbName, String userName, String password) {
            mDBName = dbName;
            mUserName = userName;
            mPassword = password;
        }

        @Override
        protected DatabaseInfo doInBackground(Context... params) {
            if(DeviceScanActivity.myApiService == null) {  // Only do this once
                MyApi.Builder builder = new MyApi.Builder(AndroidHttp.newCompatibleTransport(), new AndroidJsonFactory(), null)
                        .setRootUrl("https://infinite-uptime-1232.appspot.com/_ah/api/");
                DeviceScanActivity.myApiService = builder.build();
            }


            try {
                DatabaseInfo info = DeviceScanActivity.myApiService.createDBByDeviceID(mDeviceID, mDBName, mUserName, mPassword).execute();
                return info;
            } catch (IOException e) {
                e.getMessage();
            }

            return null;
        }

        @Override
        protected void onPostExecute(DatabaseInfo result) {
            hideLoading();

            if (result != null) {
                String dbName = result.getDbName();
                AppData.setDatabaseName(SelectingDBActivity.this, dbName);
                mDBList.add(dbName);
                mAdapter.notifyDataSetChanged();

                Intent intent = new Intent(SelectingDBActivity.this, DeviceScanActivity.class);
                intent.putExtra(DeviceScanActivity.DATABASE_NAME, result.getDbName());
                startActivity(intent);
            }
            else {
                Toast.makeText(SelectingDBActivity.this, "Creating Database is failed!", Toast.LENGTH_LONG).show();
            }
        }
    }

    class ExistDBTask extends AsyncTask<Context, Void, DatabaseInfo> {
        private String mDBName;

        public ExistDBTask(String dbName) {
            mDBName = dbName;
        }

        @Override
        protected DatabaseInfo doInBackground(Context... params) {
            if(DeviceScanActivity.myApiService == null) {  // Only do this once
                MyApi.Builder builder = new MyApi.Builder(AndroidHttp.newCompatibleTransport(), new AndroidJsonFactory(), null)
                        .setRootUrl("https://infinite-uptime-1232.appspot.com/_ah/api/");
                DeviceScanActivity.myApiService = builder.build();
            }


            try {
                DatabaseInfo info = DeviceScanActivity.myApiService.isExistDB(mDBName).execute();
                return info;
            } catch (IOException e) {
                e.getMessage();
            }

            return null;
        }

        @Override
        protected void onPostExecute(DatabaseInfo result) {
            if (result != null) {
                String dbName = result.getDbName();
                AppData.setDatabaseName(SelectingDBActivity.this, dbName);
                mDBList.add(dbName);
                mAdapter.notifyDataSetChanged();

                String value = "";
                for (int i = 0; i < mDBList.size(); i++) {
                    if (i == 0) {
                        value = mDBList.get(i);
                    }
                    else {
                        value += ":" + mDBList.get(i);
                    }
                }

                AppData.setDatabaseNameList(SelectingDBActivity.this, value);

                Intent intent = new Intent(SelectingDBActivity.this, DeviceScanActivity.class);
                intent.putExtra(DeviceScanActivity.DATABASE_NAME, dbName);
                startActivity(intent);
            }
            else {
                Toast.makeText(SelectingDBActivity.this, "There is no database!", Toast.LENGTH_LONG).show();
            }

            hideLoading();
        }
    }
}

