package com.idragonit.bleexplorersimple3;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;

public class AppData {
    static final String TAG = "BLEMonitor_AppData";
    static final String PREFERENCE_THRESHOLD = TAG + "_threshold";
    static final String PREFERENCE_FEATURE_START_TIME = TAG + "_feature_start_time";
    static final String PREFERENCE_STATUS_NAME = TAG + "_status_name";
    static final String PREFERENCE_DEVICE_NAME = TAG + "_device_name";
    static final String PREFERENCE_DATABASE_NAME = TAG + "_database_name";

    final static String[] STATUS_NAMES = new String[] {"Idle", "Normal Cutting", "Warning", "Danger"};
    static String[] gStatusNames = new String[4];

    public static void setThresholdValue(Context context, String name, int feature, int index, int value) {
        try{
            SharedPreferences pref = context.getSharedPreferences(TAG, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = pref.edit();

            editor.putInt(PREFERENCE_THRESHOLD + name + feature + index, value);

            editor.commit();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public static int getThresholdValue(Context context, String name, int feature, int index, int defaultValue) {
        try{
            SharedPreferences pref = context.getSharedPreferences(TAG, Context.MODE_PRIVATE);
            return pref.getInt(PREFERENCE_THRESHOLD + name + feature + index, defaultValue);
        } catch (Exception e){
            e.printStackTrace();
        }

        return defaultValue;
    }

    public static void setFeatureStartTime(Context context, String id, long value) {
        try{
            SharedPreferences pref = context.getSharedPreferences(TAG, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = pref.edit();

            editor.putLong(PREFERENCE_FEATURE_START_TIME + id, value);

            editor.commit();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public static long getFeatureStartTime(Context context, String id) {
        try{
            SharedPreferences pref = context.getSharedPreferences(TAG, Context.MODE_PRIVATE);
            return pref.getLong(PREFERENCE_FEATURE_START_TIME + id, 0);
        } catch (Exception e){
            e.printStackTrace();
        }

        return 0;
    }

    public static void setStatusName(Context context, int status, String value) {
        gStatusNames[status] = value;

        try{
            SharedPreferences pref = context.getSharedPreferences(TAG, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = pref.edit();

            editor.putString(PREFERENCE_STATUS_NAME + status, value);

            editor.commit();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public static String getStatusName(Context context, int status) {
        if (TextUtils.isEmpty(gStatusNames[status])) {
            try {
                SharedPreferences pref = context.getSharedPreferences(TAG, Context.MODE_PRIVATE);
                gStatusNames[status] = pref.getString(PREFERENCE_STATUS_NAME + status, STATUS_NAMES[status]);
                return gStatusNames[status];
            } catch (Exception e) {
                e.printStackTrace();
            }

            gStatusNames[status] = STATUS_NAMES[status];
        }

        return gStatusNames[status];
    }

    public static void setDeviceName(Context context, String address, String value) {
        try{
            SharedPreferences pref = context.getSharedPreferences(TAG, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = pref.edit();

            editor.putString(PREFERENCE_DEVICE_NAME + address, value);

            editor.commit();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public static String getDeviceName(Context context, String address) {
        try{
            SharedPreferences pref = context.getSharedPreferences(TAG, Context.MODE_PRIVATE);
            return pref.getString(PREFERENCE_DEVICE_NAME + address, address);
        } catch (Exception e){
            e.printStackTrace();
        }

        return address;
    }

    public static void setDatabaseName(Context context, String value) {
        try{
            SharedPreferences pref = context.getSharedPreferences(TAG, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = pref.edit();

            editor.putString(PREFERENCE_DATABASE_NAME, value);

            editor.commit();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public static String getDatabaseName(Context context) {
        try{
            SharedPreferences pref = context.getSharedPreferences(TAG, Context.MODE_PRIVATE);
            return pref.getString(PREFERENCE_DATABASE_NAME, "");
        } catch (Exception e){
            e.printStackTrace();
        }

        return "";
    }
}
