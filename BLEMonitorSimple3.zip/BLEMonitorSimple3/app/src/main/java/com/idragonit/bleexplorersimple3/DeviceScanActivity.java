package com.idragonit.bleexplorersimple3;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Dialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.api.client.extensions.android.http.AndroidHttp;
import com.google.api.client.extensions.android.json.AndroidJsonFactory;
import com.gunner.launcher.preference.dialog.MaterialDialogBuilder;
import com.idragonit.bleexplorersimple3.dialog.WaitingDialog;
import com.idragonit.cloudmonitor.backend.myApi.MyApi;
import com.idragonit.cloudmonitor.backend.myApi.model.MachineNameData;

import java.io.IOException;
import java.util.ArrayList;

@TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
public class DeviceScanActivity extends Activity {
    public static final String DEVICE_DATA_AVAILABLE = "com.idragonit.bleexplorer.DEVICE_DATA_AVAILABLE";
    public static final String DATABASE_NAME = "database_name";

    private static final int MaxDeviceCount = 500;
    private static final int REQUEST_ENABLE_BT = 1;
    private static final long SCAN_PERIOD = 5000L;
    private static final int STATE_NONE = 0;
    private static final int STATE_SCANNING = 1;
    private static final int STATE_STOP = 2;
    private static final String TAG = DeviceScanActivity.class.getSimpleName();
    private BluetoothAdapter mBluetoothAdapter;
    private Handler mHandler;
    private LeDeviceListAdapter mLeDeviceListAdapter;
    private BluetoothAdapter.LeScanCallback mLeScanCallback;
    private boolean mScanning;
    private DeviceInfo scanDevice[];
    private int scanIndex;

    private ListView mListView;
    private View mBtnScan;
    private TextView mTxtScan;
    private ImageView mImgScan;

    private View mLayoutDevices;
    private View mLayoutScan;
    private View mLayoutNoResult;

    private Dialog mDialog;

    String mServerName = "server0";
    String mDbName = "";
    String mUserName = "root";

    WaitingDialog mWaitingDialog;

    public static MyApi myApiService = null;

    private class LeDeviceListAdapter extends BaseAdapter {
        private LayoutInflater mInflator = getLayoutInflater();
        private ArrayList mLeDevices = new ArrayList();

        public LeDeviceListAdapter() {
            super();
            Log.d(TAG, "*** LeDeviceListAdapter.LeDeviceListAdapter()");
        }

        public void addDevice(BluetoothDevice bluetoothdevice) {
            Log.d(TAG, "*** LeDeviceListAdapter.addDevice()");
            if (ReadDataActivity.ISTEST) {
                mLeDevices.add(bluetoothdevice);
            }
            else {
                if (!mLeDevices.contains(bluetoothdevice))
                    mLeDevices.add(bluetoothdevice);
            }
        }

        public void clear() {
            Log.d(TAG, "*** LeDeviceListAdapter.clear()");
            mLeDevices.clear();
        }

        public int getCount() {
            Log.d(TAG, "*** LeDeviceListAdapter.getCount()");
            return mLeDevices.size();
        }

        public BluetoothDevice getDevice(int i) {
            Log.d(TAG, "*** LeDeviceListAdapter.getDevice()");
            return (BluetoothDevice) mLeDevices.get(i);
        }

        public Object getItem(int i) {
            Log.d(TAG, "*** LeDeviceListAdapter.getItem()");
            return mLeDevices.get(i);
        }

        public long getItemId(int i) {
            Log.d(TAG, "*** LeDeviceListAdapter.getItemId()");
            return (long) i;
        }

        public View getView(final int position, View view, ViewGroup viewgroup) {
            Log.d(TAG, String.format("*** LeDeviceListAdapter.getView() position=%d", position));

            ViewHolder viewholder;

            if (view == null) {
                view = mInflator.inflate(R.layout.layout_device, null);
                viewholder = new ViewHolder();
                viewholder.layoutBG = view.findViewById(R.id.layout_bg);
                viewholder.deviceName = (TextView) view.findViewById(R.id.txt_machine_name);
                viewholder.deviceAddress = (TextView) view.findViewById(R.id.txt_address);
                viewholder.deviceRSSI = (ImageView) view.findViewById(R.id.img_range);
                view.setTag(viewholder);
            } else {
                viewholder = (ViewHolder) view.getTag();
            }

            viewholder.deviceName.setText(AppData.getDeviceName(DeviceScanActivity.this, scanDevice[position].Address));
            viewholder.deviceAddress.setText(scanDevice[position].Address);

            if (scanDevice[position].RSSI < 65)
                viewholder.deviceRSSI.setImageResource(R.drawable.ic_range1);
            else if (scanDevice[position].RSSI < 75)
                viewholder.deviceRSSI.setImageResource(R.drawable.ic_range2);
            else if (scanDevice[position].RSSI < 85)
                viewholder.deviceRSSI.setImageResource(R.drawable.ic_range3);
            else if (scanDevice[position].RSSI < 95)
                viewholder.deviceRSSI.setImageResource(R.drawable.ic_range4);
            else
                viewholder.deviceRSSI.setImageResource(R.drawable.ic_range5);

            if (position % 2 == 0) {
                viewholder.layoutBG.setBackgroundColor(getResources().getColor(R.color.sub_background3));
            }
            else {
                viewholder.layoutBG.setBackgroundColor(getResources().getColor(R.color.sub_background4));
            }

            viewholder.deviceName.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    MaterialDialogBuilder dialogBuilder = new MaterialDialogBuilder(DeviceScanActivity.this);
                    View view = getLayoutInflater().inflate(R.layout.dialog_device_name, null);
                    final EditText txtMachineName = (EditText) view.findViewById(R.id.txt_machine_name);

                    txtMachineName.setText(AppData.getDeviceName(DeviceScanActivity.this, scanDevice[position].Address));

                    view.findViewById(R.id.btn_ok).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            mDialog.dismiss();

                            showLoading("Waiting...");
                            (new SetMachineNameTask(scanDevice[position].Address, txtMachineName.getText().toString())).execute(DeviceScanActivity.this);
                        }
                    });

                    view.findViewById(R.id.btn_cancel).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            mDialog.dismiss();
                        }
                    });

                    dialogBuilder.setView(view);
                    mDialog = dialogBuilder.show();
                    mDialog.setCanceledOnTouchOutside(true);

                }
            });

            if (ReadDataActivity.ISTEST) {
                if (position % 5 == 0) {
                    viewholder.deviceRSSI.setImageResource(R.drawable.ic_range5);
                }
                else if (position % 5 == 1) {
                    viewholder.deviceRSSI.setImageResource(R.drawable.ic_range3);
                }
                else if (position % 5 == 2) {
                    viewholder.deviceRSSI.setImageResource(R.drawable.ic_range2);
                }
                else if (position % 5 == 3) {
                    viewholder.deviceRSSI.setImageResource(R.drawable.ic_range4);
                }
                else {
                    viewholder.deviceRSSI.setImageResource(R.drawable.ic_range1);
                }
            }

            return view;
        }
    }

    static class ViewHolder {
        View layoutBG;
        TextView deviceName;
        TextView deviceAddress;
        ImageView deviceRSSI;
    }

    class DeviceInfo {
        public String Address;
        public int BondState;
        public String Name;
        public Integer RSSI;
        public int Type;
        public byte[] scanRecord;

        public DeviceInfo() {
            if (ReadDataActivity.ISTEST) {
                Address = "68:9E:19:07:DE:F5";
                RSSI = 70;
            }
        }
    }

    public DeviceScanActivity() {
        scanDevice = new DeviceInfo[MaxDeviceCount];
        scanIndex = 0;

        mLeScanCallback = new BluetoothAdapter.LeScanCallback() {

            public void onLeScan(final BluetoothDevice device, int rssi, byte scanRecord[]) {
                Log.d(TAG, String.format("*** BluetoothAdapter.LeScanCallback.onLeScan(): *RSSI=%d", rssi));

                String deviceName = device.getName();
                if (TextUtils.isEmpty(deviceName) || !deviceName.toUpperCase().contains("HMSOFT"))
                    return;

                scanDevice[scanIndex] = new DeviceInfo();

                if (deviceName != null && deviceName.length() > 0)
                    scanDevice[scanIndex].Name = deviceName;
                else
                    scanDevice[scanIndex].Name = "unknown device";

                scanDevice[scanIndex].Address = device.getAddress();
                scanDevice[scanIndex].RSSI = Integer.valueOf(rssi);
                scanDevice[scanIndex].Type = device.getType();
                scanDevice[scanIndex].BondState = device.getBondState();

                int length;
                for (length = 0; scanRecord[length] > 0 && length < scanRecord.length; length += 1 + scanRecord[length]) ;

                scanDevice[scanIndex].scanRecord = new byte[length];
                System.arraycopy(scanRecord, 0, scanDevice[scanIndex].scanRecord, 0, length);

                Log.d(TAG, String.format("*** Scan Index=%d, Name=%s, Address=%s, RSSI=%d, scan result length=%d",
                        scanIndex, scanDevice[scanIndex].Name, scanDevice[scanIndex].Address, scanDevice[scanIndex].RSSI, length));

                scanIndex = 1 + scanIndex;

                runOnUiThread(new Runnable() {

                    public void run() {
                        Log.d(TAG, "*** BluetoothAdapter.LeScanCallback.runOnUiThread()");
                        (new GetMachineNameTask(device.getAddress())).execute(DeviceScanActivity.this);
                        mLeDeviceListAdapter.addDevice(device);
                        mLeDeviceListAdapter.notifyDataSetChanged();
                    }
                });
            }
        };
    }

    private void scanLeDevice(boolean scanning) {
        Log.d(TAG, "*** scanLeDevice()");

        if (scanning) {
            showState(STATE_SCANNING);

            mHandler.postDelayed(new Runnable() {

                @TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
                public void run() {
                    if (scanIndex > 0)
                        showState(STATE_STOP);
                    else
                        showState(STATE_NONE);
                    mScanning = false;
                    mBluetoothAdapter.stopLeScan(mLeScanCallback);
                }
            }, SCAN_PERIOD);

            mScanning = true;
            mBluetoothAdapter.startLeScan(mLeScanCallback);
        }
        else {
            if (scanIndex > 0)
                showState(STATE_STOP);
            else
                showState(STATE_NONE);
            mScanning = false;
            mBluetoothAdapter.stopLeScan(mLeScanCallback);
        }
    }

    private void showState(int state) {
        if (state == STATE_NONE) {
            mTxtScan.setText(R.string.menu_scan);

            mLayoutDevices.setVisibility(View.GONE);
            mLayoutScan.setVisibility(View.GONE);
            mLayoutNoResult.setVisibility(View.VISIBLE);
        }
        else if (state == STATE_SCANNING) {
            mTxtScan.setText(R.string.menu_stop);

            mLayoutDevices.setVisibility(View.GONE);
            mLayoutScan.setVisibility(View.VISIBLE);
            mLayoutNoResult.setVisibility(View.GONE);
        }
        else {
            mTxtScan.setText(R.string.menu_scan);

            mLayoutDevices.setVisibility(View.VISIBLE);
            mLayoutScan.setVisibility(View.GONE);
            mLayoutNoResult.setVisibility(View.GONE);
        }
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Log.d(TAG, "*** onActivityResult()");

        if (requestCode == REQUEST_ENABLE_BT && resultCode == RESULT_CANCELED) {
            finish();
        }
        else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    public void onCreate(Bundle bundle) {
        Log.d(TAG, "*** onCreate()");

        super.onCreate(bundle);

        setContentView(R.layout.activity_scan);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        Intent intent = getIntent();
        mDbName = intent.getStringExtra(DATABASE_NAME);
        //mDbName = AppData.getDatabaseName(this);

        mListView = (ListView) findViewById(R.id.list_devices);
        mBtnScan = findViewById(R.id.btn_scan);
        mTxtScan = (TextView) findViewById(R.id.txt_scan);
        mImgScan = (ImageView) findViewById(R.id.img_scan);

        mLayoutDevices = findViewById(R.id.layout_devices);
        mLayoutScan = findViewById(R.id.layout_scan);
        mLayoutNoResult = findViewById(R.id.layout_no_result);

        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Log.d(TAG, String.format("*** onListItemClick() position %d", position));
                if (ReadDataActivity.ISTEST) {
                    Intent intent = new Intent(DeviceScanActivity.this, ReadDataActivity.class);

                    intent.putExtra("DEVICE_NAME", AppData.getDeviceName(DeviceScanActivity.this, scanDevice[position].Address));
                    intent.putExtra("DEVICE_ADDRESS", scanDevice[position].Address);
                    intent.putExtra(DeviceScanActivity.DATABASE_NAME, mDbName);

                    startActivity(intent);

                    return;
                }

                BluetoothDevice bluetoothdevice = mLeDeviceListAdapter.getDevice(position);

                if (bluetoothdevice == null)
                    return;

                if (mScanning) {
                    mBluetoothAdapter.stopLeScan(mLeScanCallback);
                    if (scanIndex > 0)
                        showState(STATE_STOP);
                    else
                        showState(STATE_NONE);
                    mScanning = false;
                }

                if (scanDevice[position].Type == 3)
                    BluetoothLeService.IsDualMode = true;
                else
                    BluetoothLeService.IsDualMode = false;

                if (BluetoothLeService.IsDualMode)
                    Toast.makeText(getApplication(), "Dual Mode", Toast.LENGTH_LONG).show();

                Intent intent = new Intent(DeviceScanActivity.this, ReadDataActivity.class);
                String macAddress = bluetoothdevice.getAddress();

                intent.putExtra("DEVICE_NAME", AppData.getDeviceName(DeviceScanActivity.this, macAddress));
                intent.putExtra("DEVICE_ADDRESS", macAddress);
                intent.putExtra(DeviceScanActivity.DATABASE_NAME, mDbName);

                startActivity(intent);
            }
        });

        mBtnScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!ReadDataActivity.ISTEST) {
                    if (mScanning) {
                        scanLeDevice(false);
                    } else {
                        scanIndex = 0;
                        mLeDeviceListAdapter.clear();
                        scanLeDevice(true);
                    }
                }
            }
        });

        mHandler = new Handler();

        if (!ReadDataActivity.ISTEST) {
            if (!getPackageManager().hasSystemFeature("android.hardware.bluetooth_le")) {
                Toast.makeText(this, R.string.ble_not_supported, Toast.LENGTH_SHORT).show();
                finish();
            }

            mBluetoothAdapter = ((BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE)).getAdapter();

            if (mBluetoothAdapter == null) {
                Toast.makeText(this, R.string.error_bluetooth_not_supported, Toast.LENGTH_SHORT).show();
                finish();
            }
        }
        else {
            showState(STATE_STOP);
        }
    }

    protected void onPause() {
        Log.d(TAG, "*** onPause()");

        super.onPause();

        if (!ReadDataActivity.ISTEST) {
            scanLeDevice(false);
            mLeDeviceListAdapter.clear();
        }
    }

    protected void onResume() {
        Log.d(TAG, "*** onResume()");

        super.onResume();

        if (!ReadDataActivity.ISTEST) {
            if (!mBluetoothAdapter.isEnabled() && !mBluetoothAdapter.isEnabled())
                startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), REQUEST_ENABLE_BT);

            mLeDeviceListAdapter = new LeDeviceListAdapter();
            mListView.setAdapter(mLeDeviceListAdapter);
            scanLeDevice(true);
        }
        else {
            scanIndex = 1;
            mLeDeviceListAdapter = new LeDeviceListAdapter();
            mListView.setAdapter(mLeDeviceListAdapter);
            for (int i = 0; i < scanIndex; i++) {
                scanDevice[i] = new DeviceInfo();
                scanDevice[i].Address = scanDevice[i].Address + i;
                new GetMachineNameTask(scanDevice[i].Address).execute(DeviceScanActivity.this);
                mLeDeviceListAdapter.addDevice(null);
            }
        }
    }

    public void showLoading(String message){
        hideLoading();

        mWaitingDialog = new WaitingDialog(this, message);
        mWaitingDialog.show();
    }

    public void hideLoading(){
        if (mWaitingDialog!=null){
            try {
                mWaitingDialog.dismiss();
                mWaitingDialog = null;
            }catch (Exception e){}
        }
    }

    class SetMachineNameTask extends AsyncTask<Context, Void, Boolean> {
        private String mMacAddress;
        private String mMachineName;

        public SetMachineNameTask(String macAddress, String machineName) {
            mMacAddress = macAddress;
            mMachineName = machineName;
        }

        @Override
        protected Boolean doInBackground(Context... params) {
            if(DeviceScanActivity.myApiService == null) {  // Only do this once
                MyApi.Builder builder = new MyApi.Builder(AndroidHttp.newCompatibleTransport(), new AndroidJsonFactory(), null)
                        .setRootUrl("https://infinite-uptime-1232.appspot.com/_ah/api/");
                DeviceScanActivity.myApiService = builder.build();
            }

            try {
                DeviceScanActivity.myApiService.setMachineNameByDevice(mServerName, mDbName, mUserName, mMacAddress, mMachineName).execute();
                return true;
            } catch (IOException e) {
                e.getMessage();
            }

            return null;
        }

        @Override
        protected void onPostExecute(Boolean result) {
            hideLoading();

            if (result != null) {
                AppData.setDeviceName(DeviceScanActivity.this, mMacAddress, mMachineName);
                mLeDeviceListAdapter.notifyDataSetChanged();
            }
            else {
                Toast.makeText(DeviceScanActivity.this, "Setting Device name is failed!", Toast.LENGTH_LONG).show();
            }
        }
    }

    class GetMachineNameTask extends AsyncTask<Context, Void, MachineNameData> {
        private String mMacAddress;

        public GetMachineNameTask(String macAddress) {
            mMacAddress = macAddress;
        }

        @Override
        protected MachineNameData doInBackground(Context... params) {
            if(DeviceScanActivity.myApiService == null) {  // Only do this once
                MyApi.Builder builder = new MyApi.Builder(AndroidHttp.newCompatibleTransport(), new AndroidJsonFactory(), null)
                        .setRootUrl("https://infinite-uptime-1232.appspot.com/_ah/api/");
                DeviceScanActivity.myApiService = builder.build();
            }

            try {
                MachineNameData data = DeviceScanActivity.myApiService.getMachineName(mServerName, mDbName, mUserName, mMacAddress).execute();
                return data;
            } catch (IOException e) {
                e.getMessage();
            }

            return null;
        }

        @Override
        protected void onPostExecute(MachineNameData result) {
            hideLoading();

            if (result != null) {
                AppData.setDeviceName(DeviceScanActivity.this, mMacAddress, result.getMachine());
                mLeDeviceListAdapter.notifyDataSetChanged();
            }
            else {
                Toast.makeText(DeviceScanActivity.this, "Getting Device name is failed!", Toast.LENGTH_LONG).show();
            }
        }
    }
}
