package com.idragonit.bleexplorersimple3;

import android.annotation.TargetApi;
import android.app.Dialog;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.pm.ActivityInfo;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.support.v4.app.FragmentActivity;
import android.support.v7.widget.AppCompatRadioButton;
import android.support.v7.widget.SwitchCompat;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.api.client.extensions.android.http.AndroidHttp;
import com.google.api.client.extensions.android.json.AndroidJsonFactory;
import com.gunner.launcher.preference.dialog.MaterialDialogBuilder;
import com.idragonit.bleexplorersimple3.dao.BLEFeature;
import com.idragonit.bleexplorersimple3.dao.BLEStatus;
import com.idragonit.bleexplorersimple3.dao.DaoUtils;
import com.idragonit.bleexplorersimple3.dialog.WaitingDialog;
import com.idragonit.bleexplorersimple3.view.ThresholdView;
import com.idragonit.cloudmonitor.backend.myApi.MyApi;
import com.idragonit.cloudmonitor.backend.myApi.model.IUDeviceData;

import org.json.JSONObject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.TimeZone;

@TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
public class ReadDataActivity extends FragmentActivity implements IReceiveData {
    public static final boolean ISTEST = false;

    public static final String EXTRAS_DEVICE_ADDRESS = "DEVICE_ADDRESS";
    public static final String EXTRAS_DEVICE_NAME = "DEVICE_NAME";
    public static final long MONITOR_TIME = 1000L;
    public static final int REFRESH_MONITOR = 1;
    public static final int REFRESH_DEVICE_NAME = 2;
    public static final int SEND_TIMESTAMP = 3;

    public static final int BUFFER_COUNT = 30;

    public static final long EMPTY_DATA_DELAY = 100L;
    public static final long SENDING_DATA_DELAY = 1L;

    public static final String UUID_POSTURE_SENSING_SERVICE = "0000ffe0-0000-1000-8000-00805f9b34fb";
    public static final String UUID_HM10_UART_RX_TX = "0000ffe1-0000-1000-8000-00805f9b34fb";

    private static final String TAG = ReadDataActivity.class.getSimpleName();
    private final String LIST_NAME = "NAME";
    private final String LIST_PERMISSION = "PERMISSION";
    private final String LIST_PROPERTIES = "PROPERTIES";
    private final String LIST_UUID = "UUID";
    public static BluetoothLeService mBluetoothLeService;
    public static boolean mConnected = false;
    public static String mDeviceAddress;
    public static String mReceivedDeviceAddress = "";
    public static String mDeviceName;
    public static BluetoothGattCharacteristic mTargetCharacteristic = null;
    private TextView mConnectionState;
    private View mBtnConnect;
    private SwitchCompat mSwitchCompat;

    private View mLayoutBattery;
    private TextView mTxtBattery;
    private ImageView mImgBattery;
    private TextView mTxtStatus;

    private Spinner mSpinner;
    private ScrollView mLayoutData;
    private ThresholdView mThresholdView;

    public static int uartIndex = -1;

    public ArrayList<BLEStatus> mStatusList = new ArrayList<BLEStatus>();
    public BLEStatus mLastStatus = null;
    public long[] mDurations = new long[4];

    public ArrayList<BLEFeature> mFeatureList = new ArrayList<BLEFeature>();
    public HashMap<String, BLEFeature> mLastFeature = new HashMap<String, BLEFeature>();
    public HashMap<String, ArrayList<BLEFeature>> mFeatureMap = new HashMap<String, ArrayList<BLEFeature>>();

    public Thread mMonitorThread = null;
    public boolean isRunning = false;

    public String mReceiveDataTmp = "";

    int testValue = 0;
    int mCurFeature = 0;

    int[] batteryImgs = new int[] {R.drawable.ic_battery0, R.drawable.ic_battery1, R.drawable.ic_battery2, R.drawable.ic_battery3, R.drawable.ic_battery4};
    public int[][] mFeatureThresholds = new int[][] {new int[]{30, 600, 1200}, new int[]{100, 500, 1000}, new int[]{6, 7, 8},
            new int[]{40, 42, 45}, new int[]{200, 205, 210}, new int[]{500, 1000, 1500}};

    int[] btnFeatureIds = new int[] {R.id.btn_feature0, R.id.btn_feature1, R.id.btn_feature2, R.id.btn_feature3, R.id.btn_feature4, R.id.btn_feature5};
    AppCompatRadioButton[] btnFeatures = new AppCompatRadioButton[6];

    Dialog mDialog;
    WaitingDialog mWaitingDialog;

    String mServerName = "server0";
    String mDbName = "";
    String mUserName = "root";

    boolean isInitThreshold = false;
    boolean isSendData = false;

    Thread mSendTimestampThread = null;
    boolean isRunningTimestamp = false;

    Thread mAddingDataThread = null;
    boolean isRunningAddData = false;

    Thread mAddingAWSThread = null;
    boolean isRunningAddAWS = false;

    Thread mThresholdThread = null;
    boolean isRunningThreshold = false;

    ArrayList<String> mDataList = new ArrayList<>();
    ArrayList<String> mAWSList = new ArrayList<>();
    int[] mThresholdList = null;

    SimpleDateFormat mFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");

    private final BroadcastReceiver mGattUpdateReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();

            if (BluetoothLeService.ACTION_GATT_CONNECTED.equals(action)) {
                mConnected = true;
                sendInitData();
                updateConnectionState(R.string.connected);
            } else if (BluetoothLeService.ACTION_GATT_DISCONNECTED.equals(action)) {
                mConnected = false;
                mTargetCharacteristic = null;
                updateConnectionState(R.string.disconnected);
                disconnect();
            } else if (BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED.equals(action))
                displayGattServices(mBluetoothLeService.getSupportedGattServices());
            else if (DeviceScanActivity.DEVICE_DATA_AVAILABLE.equals(action)) {
                mDeviceName = intent.getStringExtra("DEVICE_NAME");
                mDeviceAddress = intent.getStringExtra("DEVICE_ADDRESS");
                //displayData(intent.getStringExtra(BluetoothLeService.EXTRA_DATA));
            } else if (BluetoothLeService.ACTION_DATA_AVAILABLE.equals(action)) {
                final byte data[] = intent.getByteArrayExtra(BluetoothLeService.EXTRA_DATA);
                Log.d(TAG, "Uart BroadcastReceiver :" + (new DataManager()).byteArrayToHex(data));

                runOnUiThread(new Runnable() {

                    public void run() {
                        try {
                            String state = new String(data, "UTF-8");

                            if (state.contains(";")) {
                                mReceiveDataTmp += state;
                                mReceiveDataTmp = mReceiveDataTmp.replace(";", "");
                                displayData(mReceiveDataTmp);
                                mReceiveDataTmp = "";
                            }
                            else {
                                mReceiveDataTmp += state;
                            }
                        } catch (Exception e) {

                        }
                    }
                });
            }

            Log.d(ReadDataActivity.TAG, "BroadcastReceiver.onReceive():action=" + action);
        }
    };

    private final ServiceConnection mServiceConnection = new ServiceConnection() {

        public void onServiceConnected(ComponentName componentname, IBinder ibinder) {
            mBluetoothLeService = ((BluetoothLeService.LocalBinder) ibinder).getService();
            if (!mBluetoothLeService.initialize()) {
                Log.e(ReadDataActivity.TAG, "Unable to initialize Bluetooth");
                finish();
            }

            mBluetoothLeService.connect(mDeviceAddress);
        }

        public void onServiceDisconnected(ComponentName componentname) {
            mBluetoothLeService = null;
        }
    };

    Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            if (msg.what == REFRESH_MONITOR) {
                long curTime = System.currentTimeMillis();

                if (mLastStatus != null) {
                    mLastStatus.setEndTime(curTime);
                }

                if (mLastFeature.size() > 0) {
                    Iterator<BLEFeature> iterator = mLastFeature.values().iterator();
                    while (iterator.hasNext()) {
                        BLEFeature bleFeature = iterator.next();
                        if (bleFeature != null) {
                            bleFeature.setEndTime(curTime);
                            refreshFeatureData(String.format("%04d", mCurFeature + 1));
                        }
                    }
                }
            }
            else if (msg.what == REFRESH_DEVICE_NAME) {
                ((TextView) findViewById(R.id.device_name)).setText(mDeviceAddress);
            }
            else if (msg.what == SEND_TIMESTAMP) {
                sendTimestamp();
            }
        }
    };

    public ReadDataActivity() {
        mConnected = false;
    }

    private void startMonitorThread() {
        if (mMonitorThread != null)
            return;

        mMonitorThread = new Thread() {
            public void run() {
                while (isRunning) {
                    try {
                        sleep(MONITOR_TIME);
                    }
                    catch (Exception e) {

                    }

                    if (mLastStatus != null || mLastFeature != null) {
                        mHandler.sendEmptyMessage(REFRESH_MONITOR);
                    }
                }

                mMonitorThread = null;
            }
        };

        isRunning = true;
        mMonitorThread.start();
    }

    private void stopMonitorThread() {
        if (mMonitorThread == null)
            return;

        isRunning = false;
    }

    private void disconnect() {
        long curTime = System.currentTimeMillis();

        if (mLastStatus != null) {
            mLastStatus.setEndTime(curTime);
            mLastStatus = null;
        }

        if (mLastFeature.size() > 0) {
            Iterator<BLEFeature> iterator = mLastFeature.values().iterator();
            while (iterator.hasNext()) {
                BLEFeature bleFeature = iterator.next();
                bleFeature.setEndTime(curTime);
            }

            mLastFeature.clear();
        }

        addStatusFeature();
    }

    private void displayData(String data) {
        Log.e("test", "displayData="+data);
        //(new InsertIUDataTask(data)).execute(ReadDataActivity.this);
        String[] command = data.split(",");
        mReceivedDeviceAddress = command[0];

        try {
            String stime = command[15].substring(0, 10) + command[15].substring(11, 13) + "0";
            long timestamp = Long.valueOf(stime);

            mDataList.add(data);
            //mAWSList.add(data);

            long curTime = System.currentTimeMillis();
            int status = STATUS_NONE;

            if (command[1].contains("00")) {
                status = STATUS_IDLE;
            } else if (command[1].contains("01")) {
                status = STATUS_NORMAL_CUTTING;
            } else if (command[1].contains("02")) {
                status = STATUS_WARNING;
            } else if (command[1].contains("03")) {
                status = STATUS_DANGER;
            }

            if (status != STATUS_NONE) {
                mLastStatus = new BLEStatus(mDeviceName, mDeviceAddress, status, curTime, curTime);
                mStatusList.add(mLastStatus);
            }

            if (command.length > 2) {
                try {
                    String level = command[2];
                    int percent = Integer.valueOf(level);
                    int index = (percent - 1) / 20;

                    if (index == 0)
                        mTxtBattery.setTextColor(getResources().getColor(R.color.black));
                    else
                        mTxtBattery.setTextColor(getResources().getColor(R.color.white));

                    mTxtBattery.setText(percent + "%");
                    mImgBattery.setImageResource(batteryImgs[index]);
                } catch (Exception e) {

                }
            }

            if (command.length > 3) {
                ArrayList<String> ids = new ArrayList<String>();

                for (int i = 3; i < 15; i += 2) {
                    String featureId = command[i];
                    float featureValue = Float.valueOf(command[i + 1]);
                    BLEFeature bleFeature;

                    if (mFeatureMap.get(featureId) == null) {
                        AppData.setFeatureStartTime(this, featureId, System.currentTimeMillis());
                    }

                    bleFeature = mLastFeature.get(featureId);
                    if (bleFeature != null && (bleFeature.getStatus() != status || bleFeature.getFeatureValue() != featureValue || !TextUtils.equals(bleFeature.getFeatureId(), featureId)))
                        bleFeature = null;

                    if (bleFeature == null) {
                        bleFeature = new BLEFeature(mDeviceName, mDeviceAddress, mReceivedDeviceAddress, status, featureId, featureValue, curTime, curTime);
                        mFeatureList.add(bleFeature);

                        ArrayList<BLEFeature> featureList = mFeatureMap.get(featureId);
                        if (featureList == null) {
                            featureList = new ArrayList<BLEFeature>();
                            mFeatureMap.put(featureId, featureList);
                        }

                        featureList.add(bleFeature);

                        refreshFeatureData(String.format("%04d", mCurFeature + 1));
                    } else {
                        refreshFeatureData(String.format("%04d", mCurFeature + 1));
                    }

                    ids.add(featureId);
                    mLastFeature.put(featureId, bleFeature);
                }

                Object[] keys = mLastFeature.keySet().toArray();

                for (int i = 0; i < keys.length; i++) {
                    boolean isExist = false;

                    for (int j = 0; j < ids.size(); j++) {
                        if (TextUtils.equals((String) keys[i], ids.get(j))) {
                            isExist = true;
                            break;
                        }
                    }

                    if (!isExist)
                        mLastFeature.remove(keys[i]);
                }
            }
        }
        catch (Exception e) {

        }
    }

    public void addStatusFeature() {
        for (int i = 0; i < mStatusList.size(); i++) {
            BLEStatus status = mStatusList.get(i);
            mDurations[status.getStatus()] += status.getEndTime() - status.getStartTime();
        }

        DaoUtils.addBLEStatus(this, mStatusList);
        mStatusList.clear();
        mLastStatus = null;

//        for (int i = 0; i < mFeatureList.size(); i++) {
//            BLEFeature feature = mFeatureList.get(i);
//
//            ArrayList<BLEFeature> featureList = mFeatureMap.get(feature.getFeatureId());
//            if (featureList == null) {
//                featureList = new ArrayList<BLEFeature>();
//                mFeatureMap.put(feature.getFeatureId(), featureList);
//            }
//
//            featureList.add(feature);
//        }

        DaoUtils.addBLEFeature(this, mFeatureList);
        mFeatureList.clear();
        mLastFeature.clear();
    }

    private void displayGattServices(List gattList) {
        if (gattList == null)
            return;

        for (int i = 0; i < gattList.size(); i++) {
            BluetoothGattService bluetoothgattservice = (BluetoothGattService) gattList.get(i);
            String uuid = bluetoothgattservice.getUuid().toString();
            List characteristicList = bluetoothgattservice.getCharacteristics();

            if (TextUtils.equals(UUID_POSTURE_SENSING_SERVICE, uuid)) {
                for (int k = 0; k < characteristicList.size(); k++) {
                    BluetoothGattCharacteristic characteristic = (BluetoothGattCharacteristic) characteristicList.get(k);
                    String characterUUID = characteristic.getUuid().toString();

                    if (TextUtils.equals(UUID_HM10_UART_RX_TX, characterUUID)) {
                        mTargetCharacteristic = characteristic;

                        if (GattAttributes.IsUartCharacteristic(characteristic.getUuid()) >= 0) {
                            uartIndex = GattAttributes.IsUartCharacteristic(characteristic.getUuid());
                            mBluetoothLeService.enableTXNotification();
                            sendInitData();
                        } else {
                        }

                        mLayoutBattery.setVisibility(View.VISIBLE);
                        mLayoutData.setVisibility(View.VISIBLE);

                        return;
                    }
                }
            }
        }
    }

    private static IntentFilter makeGattUpdateIntentFilter() {
        IntentFilter intentfilter = new IntentFilter();

        intentfilter.addAction(BluetoothLeService.ACTION_GATT_CONNECTED);
        intentfilter.addAction(BluetoothLeService.ACTION_GATT_DISCONNECTED);
        intentfilter.addAction(BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED);
        intentfilter.addAction(DeviceScanActivity.DEVICE_DATA_AVAILABLE);
        intentfilter.addAction(BluetoothLeService.RSSI_DATA_AVAILABLE);
        intentfilter.addAction(BluetoothLeService.ACTION_DATA_AVAILABLE);

        return intentfilter;
    }

    private void updateConnectionState(final int resourceId) {
        runOnUiThread(new Runnable() {
            public void run() {
                mConnectionState.setText(resourceId);
                if (resourceId == R.string.connected)
                    mSwitchCompat.setChecked(true);
                else
                    mSwitchCompat.setChecked(false);
            }
        });
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);

        setContentView(R.layout.activity_read_data);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        Intent intent = getIntent();
        mDbName = intent.getStringExtra(DeviceScanActivity.DATABASE_NAME);
        //mDbName = AppData.getDatabaseName(this);

        mFormat.setTimeZone(TimeZone.getTimeZone("gmt"));

        mDeviceName = intent.getStringExtra(EXTRAS_DEVICE_NAME);
        mDeviceAddress = intent.getStringExtra(EXTRAS_DEVICE_ADDRESS);

        mDurations = DaoUtils.getStatusDuration(this, mDeviceAddress);
        mFeatureMap = DaoUtils.getFeatures(this, mDeviceAddress);

        mLayoutBattery = findViewById(R.id.layout_battery);
        mTxtBattery = (TextView) findViewById(R.id.txt_battery);
        mImgBattery = (ImageView) findViewById(R.id.img_battery);

        mTxtStatus = (TextView) findViewById(R.id.txt_status);

        mLayoutData = (ScrollView) findViewById(R.id.layout_data);
        mThresholdView = (ThresholdView) findViewById(R.id.threshold);

        ((TextView) findViewById(R.id.device_name)).setText(mDeviceName);

        mLayoutBattery.setVisibility(View.INVISIBLE);
        mLayoutData.setVisibility(View.INVISIBLE);

        mConnectionState = (TextView) findViewById(R.id.connection_state);
        mSwitchCompat = (SwitchCompat) findViewById(R.id.switch_connect);
        mBtnConnect = findViewById(R.id.btn_connect);
        mBtnConnect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ISTEST) {
                    testValue++;
                    long ltime = System.currentTimeMillis();
                    String stime = String.valueOf(ltime);
                    stime = stime.substring(0, 10) + "." + stime.substring(10, 12);

                    if (testValue % 4 == 0) {
                        displayData("DE:98:19:07:F6:A0,00,90,0001,300.94,0002,30.94,0003,30.94,0004,30.94,0005,30.94,0006,30.94," + stime);
                    }
                    if (testValue % 4 == 1) {
                        displayData("DE:98:19:07:F6:A0,01,91,0001,330.94,0002,34.94,0003,33.94,0004,30.94,0005,30.94,0006,30.94," + stime);
                    }
                    if (testValue % 4 == 2) {
                        displayData("DE:98:19:07:F6:A0,02,92,0001,320.94,0002,31.94,0003,32.94,0004,30.94,0005,30.94,0006,30.94," + stime);
                    }
                    if (testValue % 4 == 3) {
                        displayData("DE:98:19:07:F6:A0,03,93,0001,340.94,0002,32.94,0003,30.94,0004,30.94,0005,30.94,0006,30.94," + stime);
                    }
                }
                else {
                    if (mConnected) {
                        mBluetoothLeService.disconnect();
                    } else {
                        mBluetoothLeService.connect(mDeviceAddress);
                    }
                }
            }
        });

        if (ISTEST) {
            mLayoutBattery.setVisibility(View.VISIBLE);
            mLayoutData.setVisibility(View.VISIBLE);
        }

        for (int i = 0; i < mFeatureThresholds.length; i++) {
            for (int j = 0; j < 3; j++) {
                mFeatureThresholds[i][j] = AppData.getThresholdValue(this, mDeviceAddress, i, j, mFeatureThresholds[i][j]);
            }
        }

        mThresholdView.mThresholdIndex = mCurFeature;

        for (int j = 0; j < 3; j++)
            mThresholdView.defaultThreshold[j] = mFeatureThresholds[mCurFeature][j];

        mThresholdView.setThresholds();

        mThresholdView.setListener(new ThresholdView.OnTouchListener() {
            @Override
            public void onTouch() {
                mLayoutData.requestDisallowInterceptTouchEvent(true);
            }
        });

        initViews();

        if (!ISTEST) {
            bindService(new Intent(this, BluetoothLeService.class), mServiceConnection, BIND_AUTO_CREATE);
        }

        showLoading("Checking Threshold...");
        (new GetThresholdTask()).execute(ReadDataActivity.this);

        new Thread() {
            public void run() {
                try {
                    QueueService.init();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }.start();

        String data = AppData.getBLEData(this);

        if (!TextUtils.isEmpty(data)) {
            String[] datalist = data.split(";;");

            for (int i = 0; i < datalist.length; i++) {
                mDataList.add(datalist[i]);
            }
        }

        startAddingDataThread();

        data = AppData.getAWSData(this);

        if (!TextUtils.isEmpty(data)) {
            String[] datalist = data.split(";;");

            for (int i = 0; i < datalist.length; i++) {
                mAWSList.add(datalist[i]);
            }
        }

        //startAddingAWSThread();

        startThresholdThread();
    }

    private void initViews() {
        View btnSetting = findViewById(R.id.btn_setting);

        if (btnSetting != null) {
            btnSetting.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    MaterialDialogBuilder dialogBuilder = new MaterialDialogBuilder(ReadDataActivity.this);
                    View view = getLayoutInflater().inflate(R.layout.dialog_setting, null);
                    final EditText txtState0 = (EditText) view.findViewById(R.id.txt_state0);
                    final EditText txtState1 = (EditText) view.findViewById(R.id.txt_state1);
                    final EditText txtState2 = (EditText) view.findViewById(R.id.txt_state2);
                    final EditText txtState3 = (EditText) view.findViewById(R.id.txt_state3);

                    txtState0.setText(AppData.getStatusName(ReadDataActivity.this, 0));
                    txtState1.setText(AppData.getStatusName(ReadDataActivity.this, 1));
                    txtState2.setText(AppData.getStatusName(ReadDataActivity.this, 2));
                    txtState3.setText(AppData.getStatusName(ReadDataActivity.this, 3));

                    view.findViewById(R.id.btn_ok).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            mDialog.dismiss();

                            AppData.setStatusName(ReadDataActivity.this, 0, txtState0.getText().toString());
                            AppData.setStatusName(ReadDataActivity.this, 1, txtState1.getText().toString());
                            AppData.setStatusName(ReadDataActivity.this, 2, txtState2.getText().toString());
                            AppData.setStatusName(ReadDataActivity.this, 3, txtState3.getText().toString());
                        }
                    });

                    view.findViewById(R.id.btn_cancel).setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            mDialog.dismiss();
                        }
                    });

                    dialogBuilder.setView(view);
                    mDialog = dialogBuilder.show();
                    mDialog.setCanceledOnTouchOutside(true);
                }
            });
        }

        for (int i = 0; i < btnFeatureIds.length; i++) {
            btnFeatures[i] = (AppCompatRadioButton) findViewById(btnFeatureIds[i]);

            if (btnFeatures[i] == null)
                break;

            btnFeatures[i].setTag(i);
            btnFeatures[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int curFeature = (Integer) v.getTag();

                    if (curFeature == mCurFeature)
                        return;

                    btnFeatures[mCurFeature].setChecked(false);
                    btnFeatures[curFeature].setChecked(true);

                    setFeature(curFeature);
                }
            });
        }

        if (btnFeatures[mCurFeature] != null)
            btnFeatures[mCurFeature].setChecked(true);

        setFeature(mCurFeature);

    }

    private void setFeature(int index) {
        mCurFeature = index;

        for (int j = 0; j < 3; j++)
            mThresholdView.defaultThreshold[j] = mFeatureThresholds[mCurFeature][j];

        mThresholdView.mThresholdIndex = mCurFeature;
        mThresholdView.setThresholds();

        refreshFeatureData(String.format("%04d", mCurFeature + 1));
    }

    protected void onDestroy() {
        String data = "";

        for (int i = 0; i < mDataList.size(); i++) {
            if (i == mDataList.size() - 1) {
                data = data + mDataList.get(i);
            }
            else {
                data = data + mDataList.get(i) + ";;";
            }
        }

        AppData.setBLEData(this, data);

        data = "";

        for (int i = 0; i < mAWSList.size(); i++) {
            if (i == mAWSList.size() - 1) {
                data = data + mAWSList.get(i);
            }
            else {
                data = data + mAWSList.get(i) + ";;";
            }
        }

        AppData.setAWSData(this, data);

        if (!ISTEST) {
            unbindService(mServiceConnection);
            mBluetoothLeService = null;
        }

        stopAddingDataThread();
        stopAddingAWSThread();
        stopThresholdThread();

        super.onDestroy();
    }

    protected void onPause() {
        super.onPause();

        stopMonitorThread();
        stopSendTimestampThread();

        long curTime = System.currentTimeMillis();
        if (mLastStatus != null) {
            mLastStatus.setEndTime(curTime);
        }

        if (mLastFeature.size() > 0) {
            Iterator<BLEFeature> iterator = mLastFeature.values().iterator();
            while (iterator.hasNext()) {
                BLEFeature bleFeature = iterator.next();
                bleFeature.setEndTime(curTime);
            }

            mLastFeature.clear();
        }

        addStatusFeature();
        unregisterReceiver(mGattUpdateReceiver);
    }

    protected void onResume() {
        super.onResume();

        registerReceiver(mGattUpdateReceiver, makeGattUpdateIntentFilter());

        if (mBluetoothLeService != null) {
            boolean result = mBluetoothLeService.connect(mDeviceAddress);
            Log.d(TAG, "Connect request result=" + result);
        }

        startMonitorThread();
        startSendTimestampThread();
    }

    @Override
    public void readData(int status, long readTime) {

    }

    public void sendInitData() {
        if (mConnected && isInitThreshold && !isSendData && uartIndex != -1) {
            isSendData = true;

            for (int i = 0; i < mFeatureThresholds.length; i++) {
                int[] threshold = new int[4];
                threshold[1] = mFeatureThresholds[i][0];
                threshold[2] = mFeatureThresholds[i][1];
                threshold[3] = mFeatureThresholds[i][2];

                sendData(i, threshold);
            }

            sendTimestamp();
        }
    }

    private void sendTimestamp() {
        if (!ISTEST) {
            if (mBluetoothLeService != null) {
                Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
                long ltime = cal.getTimeInMillis();
                String stime = String.valueOf(ltime);
                stime = stime.substring(0, 10) + "." + stime.substring(10, 13) + "000";

                String time = "1:" + stime;
                if (mBluetoothLeService.writeRXCharacteristic(time.getBytes())) {
                    Log.d(TAG, "Sent Time=" + time);
                } else {
                    Log.d(TAG, "Fail Time=" + time);
                }
            }
        }
        else {
            Calendar cal = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
            long ltime = cal.getTimeInMillis();
            String stime = String.valueOf(ltime);
            stime = stime.substring(0, 10) + "." + stime.substring(10, 13) + "000";

            String time = "1:" + stime;
            Log.d(TAG, "Sent Time=" + time + ":" + time.getBytes().length);
        }
    }

    public void sendData(int index, int[] threshold) {
        String data = String.format("%04d", index);
        for (int i = 1; i < 4; i++) {
            data += "-" + String.format("%04d", threshold[i]);
        }

        Log.d(TAG, "Threshold Data=" + data + ":" + data.getBytes().length);

        for (int i = 0; i < 3; i++)
            mFeatureThresholds[index][i] = threshold[i + 1];

        if (!ISTEST) {
            if (mBluetoothLeService != null) {
                if (mBluetoothLeService.writeRXCharacteristic(data.getBytes())) {
                    Log.d(TAG, "Sent Data=" + data);
                    for (int i = 1; i < 4; i++) {
                        AppData.setThresholdValue(this, mDeviceAddress, mCurFeature, i - 1, threshold[i]);
                    }

                    mThresholdList = new int[] {mCurFeature, threshold[1], threshold[2], threshold[3]};
                } else {
                    Log.d(TAG, "Fail Data=" + data);
                }
            }
        }
        else {
            for (int i = 1; i < 4; i++) {
                AppData.setThresholdValue(this, mDeviceAddress, mCurFeature, i - 1, threshold[i]);
            }

            mThresholdList = new int[] {mCurFeature, threshold[1], threshold[2], threshold[3]};
        }
    }

    public void refreshFeatureData(String id) {
        ArrayList<BLEFeature> featureList = mFeatureMap.get(id);

        if (featureList == null) {
            mThresholdView.setData(null);
            mThresholdView.invalidate();

            return;
        }

        if (featureList.size() > 0) {
            BLEFeature feature = featureList.get(featureList.size() - 1);

            if (feature.getStatus() == STATUS_IDLE) {
                mTxtStatus.setBackgroundColor(STATUS_IDLE_COLOR);
                mTxtStatus.setText(AppData.getStatusName(this, 0));
            }
            else if (feature.getStatus() == STATUS_NORMAL_CUTTING) {
                mTxtStatus.setBackgroundColor(STATUS_NORMAL_CUTTING_COLOR);
                mTxtStatus.setText(AppData.getStatusName(this, 1));
            }
            else if (feature.getStatus() == STATUS_WARNING) {
                mTxtStatus.setBackgroundColor(STATUS_WARNING_COLOR);
                mTxtStatus.setText(AppData.getStatusName(this, 2));
            }
            else if (feature.getStatus() == STATUS_DANGER) {
                mTxtStatus.setBackgroundColor(STATUS_DANGER_COLOR);
                mTxtStatus.setText(AppData.getStatusName(this, 3));
            }
        }

        int index = 0;

        if (featureList.size() > 25) {
            index = featureList.size() - 25;
        }

        Float maxValue = 0F;
        for (; index < featureList.size(); index++) {
            if (maxValue < featureList.get(index).getFeatureValue())
                maxValue = featureList.get(index).getFeatureValue();
        }

        mThresholdView.setMaxValue(maxValue + maxValue / 30);
        mThresholdView.setData(generateLineData(id, featureList));
    }

    private ArrayList<ThresholdView.ChartData> generateLineData(String id, ArrayList<BLEFeature> featureList) {

        ArrayList<ThresholdView.ChartData> data = new ArrayList<ThresholdView.ChartData>();

        int index = 0;

        if (featureList.size() > 25) {
            index = featureList.size() - 25;
        }
        else {
        }

        for (; index < featureList.size(); index++) {
            BLEFeature feature = featureList.get(index);
            ThresholdView.ChartData entry = new ThresholdView.ChartData();
            entry.value = feature.getFeatureValue();

            if (feature.getStatus() == STATUS_IDLE)
                entry.color = STATUS_IDLE_COLOR;
            else if (feature.getStatus() == STATUS_NORMAL_CUTTING)
                entry.color = STATUS_NORMAL_CUTTING_COLOR;
            else if (feature.getStatus() == STATUS_WARNING)
                entry.color = STATUS_WARNING_COLOR;
            else if (feature.getStatus() == STATUS_DANGER)
                entry.color = STATUS_DANGER_COLOR;

            data.add(entry);
        }

        return data;
    }

    public void showLoading(String message){
        hideLoading();

        mWaitingDialog = new WaitingDialog(this, message);
        mWaitingDialog.show();
    }

    public void hideLoading(){
        if (mWaitingDialog!=null){
            try {
                mWaitingDialog.dismiss();
                mWaitingDialog = null;
            }catch (Exception e){}
        }
    }

    class GetThresholdTask extends AsyncTask<Context, Void, IUDeviceData> {

        public GetThresholdTask() {
        }

        @Override
        protected IUDeviceData doInBackground(Context... params) {
            if(DeviceScanActivity.myApiService == null) {  // Only do this once
                MyApi.Builder builder = new MyApi.Builder(AndroidHttp.newCompatibleTransport(), new AndroidJsonFactory(), null)
                        .setRootUrl("https://infinite-uptime-1232.appspot.com/_ah/api/");
                DeviceScanActivity.myApiService = builder.build();
            }

            try {
                IUDeviceData info = DeviceScanActivity.myApiService.getThresholdData(mServerName, mDbName, mUserName, mDeviceAddress).execute();
                return info;
            } catch (IOException e) {
                e.getMessage();
            }

            return null;
        }

        @Override
        protected void onPostExecute(IUDeviceData result) {
            hideLoading();

            if (result != null) {
                List<Integer> threshold1 = result.getThreshold1();
                List<Integer> threshold2 = result.getThreshold2();
                List<Integer> threshold3 = result.getThreshold3();

                for (int i = 0; i < mFeatureThresholds.length; i++) {
                    mFeatureThresholds[i][0] = threshold1.get(i);
                    mFeatureThresholds[i][1] = threshold2.get(i);
                    mFeatureThresholds[i][2] = threshold3.get(i);
                }

                for (int j = 0; j < 3; j++)
                    mThresholdView.defaultThreshold[j] = mFeatureThresholds[mCurFeature][j];

                mThresholdView.setThresholds();
                refreshFeatureData(String.format("%04d", mCurFeature + 1));

                isInitThreshold = true;
                sendInitData();
            }
            else {
//                showLoading("Insert Feature Data...");
//                (new InsertFeatureDBTask()).execute(ReadDataActivity.this);
                showLoading("There is issue. Checking threshold again...");
                (new GetThresholdTask()).execute(ReadDataActivity.this);
            }
        }
    }

    class InsertFeatureDBTask extends AsyncTask<Context, Void, Void> {

        @Override
        protected Void doInBackground(Context... params) {
            if(DeviceScanActivity.myApiService == null) {  // Only do this once
                MyApi.Builder builder = new MyApi.Builder(AndroidHttp.newCompatibleTransport(), new AndroidJsonFactory(), null)
                        .setRootUrl("https://infinite-uptime-1232.appspot.com/_ah/api/");
                DeviceScanActivity.myApiService = builder.build();
            }

            try {
                DeviceScanActivity.myApiService.addFeatureRow(mServerName, mDbName, mUserName, mDeviceAddress, 1, 1, 0, "Signal Energy", 30, 600, 1200, 1, mDeviceAddress).execute();
                DeviceScanActivity.myApiService.addFeatureRow(mServerName, mDbName, mUserName, mDeviceAddress, 1, 1, 1, "Mean Crossing Rate", 100, 500, 1000, 1, mDeviceAddress).execute();
                DeviceScanActivity.myApiService.addFeatureRow(mServerName, mDbName, mUserName, mDeviceAddress, 1, 1, 2, "Spectral Centroid", 6, 7, 8, 1, mDeviceAddress).execute();
                DeviceScanActivity.myApiService.addFeatureRow(mServerName, mDbName, mUserName, mDeviceAddress, 1, 1, 3, "Spectral Flatness", 40, 42, 45, 1, mDeviceAddress).execute();
                DeviceScanActivity.myApiService.addFeatureRow(mServerName, mDbName, mUserName, mDeviceAddress, 1, 1, 4, "Accel Spectral Spread", 200, 205, 210, 1, mDeviceAddress).execute();
                DeviceScanActivity.myApiService.addFeatureRow(mServerName, mDbName, mUserName, mDeviceAddress, 1, 1, 5, "Audio Spectral Spread", 500, 1000, 1500, 1, mDeviceAddress).execute();
            } catch (IOException e) {
                e.getMessage();
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            hideLoading();
        }
    }

    private void startSendTimestampThread() {
        if (mSendTimestampThread == null) {
            mSendTimestampThread = new Thread() {
                public void run() {
                    while (isRunningTimestamp) {
                        try {
                            sleep(60 * 1000L);
                            sendTimestamp();
                        } catch (Exception e) {

                        }
                    }
                }
            };

            isRunningTimestamp = true;
            mSendTimestampThread.start();
        }
    }

    private void stopSendTimestampThread() {
        isRunningTimestamp = false;
        mSendTimestampThread = null;
    }

    private void startAddingDataThread() {
        if (mAddingDataThread != null)
            return;

        mAddingDataThread = new Thread() {
            public void run() {
                while (isRunningAddData) {
                    if(DeviceScanActivity.myApiService == null) {  // Only do this once
                        MyApi.Builder builder = new MyApi.Builder(AndroidHttp.newCompatibleTransport(), new AndroidJsonFactory(), null)
                                .setRootUrl("https://infinite-uptime-1232.appspot.com/_ah/api/");
                        DeviceScanActivity.myApiService = builder.build();
                    }

                    try {
                        if (mDataList.size() == 0) {
                            sleep(EMPTY_DATA_DELAY);
                        }
                        else {
                            int count = BUFFER_COUNT;
                            if (count > mDataList.size())
                                count = mDataList.size();

                            String dataList = "";

                            for (int i = 0; i < count; i++) {
                                if (i == 0) {
                                    dataList = mDataList.get(i);
                                }
                                else {
                                    dataList += ";" + mDataList.get(i);
                                }
                            }

                            Log.e("test", "Cloud="+dataList);

                            try {
                                DeviceScanActivity.myApiService.addIUDataMultiRow(mServerName, mDbName, mUserName, mDeviceAddress, 1, dataList).execute();

                                for (int i = count - 1; i >= 0; i--) {
                                    mDataList.remove(i);
                                }
                            } catch (IOException e) {
                                e.getMessage();
                            }

                            sleep(SENDING_DATA_DELAY);
                        }
                    }
                    catch (Exception e) {

                    }
                }
            }
        };

        isRunningAddData = true;
        mAddingDataThread.start();
    }

    private void stopAddingDataThread() {
        isRunningAddData = false;
        mAddingDataThread = null;
    }

    private void startAddingAWSThread() {
        if (mAddingAWSThread != null)
            return;

        mAddingAWSThread = new Thread() {
            public void run() {
                while (isRunningAddAWS) {
                    try {
                        if (mAWSList.size() == 0) {
                            sleep(EMPTY_DATA_DELAY);
                        }
                        else {
                            String data = mAWSList.get(0);
                            String[] msg = data.split(",");
                            String stime = msg[15].substring(0, 10) + msg[15].substring(11, 13) + "0";

                            long timestamp = Long.valueOf(stime);
                            Date date = new Date();
                            date.setTime(timestamp);
                            String time = mFormat.format(date);

                            int status = STATUS_NONE;

                            if (msg[1].contains("00")) {
                                status = STATUS_IDLE;
                            } else if (msg[1].contains("01")) {
                                status = STATUS_NORMAL_CUTTING;
                            } else if (msg[1].contains("02")) {
                                status = STATUS_WARNING;
                            } else if (msg[1].contains("03")) {
                                status = STATUS_DANGER;
                            }

                            String batteryLevel = msg[2];
                            int battery = Integer.valueOf(batteryLevel);

                            float featureValue[] = new float[6];
                            int index = 0;
                            for (int i = 4; i < 15; i += 2) {
                                featureValue[index] = Float.valueOf(msg[i]);
                                index++;
                            }

                            JSONObject jsonData = new JSONObject();

                            jsonData.put("Timestamp_Pi", time);
                            jsonData.put("MAC_ADDRESS", mDeviceAddress);
                            jsonData.put("Tool_ID", 1);
                            jsonData.put("Tool_Status", 1);
                            jsonData.put("State", status);
                            jsonData.put("Battery_Level", battery);
                            jsonData.put("Feature_Value_0", featureValue[0]);
                            jsonData.put("Feature_Value_1", featureValue[1]);
                            jsonData.put("Feature_Value_2", featureValue[2]);
                            jsonData.put("Feature_Value_3", featureValue[3]);
                            jsonData.put("Feature_Value_4", featureValue[4]);
                            jsonData.put("Feature_Value_5", featureValue[5]);

                            try {
                                QueueService.sendMessage(jsonData.toString());
                                mAWSList.remove(0);
                            } catch (Exception e) {
                                e.getMessage();
                            }

                            sleep(SENDING_DATA_DELAY);
                        }
                    }
                    catch (Exception e) {

                    }
                }
            }
        };

        isRunningAddAWS = true;
        mAddingAWSThread.start();
    }

    private void stopAddingAWSThread() {
        isRunningAddAWS = false;
        mAddingAWSThread = null;
    }

    private void startThresholdThread() {
        if (mThresholdThread != null)
            return;

        mThresholdThread = new Thread() {
            public void run() {
                while (isRunningThreshold) {
                    if(DeviceScanActivity.myApiService == null) {  // Only do this once
                        MyApi.Builder builder = new MyApi.Builder(AndroidHttp.newCompatibleTransport(), new AndroidJsonFactory(), null)
                                .setRootUrl("https://infinite-uptime-1232.appspot.com/_ah/api/");
                        DeviceScanActivity.myApiService = builder.build();
                    }

                    try {
                        if (mThresholdList == null) {
                            sleep(EMPTY_DATA_DELAY);
                        }
                        else {
                            int[] data = mThresholdList;
                            mThresholdList = null;
                            Log.d("test", "threshold=" + data[0]+":"+data[1]+":"+data[2]+":"+data[3]);
                            try {
                                DeviceScanActivity.myApiService.setThresholdDataByDevice(mServerName, mDbName, mUserName, mDeviceAddress, data[0], 1, data[1]).execute();
                                DeviceScanActivity.myApiService.setThresholdDataByDevice(mServerName, mDbName, mUserName, mDeviceAddress, data[0], 2, data[2]).execute();
                                DeviceScanActivity.myApiService.setThresholdDataByDevice(mServerName, mDbName, mUserName, mDeviceAddress, data[0], 3, data[3]).execute();
                            } catch (IOException e) {
                                e.getMessage();
                            }

                            sleep(EMPTY_DATA_DELAY);
                        }
                    }
                    catch (Exception e) {

                    }
                }
            }
        };

        isRunningThreshold = true;
        mThresholdThread.start();
    }

    private void stopThresholdThread() {
        isRunningThreshold = false;
        mThresholdThread = null;
    }
}

