﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using Google.Apis.Services;
using System.Threading;
using Newtonsoft.Json;
using System.IO.Ports;

namespace CalibrationService
{

    public partial class CalibrationService : ServiceBase
    {
        string mChangeRequestUrl = "https://infinite-uptime-1232.appspot.com/_ah/api/myApi/v1/changeRequestStatus";
        string mCheckingRequesturl = "https://infinite-uptime-1232.appspot.com/_ah/api/myApi/v1/checkingRequest/-1";
        string mSendDataUrl = "https://infinite-uptime-1232.appspot.com/_ah/api/myApi/v1/sendBlobData";
        Boolean mRunning = true;
        CalibrationStatus mCalibrationStatus;
        String mAudio = "";
        String mAccel = "";
        String mTimestamp = "";
        Thread collectorThread;

        public CalibrationService(string[] args)
        {
            InitializeComponent();
            /*
            eventLog1 = new System.Diagnostics.EventLog();
            if (!System.Diagnostics.EventLog.SourceExists("CalibrationService"))
            {
                System.Diagnostics.EventLog.CreateEventSource(
                    "CalibrationService", "CalibrationServiceLog");
            }
            eventLog1.Source = "CalibrationService";
            eventLog1.Log = "CalibrationServiceLog";*/
        }

        public static int ConvertToUnixTimestamp(DateTime date)
        {
            DateTime origin = new DateTime(1970, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc);
            TimeSpan diff = date.ToUniversalTime() - origin;
            return (int) Math.Floor(diff.TotalMilliseconds);
        }

        protected override void OnStart(string[] args)
        {
            //eventLog1.WriteEntry("In OnStart");
            
            mRunning = true;
            collectorThread = new Thread(delegate ()
            {
                while (mRunning)
                {
                    try
                    {
                        String responseJson = HttpPost(mCheckingRequesturl, "");
                        mCalibrationStatus = JsonConvert.DeserializeObject<CalibrationStatus>(responseJson);

                        if (mCalibrationStatus.id != -1 && mCalibrationStatus.status == 0)
                        {
                            SerialPort ser = new SerialPort(mCalibrationStatus.port_num, 32800);

                            try
                            {
                                ser.Open();
                            }
                            catch (Exception ex)
                            {
                                //HttpPost(mChangeRequestUrl + "/" + mCalibrationStatus.id + "/3/" + "Failed to open " + mCalibrationStatus.port_num + "!", "");
                                HttpPost(mChangeRequestUrl + "/" + mCalibrationStatus.id + "/3/" + "Failed", "");
                                continue;
                            }

                            if (!ser.IsOpen)
                            {
                                HttpPost(mChangeRequestUrl + "/" + mCalibrationStatus.id + "/3/" + "Failed", "");
                                //HttpPost(mChangeRequestUrl + "/" + mCalibrationStatus.id + "/3/" + "Failed to open " + mCalibrationStatus.port_num + "!", "");
                                continue;
                            }

                            byte[] audio_data = new byte[4];
                            byte[] accel_data = new byte[4];
                            byte[] convert_buff = new byte[4];

                            mAudio = "";
                            mAccel = "";
                            mTimestamp = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss.fff");
                            int startTime = ConvertToUnixTimestamp(DateTime.UtcNow);

                            //mAudio = mAudio + mTimestamp + ";";
                            //mAccel = mAccel + mTimestamp + ";";

                            int totalSize = 0;

                            //ser.Write("acosr=08!");
                            ser.Write("rgbRun=101!");
                            //ser.Write("accsr=1000!!");
                            ser.Write("Arange=1!");

                            float audioSampRate = SetAcousticSamplingRate(ser, 4);
                            float accelSampRate = SetAccelerometerSamplingRate(ser, 7);

                            int BATCH_SIZE = (int)(1000f * audioSampRate / accelSampRate * 3 + 12);

                            try
                            {
                                ser.ReadExisting();
                            }
                            catch (Exception ex)
                            {
                                //HttpPost(mChangeRequestUrl + "/" + mCalibrationStatus.id + "/3/" + "Reading Exception", "");
                                HttpPost(mChangeRequestUrl + "/" + mCalibrationStatus.id + "/3/" + "Exception", "");
                                continue;
                            }

                            while (startTime >= ConvertToUnixTimestamp(DateTime.UtcNow) - mCalibrationStatus.testing_cycle * 1000 && mRunning)
                            {
                                if (ser.BytesToRead != 0)
                                {
                                    int batchAlignCheck = ser.BytesToRead % BATCH_SIZE;
                                    if (batchAlignCheck == 0)
                                    {
                                        totalSize += ser.BytesToRead;

                                        //String st = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss.fff");
                                        //mAudio = mAudio + st + ";";
                                        //mAccel = mAccel + st + ";";

                                        int numBatches = ser.BytesToRead / BATCH_SIZE;
                                        int sampRatio = (int)(audioSampRate * 1000f / accelSampRate);

                                        for (int i = 0; i < numBatches; i++)
                                        {
                                            for (int j = 0; j < sampRatio; j++)
                                            {
                                                int numReadBytes = ser.Read(audio_data, 0, 3);
                                                audio_data[3] = 0x00;
                                                Array.Copy(audio_data, convert_buff, 4);
                                                if (BitConverter.IsLittleEndian)
                                                    Array.Reverse(convert_buff);
                                                int audio_data_parsed = BitConverter.ToInt32(convert_buff, 0);

                                                mAudio = mAudio + audio_data_parsed.ToString() + ";";
                                            }

                                            for (int j = 0; j < 3; j++)
                                            {
                                                ser.Read(accel_data, 0, 4);
                                                Array.Copy(accel_data, convert_buff, 4);
                                                if (!BitConverter.IsLittleEndian)
                                                    convert_buff.Reverse();
                                                float accel_data_parsed = BitConverter.ToSingle(convert_buff, 0);
                                                mAccel = mAccel + accel_data_parsed.ToString() + " ";
                                            }

                                            mAccel = mAccel + ";";
                                        }
                                    }
                                    else
                                    {
                                        ser.ReadExisting();
                                    }
                                }
                            }

                            //Close all resources;
                            ser.Close();

                            String param = "{\"audioFileName\":\"audio\", \"audioFileSize\":\"0\", \"audioFileData\":\"" + mAudio + "\", \"accelFileName\":\"accel\", \"accelFileSize\":\"0\", \"accelFileData\":\"" + mAccel + "\"}";
                            String response = HttpPost(mSendDataUrl + "/" + mCalibrationStatus.id + "/2/device_id/" + mCalibrationStatus.port_num + "/" + mTimestamp, param);
                            FileData fileData = JsonConvert.DeserializeObject<FileData>(response);
                        }
                    }
                    catch (Exception ex)
                    {

                    }

                    Thread.Sleep(1000);
                }

                collectorThread = null;
            });

            collectorThread.Start();
        }

        protected override void OnStop()
        {
            //eventLog1.WriteEntry("In OnStop");
            mRunning = false;
        }

        protected override void OnContinue()
        {
            //eventLog1.WriteEntry("In OnContinue.");
        }

        public static string HttpGet(string URI)
        {
            System.Net.WebRequest req = System.Net.WebRequest.Create(URI);
            req.Proxy = new System.Net.WebProxy("http://192.168.1.114:8118/default.pac", true); //true means no proxy
            System.Net.WebResponse resp = req.GetResponse();
            System.IO.StreamReader sr = new System.IO.StreamReader(resp.GetResponseStream());
            return sr.ReadToEnd().Trim();
        }

        public static string HttpPost(string URI, string Parameters)
        {
            System.Net.WebRequest req = System.Net.WebRequest.Create(URI);
            req.Proxy = new System.Net.WebProxy("http://192.168.1.114:8118/default.pac", true);
            //Add these, as we're doing a POST
            req.ContentType = "application/json; charset=UTF-8";
            req.Method = "POST";

            //We need to count how many bytes we're sending. Post'ed Faked Forms should be name=value&
            byte[] bytes = System.Text.Encoding.ASCII.GetBytes(Parameters);
            req.ContentLength = bytes.Length;
            System.IO.Stream os = req.GetRequestStream();
            os.Write(bytes, 0, bytes.Length); //Push it out there
            os.Close();
            System.Net.WebResponse resp = req.GetResponse();
            if (resp == null) return null;
            System.IO.StreamReader sr = new System.IO.StreamReader(resp.GetResponseStream());
            return sr.ReadToEnd().Trim();
        }

        int SetAcousticSamplingRate(SerialPort ser, int acoSR)
        {
            int[] nBytesArray = { 1, 2, 3, 4, 8, 12, 16, 24, 48 };

            if (acoSR == 0)
            {
                ser.Write("acosr=01!");
            }
            else if (acoSR == 1)
            {
                ser.Write("acosr=02!");
            }
            else if (acoSR == 2)
            {
                ser.Write("acosr=03!");
            }
            else if (acoSR == 3)
            {
                ser.Write("acosr=04!");
            }
            else if (acoSR == 4)
            {
                ser.Write("acosr=08!");
            }
            else if (acoSR == 5)
            {
                ser.Write("acosr=12!");
            }
            else if (acoSR == 6)
            {
                ser.Write("acosr=16!");
            }
            else if (acoSR == 7)
            {
                ser.Write("acosr=24!");
            }
            else if (acoSR == 8)
            {
                ser.Write("acosr=48!");
            }

            return nBytesArray[acoSR];
        }

        float SetAccelerometerSamplingRate(SerialPort ser, int accSR)
        {
            float[] nBytesArray = { 1000f / 128f, 1000f / 64f, 1000f / 32f, 1000f / 16f, 125, 250, 500, 1000 };

            if (accSR == 0)
            {
                ser.Write("accsr=0008!");
            }
            else if (accSR == 1)
            {
                ser.Write("accsr=0016!");
            }
            else if (accSR == 2)
            {
                ser.Write("accsr=0031!");
            }
            else if (accSR == 3)
            {
                ser.Write("accsr=0063!");
            }
            else if (accSR == 4)
            {
                ser.Write("accsr=0125!");
            }
            else if (accSR == 5)
            {
                ser.Write("accsr=0250!");
            }
            else if (accSR == 6)
            {
                ser.Write("accsr=0500!");
            }
            else if (accSR == 7)
            {
                ser.Write("accsr=1000!");
            }

            return nBytesArray[accSR];
        }

        public class CalibrationStatus
        {
            public int id { get; set; }
            public string timestamp { get; set; }
            public string device_id { get; set; }
            public string port_num { get; set; }
            public int testing_cycle { get; set; }
            public int status { get; set; }
        }

        public class FileData
        {
            public String audioFileName { get; set; }
            public long audioFileSize { get; set; }
            public String audioFileData { get; set; }
            public String accelFileName { get; set; }
            public long accelFileSize { get; set; }
            public String accelFileData { get; set; }
        }
    }

}
