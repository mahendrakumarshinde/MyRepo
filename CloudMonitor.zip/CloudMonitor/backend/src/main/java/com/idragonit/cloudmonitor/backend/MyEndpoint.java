/*
   For step-by-step instructions on connecting your Android application to this backend module,
   see "App Engine Java Endpoints Module" template documentation at
   https://github.com/GoogleCloudPlatform/gradle-appengine-templates/tree/master/HelloEndpoints
*/

package com.idragonit.cloudmonitor.backend;

import com.google.api.server.spi.config.Api;
import com.google.api.server.spi.config.ApiMethod;
import com.google.api.server.spi.config.ApiNamespace;
import com.google.appengine.api.utils.SystemProperty;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.inject.Named;

/** An endpoint class we are exposing */
@Api(
  name = "myApi",
  version = "v1",
  namespace = @ApiNamespace(
    ownerDomain = "backend.cloudmonitor.idragonit.com",
    ownerName = "backend.cloudmonitor.idragonit.com",
    packagePath=""
  )
)
public class MyEndpoint {
    public String database_url = "jdbc:google:mysql://infinite-uptime-1232:server0/InfiniteUptime?user=root";
    public String database_url_format = "jdbc:google:mysql://infinite-uptime-1232:%s/%s?user=%s";

    /** A simple endpoint method that takes a name and says Hi back */
    @ApiMethod(name = "sayHi")
    public MyBean sayHi(@Named("name") String name) {
        MyBean response = new MyBean();
        response.setData("Hi, " + name);

        return response;
    }

    @ApiMethod(name = "getMacAddressList")
    public final ArrayList<String> getMacAddressList() throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = database_url;
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);
        PreparedStatement stmt = conn.prepareStatement("SELECT MAC_ADDRESS FROM Feature_Dictionary WHERE Status = ? GROUP BY MAC_ADDRESS");
        stmt.setInt(1, 1);
        ResultSet rs =  stmt.executeQuery();

        ArrayList<String> listMacAddress = new ArrayList<String>();


        while (rs.next()) {
            listMacAddress.add(rs.getString(1));
        }

        conn.close();

        return listMacAddress;
    }

    @ApiMethod(name = "getWholeMacAddressList")
    public final ArrayList<MacAddressInfo> getWholeMacAddressList(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);
        PreparedStatement stmt = conn.prepareStatement("SELECT MAC_ADDRESS, Status FROM Feature_Dictionary GROUP BY MAC_ADDRESS");
        ResultSet rs =  stmt.executeQuery();

        ArrayList<MacAddressInfo> listMacAddress = new ArrayList<MacAddressInfo>();

        while (rs.next()) {
            MacAddressInfo address = new MacAddressInfo();

            address.setMacAddress(rs.getString(1));
            address.setStatus(rs.getInt(2));

            listMacAddress.add(address);
        }

        conn.close();

        return listMacAddress;
    }

    @ApiMethod(name = "userLogin")
    public final UserInfo userLogin(@Named("userName") String userName, @Named("password") String password) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = database_url;
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);
        PreparedStatement stmt = conn.prepareStatement("SELECT * FROM UserInformation WHERE user_name = ? and password = ?");
        stmt.setString(1, userName);
        stmt.setString(2, password);

        ResultSet rs =  stmt.executeQuery();
        UserInfo userInfo = new UserInfo();

        if (rs.next()) {
            userInfo.setUserName(rs.getString(2));
            userInfo.setDbName(Utils.encodeDBName(rs.getString(4)));
        }

        conn.close();

        return userInfo;
    }

    @ApiMethod(name = "getDataList")
    public final List<IUDeviceData> getDataList(@Named("id") Integer id, @Named("address") String address) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = database_url;
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);
        PreparedStatement stmt = conn.prepareStatement("SELECT * FROM IU_device_data WHERE Id > ? and MAC_ADDRESS = ?");
        stmt.setInt(1, id);
        stmt.setString(2, address);
        ResultSet rs =  stmt.executeQuery();

        List<IUDeviceData> listData = new ArrayList<IUDeviceData>();

        while (rs.next()) {
            IUDeviceData value = new IUDeviceData();

            value.setId(rs.getInt(1));
            value.setTimeStampDB(rs.getString(2));
            value.setTimeStampPi(rs.getString(3));
            value.setMacAddress(rs.getString(4));
            value.setState(rs.getInt(5));
            value.setBatteryLevel(rs.getFloat(6));
            value.setFeatureValue0(rs.getFloat(7));
            value.setFeatureValue1(rs.getFloat(8));
            value.setFeatureValue2(rs.getFloat(9));
            value.setFeatureValue3(rs.getFloat(10));
            value.setFeatureValue4(rs.getFloat(11));
            value.setFeatureValue5(rs.getFloat(12));

            listData.add(value);
        }

        conn.close();

        return listData;
    }

    @ApiMethod(name = "getDataListByDB")
    public final List<IUDeviceData> getDataListByDB(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username,
                                                @Named("id") Integer id, @Named("address") String address) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);
        PreparedStatement stmt = conn.prepareStatement("SELECT * FROM IU_device_data WHERE Id > ? and MAC_ADDRESS = ?");
        stmt.setInt(1, id);
        stmt.setString(2, address);
        ResultSet rs =  stmt.executeQuery();

        List<IUDeviceData> listData = new ArrayList<IUDeviceData>();

        while (rs.next()) {
            IUDeviceData value = new IUDeviceData();

            value.setId(rs.getInt(1));
            value.setTimeStampDB(rs.getString(2));
            value.setTimeStampPi(rs.getString(3));
            value.setMacAddress(rs.getString(4));
            value.setState(rs.getInt(5));
            value.setBatteryLevel(rs.getFloat(6));
            value.setFeatureValue0(rs.getFloat(7));
            value.setFeatureValue1(rs.getFloat(8));
            value.setFeatureValue2(rs.getFloat(9));
            value.setFeatureValue3(rs.getFloat(10));
            value.setFeatureValue4(rs.getFloat(11));
            value.setFeatureValue5(rs.getFloat(12));

            listData.add(value);
        }

        conn.close();

        return listData;
    }

    @ApiMethod(name = "getDataListLast25")
    public final List<IUDeviceData> getDataListLast25(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username,
                                                    @Named("address") String address) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);
        PreparedStatement stmt = conn.prepareStatement("SELECT * FROM IU_device_data WHERE MAC_ADDRESS = ? LIMIT 25");
        stmt.setString(1, address);
        ResultSet rs =  stmt.executeQuery();

        List<IUDeviceData> listData = new ArrayList<IUDeviceData>();

        while (rs.next()) {
            IUDeviceData value = new IUDeviceData();

            value.setId(rs.getInt(1));
            value.setTimeStampDB(rs.getString(2));
            value.setTimeStampPi(rs.getString(3));
            value.setMacAddress(rs.getString(4));
            value.setState(rs.getInt(5));
            value.setBatteryLevel(rs.getFloat(6));
            value.setFeatureValue0(rs.getFloat(7));
            value.setFeatureValue1(rs.getFloat(8));
            value.setFeatureValue2(rs.getFloat(9));
            value.setFeatureValue3(rs.getFloat(10));
            value.setFeatureValue4(rs.getFloat(11));
            value.setFeatureValue5(rs.getFloat(12));

            listData.add(value);
        }

        conn.close();

        return listData;
    }

    @ApiMethod(name = "getIUDataList")
    public final List<IUDeviceDataWeb> getIUDataList(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username,
                                                     @Named("from") String from, @Named("to") String to, @Named("address") String address) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);

        String query = "SELECT * FROM IU_device_data WHERE Id > -1";

        if (address != null && !address.equalsIgnoreCase("all")) {
            query += " and MAC_ADDRESS = ?";
        }

        if (from != null && !from.equalsIgnoreCase("all")) {
            query += " and Timestamp_Pi >= ?";
        }

        if (to != null && !to.equalsIgnoreCase("all")) {
            query += " and Timestamp_Pi <= ?";
        }

        PreparedStatement stmt = conn.prepareStatement(query);
        int index = 1;

        if (address != null && !address.equalsIgnoreCase("all")) {
            stmt.setString(index, address);
            index++;
        }

        if (from != null && !from.equalsIgnoreCase("all")) {
            stmt.setString(index, from);
            index++;
        }

        if (to != null && !to.equalsIgnoreCase("all")) {
            stmt.setString(index, to);
            index++;
        }

        ResultSet rs =  stmt.executeQuery();
        List<IUDeviceDataWeb> listData = new ArrayList<IUDeviceDataWeb>();

        while (rs.next()) {
            IUDeviceDataWeb value = new IUDeviceDataWeb();

            value.setId(rs.getInt(1));
            value.setTimeStampDB(rs.getString(2));
            value.setTimeStampPi(rs.getString(3));
            value.setMacAddress(rs.getString(4));
            value.setState(rs.getInt(5));
            value.setBatteryLevel(rs.getFloat(6));
            value.setFeatureValue0(rs.getFloat(7));
            value.setFeatureValue1(rs.getFloat(8));
            value.setFeatureValue2(rs.getFloat(9));
            value.setFeatureValue3(rs.getFloat(10));
            value.setFeatureValue4(rs.getFloat(11));
            value.setFeatureValue5(rs.getFloat(12));

            listData.add(value);
        }

        conn.close();

        return listData;
    }

    @ApiMethod(name = "getFeatureList")
    public final List<FeatureDictionary> getFeatureList(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username, @Named("address") String address, @Named("featureId") Integer featureId) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);

        String query = "SELECT * FROM Feature_Dictionary";
        boolean existsMacAddress = false;

        if (address != null && !address.equalsIgnoreCase("all")) {
            query += " WHERE MAC_ADDRESS = ?";
            existsMacAddress = true;
        }

        if (featureId > 0) {
            if (existsMacAddress)
                query += " and Feature_ID = ?";
            else
                query += " WHERE Feature_ID = ?";
        }

        PreparedStatement stmt = conn.prepareStatement(query);
        int index = 1;

        if (address != null && !address.equalsIgnoreCase("all")) {
            stmt.setString(index, address);
            index++;
        }

        if (featureId > 0) {
            stmt.setInt(index, featureId - 1);
            index++;
        }

        ResultSet rs =  stmt.executeQuery();

        List<FeatureDictionary> listData = new ArrayList<FeatureDictionary>();

        while (rs.next()) {
            FeatureDictionary value = new FeatureDictionary();

            value.setMacAddress(rs.getString(1));
            value.setFeatureID(rs.getInt(2));
            value.setFeatureName(rs.getString(3));
            value.setThreshold1(rs.getInt(4));
            value.setThreshold2(rs.getInt(5));
            value.setThreshold3(rs.getInt(6));
            value.setStatus(rs.getInt(7));

            listData.add(value);
        }

        conn.close();

        return listData;
    }

    @ApiMethod(name = "addIUData")
    public final void addIUData(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username,
                                @Named("macAddress") String macAddress, @Named("state") Integer state, @Named("batteryLevel") Integer batteryLevel,
                                @Named("featureValue0") Float featureValue0, @Named("featureValue1") Float featureValue1, @Named("featureValue2") Float featureValue2,
                                @Named("featureValue3") Float featureValue3, @Named("featureValue4") Float featureValue4, @Named("featureValue5") Float featureValue5) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.S");
        String time = format.format(new java.util.Date());

        Connection conn = DriverManager.getConnection(url);
        PreparedStatement stmt = conn.prepareStatement("Insert Into IU_device_data (Timestamp_Pi, MAC_ADDRESS, State, Battery_Level, Feature_Value_0, Feature_Value_1, Feature_Value_2, Feature_Value_3, Feature_Value_4, Feature_Value_5) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);");

        stmt.setString(1, time);
        stmt.setString(2, macAddress);
        stmt.setInt(3, state);
        stmt.setInt(4, batteryLevel);
        stmt.setFloat(5, featureValue0);
        stmt.setFloat(6, featureValue1);
        stmt.setFloat(7, featureValue2);
        stmt.setFloat(8, featureValue3);
        stmt.setFloat(9, featureValue4);
        stmt.setFloat(10, featureValue5);

        stmt.executeUpdate();
        conn.close();
    }

    @ApiMethod(name = "addFeature")
    public final void addFeature(@Named("macAddress") String macAddress, @Named("featureId") Integer featureId, @Named("featureName") String featureName,
                                 @Named("threshold1") Integer threshold1, @Named("threshold2") Integer threshold2, @Named("threshold3") Integer threshold3) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = database_url;
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);
        PreparedStatement stmt = conn.prepareStatement("Insert Into Feature_Dictionary (MAC_ADDRESS, Feature_ID, Feature_Name, Threshold_1, Threshold_2, Threshold_3) VALUES (?, ?, ?, ?, ?, ?);");

        stmt.setString(1, macAddress);
        stmt.setInt(2, featureId);
        stmt.setString(3, featureName);
        stmt.setInt(4, threshold1);
        stmt.setInt(5, threshold2);
        stmt.setInt(6, threshold3);

        stmt.executeUpdate();
        conn.close();
    }

    @ApiMethod(name = "updateFeature")
    public final void updateFeature(@Named("macAddress") String macAddress, @Named("featureId") Integer featureId, @Named("featureName") String featureName,
                                 @Named("threshold1") Integer threshold1, @Named("threshold2") Integer threshold2, @Named("threshold3") Integer threshold3) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = database_url;
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);
        PreparedStatement stmt = conn.prepareStatement("Update Feature_Dictionary SET MAC_ADDRESS = ?, Feature_ID = ?, Feature_Name = ?, Threshold_1 = ?, Threshold_2 = ?, Threshold_3 = ? WHERE MAC_ADDRESS = ? AND Feature_ID = ?;");

        stmt.setString(1, macAddress);
        stmt.setInt(2, featureId);
        stmt.setString(3, featureName);
        stmt.setInt(4, threshold1);
        stmt.setInt(5, threshold2);
        stmt.setInt(6, threshold3);
        stmt.setString(7, macAddress);
        stmt.setInt(8, featureId);

        stmt.executeUpdate();
        conn.close();
    }

    @ApiMethod(name = "setThresholdData")
    public final void setThresholdData(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username,
                                       @Named("macAddress") String macAddress, @Named("featureId") Integer featureId, @Named("featureIndex") Integer featureIndex,
                                       @Named("featureValue") Integer featureValue) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);
        PreparedStatement stmt = conn.prepareStatement("Update Feature_Dictionary SET MAC_ADDRESS = ?, Feature_ID = ?, Threshold_" + featureIndex + " = ? WHERE MAC_ADDRESS = ? AND Feature_ID = ?;");

        stmt.setString(1, macAddress);
        stmt.setInt(2, featureId);
        stmt.setInt(3, featureValue);
        stmt.setString(4, macAddress);
        stmt.setInt(5, featureId);

        stmt.executeUpdate();
        conn.close();
    }

    @ApiMethod(name = "updateFeatureStatus")
    public final void updateFeatureStatus(@Named("macAddress") String macAddress, @Named("status") Integer status) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = database_url;
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);
        PreparedStatement stmt = conn.prepareStatement("Update Feature_Dictionary SET Status = ? WHERE MAC_ADDRESS = ?;");

        stmt.setInt(1, status);
        stmt.setString(2, macAddress);

        stmt.executeUpdate();
        conn.close();
    }

    @ApiMethod(name = "setSync")
    public final void setSync(@Named("resetValue") Integer resetValue) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = database_url;
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);
        PreparedStatement stmt = conn.prepareStatement("Update Env_variables SET reset_value = ?;");

        stmt.setInt(1, resetValue);

        stmt.executeUpdate();
        conn.close();
    }

    @ApiMethod(name = "setSyncByDB")
    public final void setSyncByDB(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username, @Named("resetValue") Integer resetValue) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);
        PreparedStatement stmt = conn.prepareStatement("Update Env_variables SET reset_value = ?;");

        stmt.setInt(1, resetValue);

        stmt.executeUpdate();
        conn.close();
    }

    @ApiMethod(name = "getSyncValue")
    public final SyncValue getSyncValue() throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = database_url;
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);
        PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Env_variables");

        ResultSet rs =  stmt.executeQuery();
        List<IUDeviceDataWeb> listData = new ArrayList<IUDeviceDataWeb>();

        SyncValue value = new SyncValue();

        if (rs.next()) {
            value.setResetValue(rs.getInt(1));
        }

        conn.close();

        return value;
    }

    @ApiMethod(name = "getSyncValueByDB")
    public final SyncValue getSyncValueByDB(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);
        PreparedStatement stmt = conn.prepareStatement("SELECT * FROM Env_variables");

        ResultSet rs =  stmt.executeQuery();
        List<IUDeviceDataWeb> listData = new ArrayList<IUDeviceDataWeb>();

        SyncValue value = new SyncValue();

        if (rs.next()) {
            value.setResetValue(rs.getInt(1));
        }

        conn.close();

        return value;
    }

    @ApiMethod(name = "getDeviceStatusList")
    public final List<DeviceStatus> getDeviceStatusList(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username, @Named("address") String address) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);

        String query = "SELECT MAC_ADDRESS, Status FROM Feature_Dictionary";

        if (address != null && !address.equalsIgnoreCase("all")) {
            query += " WHERE MAC_ADDRESS = ?";
        }

        query += " GROUP BY MAC_ADDRESS";

        PreparedStatement stmt = conn.prepareStatement(query);

        if (address != null && !address.equalsIgnoreCase("all")) {
            stmt.setString(1, address);
        }

        ResultSet rs =  stmt.executeQuery();

        List<DeviceStatus> listData = new ArrayList<DeviceStatus>();

        while (rs.next()) {
            DeviceStatus value = new DeviceStatus();

            value.setMacAddress(rs.getString(1));
            value.setStatus(rs.getInt(2));

            listData.add(value);
        }

        if (address != null && !address.equalsIgnoreCase("all") && listData.size() == 1) {
            query = "SELECT MAC_ADDRESS, Battery_Level FROM IU_device_data WHERE MAC_ADDRESS = ? ORDER BY Id DESC LIMIT " + listData.size();
            stmt = conn.prepareStatement(query);
            stmt.setString(1, address);

            rs =  stmt.executeQuery();

            if (rs.next()) {
                DeviceStatus value = listData.get(0);
                value.setBatteryLevel(rs.getFloat(2));
            }
        }
        else {
            for (int i = 0; i < listData.size(); i++) {
                DeviceStatus value = listData.get(i);

                query = "SELECT MAC_ADDRESS, Battery_Level FROM IU_device_data WHERE MAC_ADDRESS = ? ORDER BY Id DESC LIMIT " + listData.size();
                stmt = conn.prepareStatement(query);
                stmt.setString(1, value.getMacAddress());

                rs =  stmt.executeQuery();

                if (rs.next()) {
                    value.setBatteryLevel(rs.getFloat(2));
                }
            }
        }

        conn.close();

        return listData;
    }

    @ApiMethod(name = "getProductivityDataList")
    public final List<ProductivityData> getProductivityDataList(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username,
                                                                @Named("from") String from, @Named("to") String to, @Named("address") String address) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);

        PreparedStatement stmtMacAddress = conn.prepareStatement("SELECT MAC_ADDRESS FROM Feature_Dictionary GROUP BY MAC_ADDRESS");
        ResultSet rsMacAddress =  stmtMacAddress.executeQuery();

        ArrayList<String> listMacAddress = new ArrayList<String>();

        while (rsMacAddress.next()) {
            listMacAddress.add(rsMacAddress.getString(1));
        }

        String query = "SELECT * FROM IU_device_data WHERE Id > -1";

        if (address != null && !address.equalsIgnoreCase("all")) {
            query += " and MAC_ADDRESS = ?";
        }

        if (from != null && !from.equalsIgnoreCase("all")) {
            query += " and Timestamp_Pi >= ?";
        }

        if (to != null && !to.equalsIgnoreCase("all")) {
            query += " and Timestamp_Pi <= ?";
        }

        query += " ORDER BY Timestamp_Pi";

        PreparedStatement stmt = conn.prepareStatement(query);
        int index = 1;

        if (address != null && !address.equalsIgnoreCase("all")) {
            stmt.setString(index, address);
            index++;
        }

        if (from != null && !from.equalsIgnoreCase("all")) {
            stmt.setString(index, from);
            index++;
        }

        if (to != null && !to.equalsIgnoreCase("all")) {
            stmt.setString(index, to);
            index++;
        }

        ResultSet rs =  stmt.executeQuery();
        List<ProductivityData> listData = new ArrayList<ProductivityData>();
        HashMap<String, ProductivityData> mapData = new HashMap<String, ProductivityData>();

        if (address != null && !address.equalsIgnoreCase("all")) {
            ProductivityData data = new ProductivityData();
            data.setMacAddress(address);
            data.setTotalTime(0L);

            mapData.put(address, data);
            listData.add(data);
        }
        else {
            for (int i = 0; i < listMacAddress.size(); i++) {
                ProductivityData data = new ProductivityData();
                data.setMacAddress(listMacAddress.get(i));
                data.setTotalTime(0L);

                mapData.put(listMacAddress.get(i), data);
                listData.add(data);
            }
        }

        while (rs.next()) {
            String time = rs.getString(3);
            String macAddress = rs.getString(4);
            int state = rs.getInt(5);

            long milliseconds = Utils.convertDateToMilliseconds(time);

            if (milliseconds == -1L)
                continue;

            ProductivityData data = mapData.get(macAddress);

            if (data == null) {
                continue;
            }

            ProductivityInfo info;

            if (data.getProductivityInfo().size() == 0) {
                info = new ProductivityInfo();
                info.setState(state);
                info.setStartTime(milliseconds);
                info.setEndTime(milliseconds);

                info.setStartTimePi(time);
                info.setEndTimePi(time);

                data.getProductivityInfo().add(info);
            }
            else {
                info = data.getProductivityInfo().get(data.getProductivityInfo().size() - 1);
                info.setEndTime(milliseconds);
                info.setEndTimePi(time);

                if (info.getState() != state) {
                    info = new ProductivityInfo();
                    info.setState(state);
                    info.setStartTime(milliseconds);
                    info.setEndTime(milliseconds);

                    info.setStartTimePi(time);
                    info.setEndTimePi(time);

                    data.getProductivityInfo().add(info);
                }
            }
        }

        conn.close();

        for (int i = 0; i < listData.size(); i++) {
            ProductivityData data = listData.get(i);

            for (int j = 0; j < data.getProductivityInfo().size(); j++) {
                ProductivityInfo info = data.getProductivityInfo().get(j);
                data.setTotalTime(data.getTotalTime() + info.getDuration());
                info.setTimeLabel(Utils.convertTimeToString(info.getDuration()));
            }

            data.setTimeLabel(Utils.convertTimeToString(data.getTotalTime()));
        }

        return listData;
    }

    @ApiMethod(name = "getMonitoringDataList")
    public final List<MonitoringData> getMonitoringDataList(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username,
                                                            @Named("from") String from, @Named("to") String to, @Named("address") String address, @Named("featureId") Integer featureId) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);

        String query = "SELECT * FROM Feature_Dictionary";
        boolean existsMacAddress = false;

        if (address != null && !address.equalsIgnoreCase("all")) {
            query += " WHERE MAC_ADDRESS = ?";
            existsMacAddress = true;
        }

        if (featureId > 0) {
            if (existsMacAddress)
                query += " and Feature_ID = ?";
            else
                query += " WHERE Feature_ID = ?";
        }

        PreparedStatement stmt = conn.prepareStatement(query);
        int index = 1;

        if (address != null && !address.equalsIgnoreCase("all")) {
            stmt.setString(index, address);
            index++;
        }

        if (featureId > 0) {
            stmt.setInt(index, featureId - 1);
            index++;
        }

        ResultSet rs =  stmt.executeQuery();

        List<MonitoringData> listData = new ArrayList<MonitoringData>();
        HashMap<String, MonitoringData> mapData = new HashMap<String, MonitoringData>();

        while (rs.next()) {
            MonitoringData data = new MonitoringData();

            data.getFeatureDictionary().setMacAddress(rs.getString(1));
            data.getFeatureDictionary().setFeatureID(rs.getInt(2));
            data.getFeatureDictionary().setFeatureName(rs.getString(3));
            data.getFeatureDictionary().setThreshold1(rs.getInt(4));
            data.getFeatureDictionary().setThreshold2(rs.getInt(5));
            data.getFeatureDictionary().setThreshold3(rs.getInt(6));
            data.getFeatureDictionary().setStatus(rs.getInt(7));

            listData.add(data);
            mapData.put(data.getFeatureDictionary().getMacAddress() + "_" + data.getFeatureDictionary().getFeatureID(), data);
        }

        query = "SELECT * FROM IU_device_data WHERE Id > -1";

        if (address != null && !address.equalsIgnoreCase("all")) {
            query += " and MAC_ADDRESS = ?";
        }

        if (from != null && !from.equalsIgnoreCase("all")) {
            query += " and Timestamp_Pi >= ?";
        }

        if (to != null && !to.equalsIgnoreCase("all")) {
            query += " and Timestamp_Pi <= ?";
        }

        query += " ORDER BY Timestamp_Pi";

        stmt = conn.prepareStatement(query);
        index = 1;

        if (address != null && !address.equalsIgnoreCase("all")) {
            stmt.setString(index, address);
            index++;
        }

        if (from != null && !from.equalsIgnoreCase("all")) {
            stmt.setString(index, from);
            index++;
        }

        if (to != null && !to.equalsIgnoreCase("all")) {
            stmt.setString(index, to);
            index++;
        }

        rs =  stmt.executeQuery();

        while (rs.next()) {
            String time = rs.getString(3);
            String macAddress = rs.getString(4);
            int state = rs.getInt(5);
            long milliseconds = Utils.convertDateToMilliseconds(time);

            if (milliseconds == -1L)
                continue;

            for (int i = 0; i < 6; i++) {
                MonitoringData data = mapData.get(macAddress + "_" + i);

                if (data == null)
                    continue;

                FeatureInfo info;
                Float featureValue = rs.getFloat(7 + i);

                if (data.getFeatureInfo().size() == 0) {
                    info = new FeatureInfo();
                    info.setState(state);
                    info.setFeatureValue(featureValue);
                    info.setStartTime(milliseconds);
                    info.setEndTime(milliseconds);

                    info.setStartTimePi(time);
                    info.setEndTimePi(time);

                    data.setMaxValue(info.getFeatureValue());
                    data.setMinValue(info.getFeatureValue());

                    data.addFeatureInfo(info);
                }
                else {
                    info = data.getFeatureInfo().get(data.getFeatureInfo().size() - 1);
                    info.setEndTime(milliseconds);
                    info.setEndTimePi(time);

                    if (info.getState() != state || info.getFeatureValue() != featureValue) {
                        info = new FeatureInfo();
                        info.setState(state);
                        info.setFeatureValue(featureValue);
                        info.setStartTime(milliseconds);
                        info.setEndTime(milliseconds);

                        info.setStartTimePi(time);
                        info.setEndTimePi(time);

                        if (data.getMaxValue() < info.getFeatureValue())
                            data.setMaxValue(info.getFeatureValue());

                        if (data.getMinValue() > info.getFeatureValue())
                            data.setMinValue(info.getFeatureValue());

                        data.addFeatureInfo(info);
                    }
                }
            }
        }

        conn.close();

        for (int i = 0; i < listData.size(); i++) {
            MonitoringData data = listData.get(i);

            long curTime = 0L;
            for (int j = 0; j < data.getFeatureInfo().size(); j++) {
                FeatureInfo info = data.getFeatureInfo().get(j);
                long duration = info.getDuration();
                curTime = curTime + duration;
                info.setTimeLabel(Utils.convertTimeToString(curTime));
            }

            if (data.getMaxValue() < data.getFeatureDictionary().getThreshold1())
                data.setMaxValue(data.getFeatureDictionary().getThreshold1().floatValue());
            if (data.getMinValue() > data.getFeatureDictionary().getThreshold1())
                data.setMinValue(data.getFeatureDictionary().getThreshold1().floatValue());
            if (data.getMaxValue() < data.getFeatureDictionary().getThreshold2())
                data.setMaxValue(data.getFeatureDictionary().getThreshold2().floatValue());
            if (data.getMinValue() > data.getFeatureDictionary().getThreshold2())
                data.setMinValue(data.getFeatureDictionary().getThreshold2().floatValue());
            if (data.getMaxValue() < data.getFeatureDictionary().getThreshold3())
                data.setMaxValue(data.getFeatureDictionary().getThreshold3().floatValue());
            if (data.getMinValue() > data.getFeatureDictionary().getThreshold3())
                data.setMinValue(data.getFeatureDictionary().getThreshold3().floatValue());

            data.setMaxValue(data.getMaxValue() + 50f);
            data.setMinValue(data.getMinValue() - 50f);
            if (data.getMinValue() > 0f)
                data.setMinValue(0f);
        }

        return listData;
    }

    @ApiMethod(name = "getMachineInfoList")
    public final List<MachineInfo> getMachineInfoList(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username,
                                                      @Named("from") String from, @Named("to") String to) throws SQLException, ClassNotFoundException, ParseException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        Date date = format.parse(to);
        long toTime = date.getTime();

        date = format.parse(from);
        long fromTime = date.getTime();

        Connection conn = DriverManager.getConnection(url);

        PreparedStatement stmtMacAddress = conn.prepareStatement("SELECT MAC_ADDRESS FROM Feature_Dictionary GROUP BY MAC_ADDRESS");
        ResultSet rsMacAddress =  stmtMacAddress.executeQuery();

        ArrayList<String> listMacAddress = new ArrayList<String>();

        while (rsMacAddress.next()) {
            listMacAddress.add(rsMacAddress.getString(1));
        }

//        String query = "SELECT * FROM IU_device_data WHERE Timestamp_Pi >= ? and Timestamp_Pi <= ? ORDER BY Timestamp_Pi";
        String query = "SELECT * FROM IU_device_data ORDER BY Timestamp_Pi";

        PreparedStatement stmt = conn.prepareStatement(query);

//        stmt.setString(1, from);
//        stmt.setString(2, to);

        ResultSet rs =  stmt.executeQuery();
        List<MachineInfo> listData = new ArrayList<MachineInfo>();
        HashMap<String, MachineInfo> mapData = new HashMap<String, MachineInfo>();

        for (int i = 0; i < listMacAddress.size(); i++) {
            MachineInfo data = new MachineInfo();
            data.setMacAddress(listMacAddress.get(i));
            data.setStartTime(from);
            data.setEndTime(to);

            mapData.put(listMacAddress.get(i), data);
            listData.add(data);
        }

        while (rs.next()) {
            String time = rs.getString(3);
            String macAddress = rs.getString(4);
            int state = rs.getInt(5);
            float batterState = rs.getFloat(6);

            long milliseconds = Utils.convertDateToMilliseconds(time);

            if (milliseconds == -1L || milliseconds > toTime || milliseconds < fromTime)
                continue;

            MachineInfo data = mapData.get(macAddress);

            if (data == null) {
                continue;
            }

            data.setState(state);
            data.setBatteryState(Integer.valueOf((int)batterState));

            ProductivityInfo info;

            if (data.getProductivityInfo().size() == 0) {
                info = new ProductivityInfo();
                info.setState(state);
                info.setStartTime(milliseconds);
                info.setEndTime(milliseconds);

                info.setStartTimePi(time);
                info.setEndTimePi(time);

                data.getProductivityInfo().add(info);
            }
            else {
                info = data.getProductivityInfo().get(data.getProductivityInfo().size() - 1);
                info.setEndTime(milliseconds);
                info.setEndTimePi(time);

                if (info.getState() != state) {
                    info = new ProductivityInfo();
                    info.setState(state);
                    info.setStartTime(milliseconds);
                    info.setEndTime(milliseconds);

                    info.setStartTimePi(time);
                    info.setEndTimePi(time);

                    data.getProductivityInfo().add(info);
                }
            }
        }

        conn.close();

        for (int i = 0; i < listData.size(); i++) {
            MachineInfo data = listData.get(i);

            for (int j = 0; j < data.getProductivityInfo().size(); j++) {
                ProductivityInfo info = data.getProductivityInfo().get(j);

                if (info.getState() == 0)
                    data.setDurationIdle(data.getDurationIdle() + info.getDuration());
                else if (info.getState() == 1)
                    data.setDurationNormal(data.getDurationNormal() + info.getDuration());
                else if (info.getState() == 2)
                    data.setDurationWarning(data.getDurationWarning() + info.getDuration());
                else if (info.getState() == 3)
                    data.setDurationDanger(data.getDurationDanger() + info.getDuration());
            }

            long totalTime = data.getDurationIdle() + data.getDurationNormal() + data.getDurationWarning() + data.getDurationDanger();

            if (totalTime != 0L) {
                data.setStateIdle(((float)data.getDurationIdle() * 100 / totalTime));
                data.setStateNormal(((float) data.getDurationNormal() * 100 / totalTime));
                data.setStateWarning(((float) data.getDurationWarning() * 100 / totalTime));
                data.setStateDanger(((float)data.getDurationDanger() * 100 / totalTime));
            }
        }

        return listData;
    }

    @ApiMethod(name = "getTotalMachineInfo")
    public final MachineInfo getTotalMachineInfo(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username,
                                                 @Named("from") String from, @Named("to") String to) throws SQLException, ClassNotFoundException, ParseException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        Date date = format.parse(to);
        long toTime = date.getTime();

        date = format.parse(from);
        long fromTime = date.getTime();

        Connection conn = DriverManager.getConnection(url);

//        String query = "SELECT * FROM IU_device_data WHERE Timestamp_Pi >= ? and Timestamp_Pi <= ? ORDER BY Timestamp_Pi";
        String query = "SELECT * FROM IU_device_data ORDER BY Timestamp_Pi";

        PreparedStatement stmt = conn.prepareStatement(query);

//        stmt.setString(1, from);
//        stmt.setString(2, to);

        ResultSet rs =  stmt.executeQuery();

        MachineInfo data = new MachineInfo();
        data.setStartTime(from);
        data.setEndTime(to);

        while (rs.next()) {
            String time = rs.getString(3);
            String macAddress = rs.getString(4);
            int state = rs.getInt(5);
            float batterState = rs.getFloat(6);

            long milliseconds = Utils.convertDateToMilliseconds(time);

            if (milliseconds == -1L || milliseconds > toTime || milliseconds < fromTime)
                continue;

            ProductivityInfo info;

            if (data.getProductivityInfo().size() == 0) {
                info = new ProductivityInfo();
                info.setState(state);
                info.setStartTime(milliseconds);
                info.setEndTime(milliseconds);

                info.setStartTimePi(time);
                info.setEndTimePi(time);

                data.getProductivityInfo().add(info);
            }
            else {
                info = data.getProductivityInfo().get(data.getProductivityInfo().size() - 1);
                info.setEndTime(milliseconds);
                info.setEndTimePi(time);

                if (info.getState() != state) {
                    info = new ProductivityInfo();
                    info.setState(state);
                    info.setStartTime(milliseconds);
                    info.setEndTime(milliseconds);

                    info.setStartTimePi(time);
                    info.setEndTimePi(time);

                    data.getProductivityInfo().add(info);
                }
            }
        }

        conn.close();

        for (int j = 0; j < data.getProductivityInfo().size(); j++) {
            ProductivityInfo info = data.getProductivityInfo().get(j);

            if (info.getState() == 0)
                data.setDurationIdle(data.getDurationIdle() + info.getDuration());
            else if (info.getState() == 1)
                data.setDurationNormal(data.getDurationNormal() + info.getDuration());
            else if (info.getState() == 2)
                data.setDurationWarning(data.getDurationWarning() + info.getDuration());
            else if (info.getState() == 3)
                data.setDurationDanger(data.getDurationDanger() + info.getDuration());
        }

        long totalTime = data.getDurationIdle() + data.getDurationNormal() + data.getDurationWarning() + data.getDurationDanger();

        if (totalTime != 0L) {
            data.setStateIdle(((float)data.getDurationIdle() * 100 / totalTime));
            data.setStateNormal(((float) data.getDurationNormal() * 100 / totalTime));
            data.setStateWarning(((float) data.getDurationWarning() * 100 / totalTime));
            data.setStateDanger(((float)data.getDurationDanger() * 100 / totalTime));
        }

        return data;
    }

    @ApiMethod(name = "getCurrentMachineInfo")
    public final MachineInfo getCurrentMachineInfo(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username,
                                                   @Named("from") String from, @Named("to") String to, @Named("macAddress") String macAddress) throws SQLException, ClassNotFoundException, ParseException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        Date date = format.parse(to);
        long toTime = date.getTime();

        date = format.parse(from);
        long fromTime = date.getTime();

        Connection conn = DriverManager.getConnection(url);

//        String query = "SELECT * FROM IU_device_data WHERE Timestamp_Pi >= ? and Timestamp_Pi <= ? ORDER BY Timestamp_Pi";
        String query = "SELECT * FROM IU_device_data WHERE MAC_ADDRESS = ? ORDER BY Timestamp_Pi";

        PreparedStatement stmt = conn.prepareStatement(query);

        stmt.setString(1, macAddress);
//        stmt.setString(2, to);

        ResultSet rs =  stmt.executeQuery();

        MachineInfo data = new MachineInfo();
        data.setStartTime(from);
        data.setEndTime(to);

        while (rs.next()) {
            String time = rs.getString(3);
            int state = rs.getInt(5);
            float batterState = rs.getFloat(6);

            long milliseconds = Utils.convertDateToMilliseconds(time);

            if (milliseconds == -1L || milliseconds > toTime || milliseconds < fromTime)
                continue;

            ProductivityInfo info;

            if (data.getProductivityInfo().size() == 0) {
                info = new ProductivityInfo();
                info.setState(state);
                info.setStartTime(milliseconds);
                info.setEndTime(milliseconds);

                info.setStartTimePi(time);
                info.setEndTimePi(time);

                data.getProductivityInfo().add(info);
            }
            else {
                info = data.getProductivityInfo().get(data.getProductivityInfo().size() - 1);
                info.setEndTime(milliseconds);
                info.setEndTimePi(time);

                if (info.getState() != state) {
                    info = new ProductivityInfo();
                    info.setState(state);
                    info.setStartTime(milliseconds);
                    info.setEndTime(milliseconds);

                    info.setStartTimePi(time);
                    info.setEndTimePi(time);

                    data.getProductivityInfo().add(info);
                }
            }
        }

        conn.close();

        for (int j = 0; j < data.getProductivityInfo().size(); j++) {
            ProductivityInfo info = data.getProductivityInfo().get(j);

            if (info.getState() == 0)
                data.setDurationIdle(data.getDurationIdle() + info.getDuration());
            else if (info.getState() == 1)
                data.setDurationNormal(data.getDurationNormal() + info.getDuration());
            else if (info.getState() == 2)
                data.setDurationWarning(data.getDurationWarning() + info.getDuration());
            else if (info.getState() == 3)
                data.setDurationDanger(data.getDurationDanger() + info.getDuration());
        }

        long totalTime = data.getDurationIdle() + data.getDurationNormal() + data.getDurationWarning() + data.getDurationDanger();

        if (totalTime != 0L) {
            data.setStateIdle(((float)data.getDurationIdle() * 100 / totalTime));
            data.setStateNormal(((float)data.getDurationNormal() * 100 / totalTime));
            data.setStateWarning(((float)data.getDurationWarning() * 100 / totalTime));
            data.setStateDanger(((float)data.getDurationDanger() * 100 / totalTime));
        }

        return data;
    }

    @ApiMethod(name = "getRedAlertInfoList")
    public final List<RedAlertInfo> getRedAlertInfoList(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username,
                                                        @Named("from") String from, @Named("to") String to) throws SQLException, ClassNotFoundException, ParseException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        Date date = format.parse(to);
        long toTime = date.getTime();

        date = format.parse(from);
        long fromTime = date.getTime();

        Connection conn = DriverManager.getConnection(url);

        PreparedStatement stmtMacAddress = conn.prepareStatement("SELECT MAC_ADDRESS FROM Feature_Dictionary GROUP BY MAC_ADDRESS");
        ResultSet rsMacAddress =  stmtMacAddress.executeQuery();

        ArrayList<String> listMacAddress = new ArrayList<String>();

        while (rsMacAddress.next()) {
            listMacAddress.add(rsMacAddress.getString(1));
        }

//        String query = "SELECT * FROM IU_device_data WHERE Timestamp_Pi >= ? and Timestamp_Pi <= ? ORDER BY Timestamp_Pi";
        String query = "SELECT * FROM IU_device_data ORDER BY Timestamp_Pi";

        PreparedStatement stmt = conn.prepareStatement(query);

//        stmt.setString(1, from);
//        stmt.setString(2, to);

        ResultSet rs =  stmt.executeQuery();
        List<RedAlertInfo> listData = new ArrayList<RedAlertInfo>();
        HashMap<String, RedAlertInfo> mapData = new HashMap<String, RedAlertInfo>();

        for (int i = 0; i < listMacAddress.size(); i++) {
            RedAlertInfo data = new RedAlertInfo();
            data.setMacAddress(listMacAddress.get(i));
            data.setStartTime(from);
            data.setEndTime(to);

            mapData.put(listMacAddress.get(i), data);
            listData.add(data);
        }

        int totalCount = 0;

        while (rs.next()) {
            String time = rs.getString(3);
            String macAddress = rs.getString(4);
            int state = rs.getInt(5);
            float batterState = rs.getFloat(6);

            if (state == 3)
                totalCount++;

            long milliseconds = Utils.convertDateToMilliseconds(time);

            if (milliseconds == -1L || milliseconds > toTime || milliseconds < fromTime)
                continue;

            RedAlertInfo data = mapData.get(macAddress);

            if (data == null) {
                continue;
            }

            ProductivityInfo info;

            if (data.getProductivityInfo().size() == 0) {
                info = new ProductivityInfo();
                info.setState(state);
                info.setStartTime(milliseconds);
                info.setEndTime(milliseconds);

                info.setStartTimePi(time);
                info.setEndTimePi(time);

                data.getProductivityInfo().add(info);
            }
            else {
                info = data.getProductivityInfo().get(data.getProductivityInfo().size() - 1);

                int index = Utils.getDayIndex(toTime, milliseconds);
                int lastIndex = Utils.getDayIndex(toTime, info.getEndTime());

                info.setEndTime(milliseconds);
                info.setEndTimePi(time);

                if (info.getState() != state || lastIndex != index) {
                    info = new ProductivityInfo();
                    info.setState(state);
                    info.setStartTime(milliseconds);
                    info.setEndTime(milliseconds);

                    info.setStartTimePi(time);
                    info.setEndTimePi(time);

                    data.getProductivityInfo().add(info);
                }
            }
        }

        conn.close();

        for (int i = 0; i < listData.size(); i++) {
            RedAlertInfo data = listData.get(i);

            data.setTotalCount(totalCount);

            for (int j = 0; j < data.getProductivityInfo().size(); j++) {
                ProductivityInfo info = data.getProductivityInfo().get(j);
                if (info.getState() == 3) {
                    int index = Utils.getDayIndex(toTime, info.getStartTime());
                    data.setTrends(index, data.getTrends(index) + info.getDuration());
                }
            }

            for (int k = 0; k < 7; k++) {
                data.setSpan(data.getSpan() + data.getTrends(k));
            }

            if (data.getSpan() != 0L) {
                for (int k = 0; k < 7; k++) {
                    int percent = (int) (data.getTrends(k) * 100 / data.getSpan());

                    if (percent == 0)
                        percent = 1;

                    data.setTrendsPercent(k, percent);
                }

                //data.setTrendsPercent(6, 100 - data.getTrendsPercent(0) - data.getTrendsPercent(1) - data.getTrendsPercent(2) - data.getTrendsPercent(3) - data.getTrendsPercent(4) - data.getTrendsPercent(5));
            }
        }

        return listData;
    }

    @ApiMethod(name = "getDeviceStatus")
    public final DeviceStatus getDeviceStatus(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username, @Named("address") String address) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);

        String query = "SELECT MAC_ADDRESS, Status FROM Feature_Dictionary";

        query += " WHERE MAC_ADDRESS = ?";
        query += " GROUP BY MAC_ADDRESS";

        PreparedStatement stmt = conn.prepareStatement(query);

        stmt.setString(1, address);

        ResultSet rs =  stmt.executeQuery();

        DeviceStatus value = new DeviceStatus();

        while (rs.next()) {
            value.setMacAddress(rs.getString(1));
            value.setStatus(rs.getInt(2));
        }

        query = "SELECT MAC_ADDRESS, Battery_Level FROM IU_device_data WHERE MAC_ADDRESS = ? ORDER BY Id DESC LIMIT 1";
        stmt = conn.prepareStatement(query);
        stmt.setString(1, address);

        rs =  stmt.executeQuery();

        if (rs.next()) {
            value.setBatteryLevel(rs.getFloat(2));
        }

        conn.close();

        return value;
    }

    @ApiMethod(name = "getRedAlertInfoListByMacAddress")
    public final RedAlertInfo getRedAlertInfoListByMacAddress(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username,
                                                              @Named("from") String from, @Named("to") String to, @Named("macAddress") String macAddress) throws SQLException, ClassNotFoundException, ParseException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        Date date = format.parse(to);
        long toTime = date.getTime();

        date = format.parse(from);
        long fromTime = date.getTime();

        Connection conn = DriverManager.getConnection(url);

//        String query = "SELECT * FROM IU_device_data WHERE Timestamp_Pi >= ? and Timestamp_Pi <= ? ORDER BY Timestamp_Pi";
        String query = "SELECT * FROM IU_device_data WHERE MAC_ADDRESS = ? ORDER BY Timestamp_Pi";

        PreparedStatement stmt = conn.prepareStatement(query);

        stmt.setString(1, macAddress);
//        stmt.setString(2, to);

        ResultSet rs =  stmt.executeQuery();

        RedAlertInfo data = new RedAlertInfo(12);
        data.setMacAddress(macAddress);
        data.setStartTime(from);
        data.setEndTime(to);

        int totalCount = 0;

        while (rs.next()) {
            String time = rs.getString(3);
            int state = rs.getInt(5);
            float batterState = rs.getFloat(6);

            long milliseconds = Utils.convertDateToMilliseconds(time);

            if (milliseconds == -1L || milliseconds > toTime || milliseconds < fromTime)
                continue;

            if (data == null) {
                continue;
            }

            if (state == 3)
                totalCount++;

            ProductivityInfo info;

            if (data.getProductivityInfo().size() == 0) {
                info = new ProductivityInfo();
                info.setState(state);
                info.setStartTime(milliseconds);
                info.setEndTime(milliseconds);

                info.setStartTimePi(time);
                info.setEndTimePi(time);

                data.getProductivityInfo().add(info);
            }
            else {
                info = data.getProductivityInfo().get(data.getProductivityInfo().size() - 1);

                int index = Utils.getTimeIndex(toTime, milliseconds);
                int lastIndex = Utils.getTimeIndex(toTime, info.getEndTime());

                info.setEndTime(milliseconds);
                info.setEndTimePi(time);

                if (info.getState() != state || lastIndex != index) {
                    info = new ProductivityInfo();
                    info.setState(state);
                    info.setStartTime(milliseconds);
                    info.setEndTime(milliseconds);

                    info.setStartTimePi(time);
                    info.setEndTimePi(time);

                    data.getProductivityInfo().add(info);
                }
            }
        }

        conn.close();

        data.setTotalCount(totalCount);

        for (int j = 0; j < data.getProductivityInfo().size(); j++) {
            ProductivityInfo info = data.getProductivityInfo().get(j);
            if (info.getState() == 3) {
                int index = Utils.getTimeIndex(toTime, info.getStartTime());
                data.setTrends(index, data.getTrends(index) + info.getDuration());
            }
        }

        for (int k = 0; k < 12; k++) {
            data.setSpan(data.getSpan() + data.getTrends(k));
        }

        if (data.getSpan() != 0L) {
            for (int k = 0; k < 12; k++) {
                int percent = (int) (data.getTrends(k) * 100 / data.getSpan());

                if (percent == 0)
                    percent = 1;

                data.setTrendsPercent(k, percent);
            }
        }

        return data;
    }

    @ApiMethod(name = "getDailyPerformanceList")
    public final DailyPerformanceData[] getDailyPerformanceList(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username,
                                                                @Named("macAddress") String macAddress) throws SQLException, ClassNotFoundException, ParseException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");

        Date date = new Date();
        long toTime = System.currentTimeMillis();
        String to = format.format(date);

        long fromTime = toTime - 24L * 60L * 60L * 1000L * 25L;
        date.setTime(fromTime);
        String from = format.format(date);

        Connection conn = DriverManager.getConnection(url);

        String query = "SELECT * FROM IU_device_data WHERE MAC_ADDRESS = ? and Timestamp_Pi >= ? and Timestamp_Pi <= ? ORDER BY Timestamp_Pi";
//        String query = "SELECT * FROM IU_device_data WHERE MAC_ADDRESS = ? ORDER BY Timestamp_Pi";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setString(1, macAddress);
        stmt.setString(2, from);
        stmt.setString(3, to);

        ResultSet rs =  stmt.executeQuery();

        SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");

        DailyPerformanceData[] dataList = new DailyPerformanceData[25];

        for (int i = 0; i < dataList.length; i++) {
            dataList[i] = new DailyPerformanceData();
            dataList[i].setStartTime(format1.format(date));
        }

        int maxRedCount = 0;

        while (rs.next()) {
            String time = rs.getString(3);
            int state = rs.getInt(5);

            long milliseconds = Utils.convertDateToMilliseconds(time);

            if (milliseconds == -1L || milliseconds > toTime || milliseconds < fromTime)
                continue;
//            if (milliseconds == -1L || milliseconds < fromTime)
//                continue;
//            if (milliseconds == -1L)
//                continue;

            int index = Utils.getDayIndexByDaily(toTime, milliseconds);
            DailyPerformanceData data = dataList[index];

            ProductivityInfo info;

            if (state == 3) {
                data.setRedCount(data.getRedCount() + 1);

                if (maxRedCount < data.getRedCount())
                    maxRedCount = data.getRedCount();
            }

            if (data.getProductivityInfo().size() == 0) {
                info = new ProductivityInfo();
                info.setState(state);
                info.setStartTime(milliseconds);
                info.setEndTime(milliseconds);

                info.setStartTimePi(time);
                info.setEndTimePi(time);

                data.getProductivityInfo().add(info);
            }
            else {
                info = data.getProductivityInfo().get(data.getProductivityInfo().size() - 1);
                info.setEndTime(milliseconds);
                info.setEndTimePi(time);

                if (info.getState() != state) {
                    info = new ProductivityInfo();
                    info.setState(state);
                    info.setStartTime(milliseconds);
                    info.setEndTime(milliseconds);

                    info.setStartTimePi(time);
                    info.setEndTimePi(time);

                    data.getProductivityInfo().add(info);
                }
            }
        }

        conn.close();

        for (int i = 0; i < dataList.length; i++) {
            DailyPerformanceData data = dataList[i];

            data.setMaxRedCount(maxRedCount);

            for (int j = 0; j < data.getProductivityInfo().size(); j++) {
                ProductivityInfo info = data.getProductivityInfo().get(j);

                if (info.getState() == 0)
                    data.setDurationIdle(data.getDurationIdle() + info.getDuration());
                else if (info.getState() == 1)
                    data.setDurationNormal(data.getDurationNormal() + info.getDuration());
                else if (info.getState() == 2)
                    data.setDurationWarning(data.getDurationWarning() + info.getDuration());
                else if (info.getState() == 3)
                    data.setDurationDanger(data.getDurationDanger() + info.getDuration());
            }

            long totalTime = data.getDurationIdle() + data.getDurationNormal() + data.getDurationWarning() + data.getDurationDanger();

            if (totalTime != 0L) {
                int percent = 100;

                if (maxRedCount > percent)
                    percent = maxRedCount;

                data.setStateIdle((float)data.getDurationIdle() * percent / totalTime);
                data.setStateNormal((float)data.getDurationNormal() * percent / totalTime);
                data.setStateWarning((float)data.getDurationWarning() * percent / totalTime);
                data.setStateDanger((float)data.getDurationDanger() * percent / totalTime);
            }
        }

        return dataList;
    }

    @ApiMethod(name = "getMonitoringDataListByRealTime")
    public final List<MonitoringData> getMonitoringDataListByRealTime(@Named("server") String server, @Named("dbname") String dbname, @Named("username") String username, @Named("address") String address, @Named("featureId") Integer featureId) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = String.format(database_url_format, server, Utils.decodeDBName(dbname), username);
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");

//        Date date = new Date();
//        long toTime = System.currentTimeMillis();
//        String to = format.format(date);
//
//        long fromTime = toTime - 24L * 60L * 60L * 1000L * 25L;
//        date.setTime(fromTime);
//        String from = format.format(date);

        Connection conn = DriverManager.getConnection(url);

        String query = "SELECT * FROM Feature_Dictionary WHERE MAC_ADDRESS = ? and Feature_ID = ?";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setString(1, address);
        stmt.setInt(2, featureId);

        ResultSet rs =  stmt.executeQuery();

        List<MonitoringData> listData = new ArrayList<MonitoringData>();
        HashMap<String, MonitoringData> mapData = new HashMap<String, MonitoringData>();

        while (rs.next()) {
            MonitoringData data = new MonitoringData();

            data.getFeatureDictionary().setMacAddress(rs.getString(1));
            data.getFeatureDictionary().setFeatureID(rs.getInt(2));
            data.getFeatureDictionary().setFeatureName(rs.getString(3));
            data.getFeatureDictionary().setThreshold1(rs.getInt(4));
            data.getFeatureDictionary().setThreshold2(rs.getInt(5));
            data.getFeatureDictionary().setThreshold3(rs.getInt(6));
            data.getFeatureDictionary().setStatus(rs.getInt(7));

            listData.add(data);
            mapData.put(data.getFeatureDictionary().getMacAddress() + "_" + data.getFeatureDictionary().getFeatureID(), data);
        }

        query = "SELECT * FROM IU_device_data WHERE MAC_ADDRESS = ? ORDER BY Timestamp_Pi DESC LIMIT 25";

        stmt = conn.prepareStatement(query);
        stmt.setString(1, address);

        rs =  stmt.executeQuery();

        while (rs.next()) {
            String time = rs.getString(3);
            String macAddress = rs.getString(4);
            int state = rs.getInt(5);
            long milliseconds = Utils.convertDateToMilliseconds(time);

            if (milliseconds == -1L)
                continue;

            for (int i = 0; i < 6; i++) {
                MonitoringData data = mapData.get(macAddress + "_" + i);

                if (data == null)
                    continue;

                FeatureInfo info;
                Float featureValue = rs.getFloat(7 + i);

                if (data.getFeatureInfo().size() == 0) {
                    info = new FeatureInfo();
                    info.setState(state);
                    info.setFeatureValue(featureValue);
                    info.setStartTime(milliseconds);
                    info.setEndTime(milliseconds);

                    info.setStartTimePi(time);
                    info.setEndTimePi(time);

                    data.setMaxValue(info.getFeatureValue());
                    data.setMinValue(info.getFeatureValue());

                    data.getFeatureInfo().add(0, info);
                }
                else {
                    //info = data.getFeatureInfo().get(data.getFeatureInfo().size() - 1);
                    info = data.getFeatureInfo().get(0);
                    info.setEndTime(milliseconds);
                    info.setEndTimePi(time);

                    if (info.getState() != state || info.getFeatureValue() != featureValue) {
                        info = new FeatureInfo();
                        info.setState(state);
                        info.setFeatureValue(featureValue);
                        info.setStartTime(milliseconds);
                        info.setEndTime(milliseconds);

                        info.setStartTimePi(time);
                        info.setEndTimePi(time);

                        if (data.getMaxValue() < info.getFeatureValue())
                            data.setMaxValue(info.getFeatureValue());

                        if (data.getMinValue() > info.getFeatureValue())
                            data.setMinValue(info.getFeatureValue());

                        data.getFeatureInfo().add(0, info);
                    }
                }
            }
        }

        conn.close();

        for (int i = 0; i < listData.size(); i++) {
            MonitoringData data = listData.get(i);

            long curTime = 0L;
            for (int j = 0; j < data.getFeatureInfo().size(); j++) {
                FeatureInfo info = data.getFeatureInfo().get(j);
                long duration = info.getDuration();
                curTime = curTime + duration;
                info.setTimeLabel(Utils.convertTimeToString(-curTime));
            }

            if (data.getMaxValue() < data.getFeatureDictionary().getThreshold1())
                data.setMaxValue(data.getFeatureDictionary().getThreshold1().floatValue());
            if (data.getMinValue() > data.getFeatureDictionary().getThreshold1())
                data.setMinValue(data.getFeatureDictionary().getThreshold1().floatValue());
            if (data.getMaxValue() < data.getFeatureDictionary().getThreshold2())
                data.setMaxValue(data.getFeatureDictionary().getThreshold2().floatValue());
            if (data.getMinValue() > data.getFeatureDictionary().getThreshold2())
                data.setMinValue(data.getFeatureDictionary().getThreshold2().floatValue());
            if (data.getMaxValue() < data.getFeatureDictionary().getThreshold3())
                data.setMaxValue(data.getFeatureDictionary().getThreshold3().floatValue());
            if (data.getMinValue() > data.getFeatureDictionary().getThreshold3())
                data.setMinValue(data.getFeatureDictionary().getThreshold3().floatValue());

            data.setMaxValue(data.getMaxValue() + 50f);
            data.setMinValue(data.getMinValue() - 50f);
            if (data.getMinValue() > 0f)
                data.setMinValue(0f);
        }

        return listData;
    }

    @ApiMethod(name = "setMaterialData")
    public final void setMaterialData(@Named("Material") String Material, @Named("Tool_Diameter") String Tool_Diameter, @Named("Flutes") String Flutes,
                                       @Named("Tool_Type") String Tool_Type, @Named("RPM") String RPM, @Named("Feed_Rate") String Feed_Rate,
                                       @Named("Other") String Other) throws SQLException, ClassNotFoundException {
        String url = null;

        if (SystemProperty.environment.value() ==
                SystemProperty.Environment.Value.Production) {
            // Connecting from App Engine.
            // Load the class that provides the "jdbc:google:mysql://"
            // prefix.
            Class.forName("com.mysql.jdbc.GoogleDriver");

            url = String.format(database_url_format, "server0", "MLS", "root");
        } else {
            // You may also assign an IP Address from the access control
            // page and use it to connect from an external network.
        }

        Connection conn = DriverManager.getConnection(url);
        PreparedStatement stmt = conn.prepareStatement("Insert Into Tagged_Data (Timestamp_Pi, Material, Tool_Diameter, Flutes, Tool_Type, RPM, Feed_Rate, Other) VALUES (?, ?, ?, ?, ?, ?, ?, ?);");

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.S");
        String time = format.format(new java.util.Date());

        stmt.setString(1, time);
        stmt.setString(2, Material);
        stmt.setString(3, Tool_Diameter);
        stmt.setString(4, Flutes);
        stmt.setString(5, Tool_Type);
        stmt.setString(6, RPM);
        stmt.setString(7, Feed_Rate);
        stmt.setString(8, Other);

        stmt.executeUpdate();
        conn.close();
    }
}
