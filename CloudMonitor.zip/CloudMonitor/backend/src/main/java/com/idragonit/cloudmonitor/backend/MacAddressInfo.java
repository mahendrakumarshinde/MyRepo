package com.idragonit.cloudmonitor.backend;

/**
 * Created by idragon on 2/26/16.
 */
public class MacAddressInfo {
    private String MAC_ADDRESS;
    private Integer Status;

    public String getMacAddress() {
        return MAC_ADDRESS;
    }

    public void setMacAddress(String macAddress) {
        MAC_ADDRESS = macAddress;
    }

    public Integer getStatus() {
        return Status;
    }

    public void setStatus(Integer status) {
        Status = status;
    }

}
