package com.idragonit.cloudmonitor.backend;

/**
 * Created by idragon on 2/26/16.
 */
public class FeatureDictionary {
    private String MAC_ADDRESS;
    private Integer Feature_ID;
    private String Feature_Name;
    private Integer Threshold_1;
    private Integer Threshold_2;
    private Integer Threshold_3;
    private Integer Status;

    public String getMacAddress() {
        return MAC_ADDRESS;
    }

    public void setMacAddress(String macAddress) {
        MAC_ADDRESS = macAddress;
    }

    public Integer getFeatureID() {
        return Feature_ID;
    }

    public void setFeatureID(Integer featureID) {
        Feature_ID = featureID;
    }

    public String getFeatureName() {
        return Feature_Name;
    }

    public void setFeatureName(String featureName) {
        Feature_Name = featureName;
    }

    public Integer getThreshold1() {
        return Threshold_1;
    }

    public void setThreshold1(Integer threshold) {
        Threshold_1 = threshold;
    }

    public Integer getThreshold2() {
        return Threshold_2;
    }

    public void setThreshold2(Integer threshold) {
        Threshold_2 = threshold;
    }

    public Integer getThreshold3() {
        return Threshold_3;
    }

    public void setThreshold3(Integer threshold) {
        Threshold_3 = threshold;
    }

    public Integer getStatus() {
        return Status;
    }

    public void setStatus(Integer status) {
        Status = status;
    }

}
