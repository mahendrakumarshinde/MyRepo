package com.idragonit.cloudexplorer.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;

import com.idragonit.cloudexplorer.IReceiveData;
import com.idragonit.cloudexplorer.R;
import com.idragonit.cloudexplorer.ReadDataActivity;
import com.idragonit.cloudexplorer.view.ThresholdView;

public class ThresholdFragment extends Fragment implements IReceiveData {

    View mView;
    Spinner mSpinner;
    ThresholdView thresholdView;
    int mCurFeature = 0;

    int ids[] = new int[] {R.string.feature_name1, R.string.feature_name2, R.string.feature_name3, R.string.feature_name4, R.string.feature_name5, R.string.feature_name6};

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mView = inflater.inflate(R.layout.fragment_threshold, container, false);

        LinearLayout layoutThreshold = (LinearLayout) mView.findViewById(R.id.layout_threshold);
        final ScrollView scrollView = (ScrollView) mView.findViewById(R.id.layout_main);

        View view = getActivity().getLayoutInflater().inflate(R.layout.layout_feature_threshold, null);
        thresholdView = ((ThresholdView) view.findViewById(R.id.threshold));
        thresholdView.mThresholdIndex = mCurFeature;

        for (int j = 0; j < 3; j++)
            thresholdView.defaultThreshold[j] = ((ReadDataActivity)getActivity()).mFeatureThresholds[mCurFeature][j];

        thresholdView.setThresholds();
        layoutThreshold.addView(view);

        thresholdView.setListener(new ThresholdView.OnTouchListener() {
            @Override
            public void onTouch() {
                scrollView.requestDisallowInterceptTouchEvent(true);
            }
        });

        String[] featureValues = new String[6];

        featureValues[0] = "Signal Energy";
        featureValues[1] = "Mean Crossing Rate";
        featureValues[2] = "Spectral Centroid";
        featureValues[3] = "Spectral Flatness";
        featureValues[4] = "Accel Spectral Spread";
        featureValues[5] = "Audio Spectral Spread";

        mSpinner = (Spinner) mView.findViewById(R.id.spinner);
        ArrayAdapter adapter = new ArrayAdapter(getActivity(), R.layout.layout_spinner_item, featureValues);
        mSpinner.setAdapter(adapter);
        mSpinner.setPrompt("Signal Energy");
        mSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                mCurFeature = position;
                refreshData();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        return mView;
    }

    @Override
    public void readData(int status, long readTime) {
    }

    public void refreshData() {

        for (int j = 0; j < 3; j++)
            thresholdView.defaultThreshold[j] = ((ReadDataActivity)getActivity()).mFeatureThresholds[mCurFeature][j];

        thresholdView.setThresholds();
        thresholdView.invalidate();
    }
}