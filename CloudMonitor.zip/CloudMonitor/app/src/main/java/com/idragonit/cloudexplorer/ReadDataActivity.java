package com.idragonit.cloudexplorer;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.api.client.extensions.android.http.AndroidHttp;
import com.google.api.client.extensions.android.json.AndroidJsonFactory;
import com.idragonit.cloudexplorer.dao.BLEFeature;
import com.idragonit.cloudexplorer.dao.BLEStatus;
import com.idragonit.cloudexplorer.dao.DaoUtils;
import com.idragonit.cloudexplorer.fragment.HistoryFragment;
import com.idragonit.cloudexplorer.fragment.MonitoringFragment;
import com.idragonit.cloudexplorer.fragment.ThresholdFragment;
import com.idragonit.cloudexplorer.fragment.UtilizationFragment;
import com.idragonit.cloudmonitor.backend.myApi.MyApi;
import com.idragonit.cloudmonitor.backend.myApi.model.FeatureDictionary;
import com.idragonit.cloudmonitor.backend.myApi.model.FeatureDictionaryCollection;
import com.idragonit.cloudmonitor.backend.myApi.model.IUDeviceData;
import com.idragonit.cloudmonitor.backend.myApi.model.IUDeviceDataCollection;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

@TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
public class ReadDataActivity extends FragmentActivity implements IReceiveData {
    public static final boolean ISTEST = false;

    public static final String EXTRAS_DEVICE_ADDRESS = "DEVICE_ADDRESS";
    public static final String EXTRAS_DEVICE_NAME = "DEVICE_NAME";
    public static final long MONITOR_TIME = 1000L;
    public static final int REFRESH_MONITOR = 1;
    public static final int REFRESH_DEVICE_NAME = 2;
    public static final int REFRESH_DATA = 3;

    private static final String TAG = ReadDataActivity.class.getSimpleName();

    public static String mDeviceAddress;
    public static String mReceivedDeviceAddress = "";

    private Button mBtnSync;
    private View mLayoutChart;
    private TextView mTxtData;

    private View mLayoutBattery;
    private TextView mTxtBattery;
    private ImageView mImgBattery;

    private IReceiveData mMonitoringListener = null;
    private IReceiveData mUtilizationListener = null;
    private IReceiveFeatureData mHistoryListener = null;

    public ArrayList<BLEStatus> mStatusList = new ArrayList<BLEStatus>();
    public BLEStatus mLastStatus = null;
    public long[] mDurations = new long[4];

    public ArrayList<BLEFeature> mFeatureList = new ArrayList<BLEFeature>();
    public HashMap<String, BLEFeature> mLastFeature = new HashMap<String, BLEFeature>();
    public HashMap<String, ArrayList<BLEFeature>> mFeatureMap = new HashMap<String, ArrayList<BLEFeature>>();

    public Thread mMonitorThread = null;
    public boolean isRunning = false;

    public static boolean mConnected = true;
    public Thread mGetDataThread = null;

    public String mReceiveDataTmp = "";

    int testValue = 0;

    int[] batteryImgs = new int[] {R.drawable.ic_battery0, R.drawable.ic_battery1, R.drawable.ic_battery2, R.drawable.ic_battery3, R.drawable.ic_battery4};
    int mFeatureNameIds[] = new int[] {R.string.feature_name1, R.string.feature_name2, R.string.feature_name3, R.string.feature_name4, R.string.feature_name5, R.string.feature_name6};
    public int[][] mFeatureThresholds = new int[][] {new int[]{100, 750, 1500}, new int[]{100, 750, 1500}, new int[]{100, 750, 1500},
                                                     new int[]{100, 750, 1500}, new int[]{100, 750, 1500}, new int[]{100, 750, 1500}};

    String mServerName = "server0";
    String mDbName;
    String mUserName = "root";

    ViewPager viewPager;
    ThresholdFragment thresholdFragment = null;

    Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            if (msg.what == REFRESH_MONITOR) {
                long curTime = System.currentTimeMillis();

                if (mLastStatus != null) {
                    mLastStatus.setEndTime(curTime);

                    if (mMonitoringListener != null)
                        mMonitoringListener.readData(mLastStatus.getStatus(), curTime);
                    if (mUtilizationListener != null)
                        mUtilizationListener.readData(mLastStatus.getStatus(), curTime);
                }

                if (mLastFeature.size() > 0) {
                    Iterator<BLEFeature> iterator = mLastFeature.values().iterator();
                    while (iterator.hasNext()) {
                        BLEFeature bleFeature = iterator.next();
                        if (bleFeature != null) {
                            bleFeature.setEndTime(curTime);

                            if (mHistoryListener != null)
                                mHistoryListener.readData(bleFeature.getStatus(), bleFeature.getFeatureId(), bleFeature.getFeatureValue(), curTime, false);
                        }
                    }
                }
            }
            else if (msg.what == REFRESH_DEVICE_NAME) {
                ((TextView) findViewById(R.id.device_name)).setText(mDeviceAddress);
            }
            else if (msg.what == REFRESH_DATA) {
                displayData((String) msg.obj);
            }
        }
    };

    public ReadDataActivity() {
        mConnected = false;
    }

    public long getStatusDuration(int status) {
        long duration = mDurations[status - 1];
        for (int i = 0; i < mStatusList.size(); i++) {
            BLEStatus bleData = mStatusList.get(i);

            if (bleData.getStatus() == status)
                duration += bleData.getEndTime() - bleData.getStartTime();
        }

        return duration;
    }

    public long getTotalDuration() {
        long duration = 0;
        for (int i = 0; i < 4; i++)
            duration += getStatusDuration(i + 1);

        return duration;
    }

    public int getStatusPercent(int status) {
        long totalDuration = getTotalDuration();
        long duration = getStatusDuration(status);

        if (totalDuration == 0)
            return 0;

        return (int) (duration * 100L / totalDuration);
    }

    private void startMonitorThread() {
        if (mMonitorThread != null)
            return;

        mMonitorThread = new Thread() {
            public void run() {
                while (isRunning) {
                    try {
                        sleep(MONITOR_TIME);
                    }
                    catch (Exception e) {

                    }

                    if (mLastStatus != null || mLastFeature != null) {
                        mHandler.sendEmptyMessage(REFRESH_MONITOR);
                    }
                }

                mMonitorThread = null;
            }
        };

        isRunning = true;
        mMonitorThread.start();
    }

    private void endMonitorThread() {
        if (mMonitorThread == null)
            return;

        isRunning = false;
    }

    private void startGetDataThread() {
        if (mGetDataThread != null)
            return;

        mGetDataThread = new Thread() {
            public void run() {
                while (mConnected) {
                    try {
                        sleep(10);
                    }
                    catch (Exception e) {

                    }

                    if(DeviceScanActivity.myApiService == null) {  // Only do this once
                        MyApi.Builder builder = new MyApi.Builder(AndroidHttp.newCompatibleTransport(), new AndroidJsonFactory(), null)
                                .setRootUrl("https://infinite-uptime-1232.appspot.com/_ah/api/");
                        DeviceScanActivity.myApiService = builder.build();
                    }

                    try {
                        IUDeviceDataCollection collection = DeviceScanActivity.myApiService.getDataListByDB(mServerName, mDbName, mUserName, AppData.getLatestId(ReadDataActivity.this, mDeviceAddress), mDeviceAddress).execute();
                        List<IUDeviceData> dataList = collection.getItems();

                        if (dataList != null && dataList.size() > 0) {

                            for (int i = 0; i < dataList.size(); i++) {
                                IUDeviceData data = dataList.get(i);
                                String iuData = data.getMacAddress() + "," + String.format("%02d", data.getState()) + "," + (data.getBatteryLevel().intValue()) + "," +
                                        "0000" + "," + data.getFeatureValue0() + "," +
                                        "0001" + "," + data.getFeatureValue1() + "," +
                                        "0002" + "," + data.getFeatureValue2() + "," +
                                        "0003" + "," + data.getFeatureValue3() + "," +
                                        "0004" + "," + data.getFeatureValue4() + "," +
                                        "0005" + "," + data.getFeatureValue5();

                                Message msg = new Message();
                                msg.what = REFRESH_DATA;
                                msg.obj = iuData;
                                mHandler.sendMessage(msg);
                            }

                            AppData.setLatestId(ReadDataActivity.this, mDeviceAddress, dataList.get(dataList.size() - 1).getId());
                        }
                    } catch (IOException e) {
                        e.getMessage();
                    }
                }

                mGetDataThread = null;
            }
        };

        mConnected = true;
        mGetDataThread.start();
    }

    private void stopGetDataThread() {
        if (mGetDataThread == null)
            return;

        mConnected = false;
    }

    private void disconnect() {
        long curTime = System.currentTimeMillis();

        if (mLastStatus != null) {
            mLastStatus.setEndTime(curTime);
            mLastStatus = null;
        }

        if (mLastFeature.size() > 0) {
            Iterator<BLEFeature> iterator = mLastFeature.values().iterator();
            while (iterator.hasNext()) {
                BLEFeature bleFeature = iterator.next();
                bleFeature.setEndTime(curTime);
            }

            mLastFeature.clear();
        }

        addStatusFeature();
    }

    private void displayData(String data) {
        Log.e("test", "displayData="+data);
        String[] command = data.split(",");
        mReceivedDeviceAddress = command[0];

        long curTime = System.currentTimeMillis();
        int status = STATUS_NONE;

        if (command[1].contains("00")) {
            status = STATUS_IDLE;
        }
        else if (command[1].contains("01")) {
            status = STATUS_NORMAL_CUTTING;
        }
        else if (command[1].contains("02")) {
            status = STATUS_WARNING;
        }
        else if (command[1].contains("03")) {
            status = STATUS_DANGER;
        }

        if (status != STATUS_NONE) {
            mLastStatus = new BLEStatus(mDeviceAddress, mDeviceAddress, status, curTime, curTime);
            mStatusList.add(mLastStatus);

            if (mMonitoringListener != null)
                mMonitoringListener.readData(status, curTime);
            if (mUtilizationListener != null)
                mUtilizationListener.readData(status, curTime);

            mTxtData.setText(data);
        }

        if (command.length > 2) {
            try {
                String level = command[2];
                int percent = Integer.valueOf(level);
                int index = (percent - 1) / 20;

                mTxtBattery.setText(percent + "%");
                mImgBattery.setImageResource(batteryImgs[index]);
            }
            catch (Exception e) {

            }
        }

        if (command.length > 3) {
            ArrayList<String> ids = new ArrayList<String>();

            for (int i = 3; i < command.length; i+=2) {
                String featureId = command[i];
                float featureValue = Float.valueOf(command[i + 1]);
                BLEFeature bleFeature;

                if (mFeatureMap.get(featureId) == null) {
                    AppData.setFeatureStartTime(this, featureId, System.currentTimeMillis());
                }

                bleFeature = mLastFeature.get(featureId);
                if (bleFeature != null && (bleFeature.getStatus() != status || bleFeature.getFeatureValue() != featureValue || !TextUtils.equals(bleFeature.getFeatureId(), featureId)))
                    bleFeature = null;

                if (bleFeature == null) {
                    bleFeature = new BLEFeature(mDeviceAddress, mDeviceAddress, mReceivedDeviceAddress, status, featureId, featureValue, curTime, curTime);
                    mFeatureList.add(bleFeature);

                    ArrayList<BLEFeature> featureList = mFeatureMap.get(featureId);
                    if (featureList == null) {
                        featureList = new ArrayList<BLEFeature>();
                        mFeatureMap.put(featureId, featureList);
                    }

                    featureList.add(bleFeature);

                    if (mHistoryListener != null)
                        mHistoryListener.readData(bleFeature.getStatus(), bleFeature.getFeatureId(), bleFeature.getFeatureValue(), curTime, true);
                }
                else {
                    if (mHistoryListener != null)
                        mHistoryListener.readData(bleFeature.getStatus(), bleFeature.getFeatureId(), bleFeature.getFeatureValue(), curTime, false);
                }

                ids.add(featureId);
                mLastFeature.put(featureId, bleFeature);
            }

            Object[] keys = mLastFeature.keySet().toArray();

            for (int i = 0; i < keys.length; i++) {
                boolean isExist = false;

                for (int j = 0; j < ids.size(); j++) {
                    if (TextUtils.equals((String)keys[i], ids.get(j))) {
                        isExist = true;
                        break;
                    }
                }

                if (!isExist)
                    mLastFeature.remove(keys[i]);
            }
        }
    }

    public void addStatusFeature() {
//        new Thread() {
//            public void run() {
//                for (int i = 0; i < mStatusList.size(); i++) {
//                    BLEStatus status = mStatusList.get(i);
//                    mDurations[status.getStatus() - 1] += status.getEndTime() - status.getStartTime();
//                }
//
//                DaoUtils.addBLEStatus(ReadDataActivity.this, mStatusList);
//                mStatusList.clear();
//                mLastStatus = null;
//
//                DaoUtils.addBLEFeature(ReadDataActivity.this, mFeatureList);
//                mFeatureList.clear();
//                mLastFeature.clear();
//
//            }
//        }.start();

        for (int i = 0; i < mStatusList.size(); i++) {
            BLEStatus status = mStatusList.get(i);
            mDurations[status.getStatus() - 1] += status.getEndTime() - status.getStartTime();
        }

        DaoUtils.addBLEStatus(ReadDataActivity.this, mStatusList);
        mStatusList.clear();
        mLastStatus = null;

        DaoUtils.addBLEFeature(ReadDataActivity.this, mFeatureList);
        mFeatureList.clear();
        mLastFeature.clear();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);

        setContentView(R.layout.activity_read_data);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        Intent intent = getIntent();

        mDeviceAddress = intent.getStringExtra(EXTRAS_DEVICE_ADDRESS);
        mDbName = intent.getStringExtra(DeviceScanActivity.DATABASE_NAME);

//        mDeviceName = "test";
//        mDeviceAddress = "test";

        mDurations = DaoUtils.getStatusDuration(this, mDeviceAddress, mDeviceAddress);
        mFeatureMap = DaoUtils.getFeatures(this, mDeviceAddress, mDeviceAddress);

        mLayoutBattery = findViewById(R.id.layout_battery);
        mTxtBattery = (TextView) findViewById(R.id.txt_battery);
        mImgBattery = (ImageView) findViewById(R.id.img_battery);

        ((TextView) findViewById(R.id.device_name)).setText(mDeviceAddress);

        mTxtData = (TextView) findViewById(R.id.data_value);

        mLayoutChart = findViewById(R.id.layout_chart);
        mLayoutChart.setVisibility(View.VISIBLE);
        mLayoutBattery.setVisibility(View.VISIBLE);

        mBtnSync = (Button) findViewById(R.id.btn_sync);
        mBtnSync.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                (new SetSyncAsyncTask()).execute(1);
            }
        });

        TabLayout tabLayout = (TabLayout) findViewById(R.id.tab_layout);
        tabLayout.addTab(tabLayout.newTab().setText("Monitoring"));
        tabLayout.addTab(tabLayout.newTab().setText("Utilization"));
        tabLayout.addTab(tabLayout.newTab().setText("Threshold"));
        tabLayout.addTab(tabLayout.newTab().setText("History"));
        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);

        viewPager = (ViewPager) findViewById(R.id.pager);
        final PagerAdapter adapter = new PagerAdapter(getSupportFragmentManager(), tabLayout.getTabCount());
        viewPager.setAdapter(adapter);
        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        changeTabsFont(tabLayout);

        (new GetThresholdAsyncTask()).execute();
    }

    private void changeTabsFont(TabLayout tabLayout) {

        ViewGroup vg = (ViewGroup) tabLayout.getChildAt(0);
        int tabsCount = vg.getChildCount();
        for (int j = 0; j < tabsCount; j++) {
            ViewGroup vgTab = (ViewGroup) vg.getChildAt(j);
            int tabChildsCount = vgTab.getChildCount();
            for (int i = 0; i < tabChildsCount; i++) {
                View tabViewChild = vgTab.getChildAt(i);
                if (tabViewChild instanceof TextView) {
                    ((TextView) tabViewChild).setTextSize(TypedValue.COMPLEX_UNIT_SP, 10);
                }
            }
        }
    }

    protected void onDestroy() {
        super.onDestroy();
    }

    protected void onPause() {
        super.onPause();

        stopGetDataThread();
        endMonitorThread();

        long curTime = System.currentTimeMillis();
        if (mLastStatus != null) {
            mLastStatus.setEndTime(curTime);
        }

        if (mLastFeature.size() > 0) {
            Iterator<BLEFeature> iterator = mLastFeature.values().iterator();
            while (iterator.hasNext()) {
                BLEFeature bleFeature = iterator.next();
                bleFeature.setEndTime(curTime);
            }

            mLastFeature.clear();
        }

        addStatusFeature();
    }

    protected void onResume() {
        super.onResume();

        startGetDataThread();
        startMonitorThread();
    }

    @Override
    public void readData(int status, long readTime) {

    }

    public void sendData(int index, int[] threshold) {
        String data = String.valueOf(threshold[1]);
        for (int i = 2; i < 4; i++) {
            data += "-" + String.format("%04d", threshold[i]);
        }

        threshold[0] = index;

        for (int i = 0; i < 3; i++)
            mFeatureThresholds[index][i] = threshold[i + 1];

        (new SendFeatureDataAsyncTask()).execute(threshold[0], threshold[1], threshold[2], threshold[3]);
        for (int i = 1; i < 4; i++) {
            AppData.setThresholdValue(this, i, threshold[i]);
        }
    }

    class GetThresholdAsyncTask extends AsyncTask<Context, Void, FeatureDictionaryCollection> {
        @Override
        protected FeatureDictionaryCollection doInBackground(Context... params) {
            if(DeviceScanActivity.myApiService == null) {  // Only do this once
                MyApi.Builder builder = new MyApi.Builder(AndroidHttp.newCompatibleTransport(), new AndroidJsonFactory(), null)
                        .setRootUrl("https://infinite-uptime-1232.appspot.com/_ah/api/");
                DeviceScanActivity.myApiService = builder.build();
            }

            try {
                FeatureDictionaryCollection collection = DeviceScanActivity.myApiService.getFeatureList(mServerName, mDbName, mUserName, mDeviceAddress, 0).execute();
                return collection;
            } catch (IOException e) {
                e.getMessage();
            }

            return null;
        }

        @Override
        protected void onPostExecute(FeatureDictionaryCollection result) {
            if (result != null) {
                List<FeatureDictionary> dataList = result.getItems();

                for (int i = 0; i < dataList.size(); i++) {
                    mFeatureThresholds[i][0] = dataList.get(i).getThreshold1();
                    mFeatureThresholds[i][1] = dataList.get(i).getThreshold2();
                    mFeatureThresholds[i][2] = dataList.get(i).getThreshold3();
                }

                if (viewPager.getCurrentItem() == 2 && thresholdFragment != null) {
                    thresholdFragment.refreshData();
                }
            }
        }
    }

    class SendFeatureDataAsyncTask extends AsyncTask<Integer, Void, String> {
        @Override
        protected String doInBackground(Integer... params) {
            if(DeviceScanActivity.myApiService == null) {  // Only do this once
                MyApi.Builder builder = new MyApi.Builder(AndroidHttp.newCompatibleTransport(), new AndroidJsonFactory(), null)
                        .setRootUrl("https://infinite-uptime-1232.appspot.com/_ah/api/");
                DeviceScanActivity.myApiService = builder.build();
            }

            try {
                DeviceScanActivity.myApiService.setThresholdData(mServerName, mDbName, mUserName, mDeviceAddress, params[0], 1, params[1]).execute();
                DeviceScanActivity.myApiService.setThresholdData(mServerName, mDbName, mUserName, mDeviceAddress, params[0], 2, params[2]).execute();
                DeviceScanActivity.myApiService.setThresholdData(mServerName, mDbName, mUserName, mDeviceAddress, params[0], 3, params[3]).execute();

                return "";
            } catch (IOException e) {
                e.getMessage();
            }

            return null;
        }

        @Override
        protected void onPostExecute(String result) {
        }
    }

    class SetSyncAsyncTask extends AsyncTask<Integer, Void, String> {
        @Override
        protected String doInBackground(Integer... params) {
            if(DeviceScanActivity.myApiService == null) {  // Only do this once
                MyApi.Builder builder = new MyApi.Builder(AndroidHttp.newCompatibleTransport(), new AndroidJsonFactory(), null)
                        .setRootUrl("https://infinite-uptime-1232.appspot.com/_ah/api/");
                DeviceScanActivity.myApiService = builder.build();
            }

            try {
                DeviceScanActivity.myApiService.setSyncByDB(mServerName, mDbName, mUserName, params[0]).execute();
                return "";
            } catch (IOException e) {
                e.getMessage();
            }

            return null;
        }

        @Override
        protected void onPostExecute(String result) {
        }
    }

    public class PagerAdapter extends FragmentStatePagerAdapter {
        int mNumOfTabs;

        public PagerAdapter(FragmentManager fm, int NumOfTabs) {
            super(fm);
            this.mNumOfTabs = NumOfTabs;
        }

        @Override
        public Fragment getItem(int position) {

            switch (position) {
                case 0:
                    MonitoringFragment monitoringFragment = new MonitoringFragment();
                    mMonitoringListener = monitoringFragment;
                    return monitoringFragment;
                case 1:
                    UtilizationFragment utilizationFragment = new UtilizationFragment();
                    mUtilizationListener = utilizationFragment;
                    return utilizationFragment;
                case 2:
                    thresholdFragment = new ThresholdFragment();
                    return thresholdFragment;
                case 3:
                    HistoryFragment historyFragment = new HistoryFragment();
                    mHistoryListener = historyFragment;
                    return historyFragment;
                default:
                    return null;
            }
        }

        @Override
        public int getCount() {
            return mNumOfTabs;
        }
    }
}
