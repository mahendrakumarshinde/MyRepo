package com.idragonit.cloudexplorer;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.google.api.client.extensions.android.http.AndroidHttp;
import com.google.api.client.extensions.android.json.AndroidJsonFactory;
import com.idragonit.cloudmonitor.backend.myApi.MyApi;
import com.idragonit.cloudmonitor.backend.myApi.model.MacAddressInfo;
import com.idragonit.cloudmonitor.backend.myApi.model.MacAddressInfoCollection;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
public class DeviceScanActivity extends Activity {
    public static final String DEVICE_DATA_AVAILABLE = "com.idragonit.bleexplorer.DEVICE_DATA_AVAILABLE";
    public static final String DATABASE_NAME = "database_name";

    private static final int MaxDeviceCount = 500;
    private static final long SCAN_PERIOD = 5000L;
    private static final int STATE_NONE = 0;
    private static final int STATE_SCANNING = 1;
    private static final int STATE_STOP = 2;
    private static final String TAG = DeviceScanActivity.class.getSimpleName();
    private Handler mHandler;
    private LeDeviceListAdapter mLeDeviceListAdapter;
    private boolean mScanning;
    private ArrayList<deviceInfo> scanDevice = new ArrayList<deviceInfo>();

    private ListView mListView;
    private Button mBtnScan;

    private View mLayoutDevices;
    private View mLayoutScan;
    private View mLayoutNoResult;

    String mServerName = "server0";
    String mDbName;
    String mUserName = "root";

    private class LeDeviceListAdapter extends BaseAdapter {
        private LayoutInflater mInflator = getLayoutInflater();

        public LeDeviceListAdapter() {
            super();
            Log.d(TAG, "*** LeDeviceListAdapter.LeDeviceListAdapter()");
        }

        public int getCount() {
            Log.d(TAG, "*** LeDeviceListAdapter.getCount()");
            return scanDevice.size();
        }

        public Object getItem(int i) {
            Log.d(TAG, "*** LeDeviceListAdapter.getItem()");
            return scanDevice.get(i);
        }

        public long getItemId(int i) {
            Log.d(TAG, "*** LeDeviceListAdapter.getItemId()");
            return (long) i;
        }

        public View getView(int position, View view, ViewGroup viewgroup) {
            Log.d(TAG, String.format("*** LeDeviceListAdapter.getView() position=%d", position));

            ViewHolder viewholder;

            if (view == null) {
                view = mInflator.inflate(R.layout.device_scan, null);
                viewholder = new ViewHolder();
                viewholder.deviceAddress = (TextView) view.findViewById(R.id.device_address);
                view.setTag(viewholder);
            } else {
                viewholder = (ViewHolder) view.getTag();
            }

            viewholder.deviceAddress.setText(scanDevice.get(position).Address);

            return view;
        }
    }

    static class ViewHolder {

        TextView deviceAddress;
    }

    class deviceInfo {
        public String Address;
    }

    private void showState(int state) {
        if (state == STATE_NONE) {
            mBtnScan.setText(R.string.menu_scan);

            mLayoutDevices.setVisibility(View.GONE);
            mLayoutScan.setVisibility(View.GONE);
            mLayoutNoResult.setVisibility(View.VISIBLE);
        }
        else if (state == STATE_SCANNING) {
            mBtnScan.setText(R.string.menu_stop);

            mLayoutDevices.setVisibility(View.GONE);
            mLayoutScan.setVisibility(View.VISIBLE);
            mLayoutNoResult.setVisibility(View.GONE);
        }
        else {
            mBtnScan.setText(R.string.menu_scan);

            mLayoutDevices.setVisibility(View.VISIBLE);
            mLayoutScan.setVisibility(View.GONE);
            mLayoutNoResult.setVisibility(View.GONE);
        }
    }

    public void onCreate(Bundle bundle) {
        Log.d(TAG, "*** onCreate()");

        super.onCreate(bundle);

        setContentView(R.layout.activity_scan);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        Intent intent = getIntent();

        mDbName = intent.getStringExtra(DATABASE_NAME);

        mListView = (ListView) findViewById(R.id.list_devices);
        mBtnScan = (Button) findViewById(R.id.btn_scan);

        mLayoutDevices = findViewById(R.id.layout_devices);
        mLayoutScan = findViewById(R.id.layout_scan);
        mLayoutNoResult = findViewById(R.id.layout_no_result);

        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Log.d(TAG, String.format("*** onListItemClick() position %d", position));

                if (mScanning) {
                    if (scanDevice.size() > 0)
                        showState(STATE_STOP);
                    mScanning = false;
                }

                Intent intent = new Intent(DeviceScanActivity.this, ReadDataActivity.class);

                intent.putExtra("DEVICE_ADDRESS", scanDevice.get(position).Address);
                intent.putExtra(DATABASE_NAME, mDbName);

                startActivity(intent);
            }
        });

        mBtnScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mScanning) {
                    return;
                }

                mScanning = true;
                showState(STATE_SCANNING);
                (new GetMacAddressAsyncTask()).execute(DeviceScanActivity.this);
            }
        });

        mHandler = new Handler();
        mLeDeviceListAdapter = new LeDeviceListAdapter();
        mListView.setAdapter(mLeDeviceListAdapter);

        mScanning = true;
        showState(STATE_SCANNING);
        (new GetMacAddressAsyncTask()).execute(DeviceScanActivity.this);
    }

    protected void onPause() {
        super.onPause();
    }

    protected void onResume() {
        super.onResume();
    }

    public static MyApi myApiService = null;

    class GetMacAddressAsyncTask extends AsyncTask<Context, Void, MacAddressInfoCollection> {
        private Context context;

        @Override
        protected MacAddressInfoCollection doInBackground(Context... params) {
            if(myApiService == null) {  // Only do this once
                MyApi.Builder builder = new MyApi.Builder(AndroidHttp.newCompatibleTransport(), new AndroidJsonFactory(), null)
                        .setRootUrl("https://infinite-uptime-1232.appspot.com/_ah/api/");
                myApiService = builder.build();
            }

            context = params[0];

            try {
                MacAddressInfoCollection collection = myApiService.getWholeMacAddressList(mServerName, mDbName, mUserName).execute();
                return collection;
            } catch (IOException e) {
                e.getMessage();
            }

            return null;
        }

        @Override
        protected void onPostExecute(MacAddressInfoCollection result) {
            if (result != null) {
                List<MacAddressInfo> macAddressList = result.getItems();
                scanDevice.clear();

                for (int i = 0; i < macAddressList.size(); i++) {
                    deviceInfo info = new deviceInfo();
                    info.Address = macAddressList.get(i).getMacAddress();
                    scanDevice.add(info);
                }

                mLeDeviceListAdapter.notifyDataSetChanged();
            }

            mScanning = false;

            if (scanDevice.size() == 0) {
                showState(STATE_NONE);
            }
            else {
                showState(STATE_STOP);
            }
        }
    }
}

