package com.idragonit.cloudexplorer.fragment;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import com.github.mikephil.charting.charts.CombinedChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.CombinedData;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.idragonit.cloudexplorer.AppData;
import com.idragonit.cloudexplorer.IReceiveFeatureData;
import com.idragonit.cloudexplorer.R;
import com.idragonit.cloudexplorer.ReadDataActivity;
import com.idragonit.cloudexplorer.dao.BLEFeature;

import java.util.ArrayList;

public class HistoryFragment extends Fragment implements IReceiveFeatureData {

    View mView;
    LinearLayout mLayoutHistory;
    FeatureData mChartData;
    Spinner mSpinner;
    int mCurFeature = 0;

    public class FeatureData {
        TextView chartName;
        CombinedChart chartView;
        long startTime = 0;
        String featureId = "";
        ArrayList<BLEFeature> dataList = new ArrayList<BLEFeature>();
        CombinedData combinedData;
        LineData lineData;
        BarData barData;
        float maxValue = 0f;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mView = inflater.inflate(R.layout.fragment_history, container, false);
        mLayoutHistory = (LinearLayout) mView.findViewById(R.id.layout_history);

        String[] featureValues = new String[6];

        featureValues[0] = "Signal Energy";
        featureValues[1] = "Mean Crossing Rate";
        featureValues[2] = "Spectral Centroid";
        featureValues[3] = "Spectral Flatness";
        featureValues[4] = "Accel Spectral Spread";
        featureValues[5] = "Audio Spectral Spread";

        mSpinner = (Spinner) mView.findViewById(R.id.spinner);
        ArrayAdapter adapter = new ArrayAdapter(getActivity(), R.layout.layout_spinner_item, featureValues);
        mSpinner.setAdapter(adapter);
        mSpinner.setPrompt("Signal Energy");
        mSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                mCurFeature = position;
                mChartData.featureId = String.format("%04d", mCurFeature);
                mChartData.chartName.setText("Feature ID : " + mChartData.featureId);
                mChartData.startTime = AppData.getFeatureStartTime(getActivity(), mChartData.featureId);
                refreshFeatureData(mChartData.featureId, mChartData, (ReadDataActivity) getActivity());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        addChart(String.format("%04d", mCurFeature));

        return mView;
    }

    public FeatureData addChart(String id) {
        mChartData = new FeatureData();

        View view = getActivity().getLayoutInflater().inflate(R.layout.layout_feature_chart, null);
        mLayoutHistory.addView(view);
        mChartData.chartName = (TextView) view.findViewById(R.id.txt_name);
        mChartData.chartView = (CombinedChart) view.findViewById(R.id.chart);
        mChartData.featureId = id;
        mChartData.startTime = AppData.getFeatureStartTime(getActivity(), id);

        mChartData.chartName.setText("Feature ID : " + id);

        mChartData.chartView.setDescription("");
        mChartData.chartView.setBackgroundColor(Color.WHITE);
        mChartData.chartView.setDrawGridBackground(false);
        mChartData.chartView.setDrawBarShadow(false);

        // draw bars behind lines
        mChartData.chartView.setDrawOrder(new CombinedChart.DrawOrder[]{
                CombinedChart.DrawOrder.BAR, CombinedChart.DrawOrder.LINE
        });

        YAxis rightAxis = mChartData.chartView.getAxisRight();
        rightAxis.setDrawGridLines(false);
        rightAxis.setAxisMinValue(0f); // this replaces setStartAtZero(true)

        YAxis leftAxis = mChartData.chartView.getAxisLeft();
        leftAxis.setDrawGridLines(false);
        leftAxis.setAxisMinValue(0f); // this replaces setStartAtZero(true)

        XAxis xAxis = mChartData.chartView.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTH_SIDED);

        ReadDataActivity activity = (ReadDataActivity) getActivity();
        refreshFeatureData(id, mChartData, activity);

        mChartData.chartView.getLegend().setEnabled(false);

        return mChartData;
    }

    public void refreshFeatureData(String id, FeatureData featureData, ReadDataActivity activity) {
        ArrayList<BLEFeature> featureList = activity.mFeatureMap.get(id);

        if (featureList == null) {
            featureData.chartView.setData(null);
            featureData.chartView.invalidate();

            return;
        }

        ArrayList<String> timeList = new ArrayList<>();
        long time = 0;

        timeList.add("0s");

        int index = 0;

        if (featureList.size() > 25) {
            index = featureList.size() - 25;
        }

        for (; index < featureList.size(); index++) {
            time += featureList.get(index).getDuration();

            if (time < 60000)
                timeList.add((time / 1000) + "s");
            else if (time < 3600000)
                timeList.add((time / 60000) + "m" + ((time % 60000) / 1000) + "s");
            else
                timeList.add((time / 3600000) + "h" + ((time % 3600000) / 60000) + "m");

            if (featureData.maxValue < featureList.get(index).getFeatureValue())
                featureData.maxValue = featureList.get(index).getFeatureValue();
        }

        featureData.combinedData = new CombinedData(timeList);
        featureData.lineData = generateLineData(id, featureList);
        featureData.barData = generateBarData(id, featureList, featureData.maxValue);

        featureData.combinedData.setData(featureData.lineData);
        //featureData.combinedData.setData(featureData.barData);

        featureData.chartView.setData(featureData.combinedData);
        featureData.chartView.invalidate();
    }

    @Override
    public void readData(int status, String id, float value, long readTime, boolean isNew) {
        if (getActivity() == null)
            return;

        ReadDataActivity activity = (ReadDataActivity) getActivity();
        FeatureData featureData = mChartData;

        if (featureData != null && TextUtils.equals(id, featureData.featureId)) {
            refreshFeatureData(id, featureData, activity);
        }

    }

    private LineData generateLineData(String id, ArrayList<BLEFeature> featureList) {

        LineData d = new LineData();

        ArrayList<Entry> entries = new ArrayList<Entry>();

        entries.add(new Entry(0f, 0));

        int[] colors;
        int index = 0;
        int colorIndex = 0;

        if (featureList.size() > 25) {
            index = featureList.size() - 25;
            colors = new int[25];
        }
        else {
            colors = new int[featureList.size()];
        }

        for (; index < featureList.size(); index++) {
            BLEFeature feature = featureList.get(index);
            entries.add(new Entry(feature.getFeatureValue(), colorIndex+1));
            if (feature.getStatus() == STATUS_IDLE)
                colors[colorIndex] = STATUS_IDLE_COLOR;
            else if (feature.getStatus() == STATUS_NORMAL_CUTTING)
                colors[colorIndex] = STATUS_NORMAL_CUTTING_COLOR;
            else if (feature.getStatus() == STATUS_WARNING)
                colors[colorIndex] = STATUS_WARNING_COLOR;
            else if (feature.getStatus() == STATUS_DANGER)
                colors[colorIndex] = STATUS_DANGER_COLOR;

            colorIndex++;
        }

        LineDataSet set = new LineDataSet(entries, id);
        set.setColors(colors);
        set.setLineWidth(1.5f);
        set.setCircleColor(Color.rgb(0, 0, 0));
        set.setCircleRadius(2.5f);
        set.setFillColor(Color.rgb(240, 238, 70));
        set.setDrawCubic(false);
        set.setDrawValues(true);
        set.setValueTextSize(10f);
        set.setValueTextColor(Color.rgb(0, 0, 0));

        set.setAxisDependency(YAxis.AxisDependency.LEFT);

        d.addDataSet(set);

        return d;
    }

    private BarData generateBarData(String id, ArrayList<BLEFeature> featureList, float maxValue) {

        BarData d = new BarData();

        ArrayList<BarEntry> entries = new ArrayList<BarEntry>();

        int index = 0;
        int[] colors;
        int colorIndex = 0;

        if (featureList.size() > 25) {
            index = featureList.size() - 25;
            colors = new int[25];
        }
        else {
            colors = new int[featureList.size()];
        }

        for (; index < featureList.size(); index++) {
            BLEFeature feature = featureList.get(index);
            entries.add(new BarEntry(maxValue, colorIndex));

            if (feature.getStatus() == STATUS_IDLE)
                colors[colorIndex] = STATUS_IDLE_COLOR & 0x3FFFFFFF;
            else if (feature.getStatus() == STATUS_NORMAL_CUTTING)
                colors[colorIndex] = STATUS_NORMAL_CUTTING_COLOR & 0x3FFFFFFF;
            else if (feature.getStatus() == STATUS_WARNING)
                colors[colorIndex] = STATUS_WARNING_COLOR & 0x3FFFFFFF;
            else if (feature.getStatus() == STATUS_DANGER)
                colors[colorIndex] = STATUS_DANGER_COLOR & 0x3FFFFFFF;

            colorIndex++;
        }

        BarDataSet set = new BarDataSet(entries, id);
        set.setColors(colors);
        set.setDrawValues(false);
        d.addDataSet(set);

        set.setAxisDependency(YAxis.AxisDependency.LEFT);

        return d;
    }

}