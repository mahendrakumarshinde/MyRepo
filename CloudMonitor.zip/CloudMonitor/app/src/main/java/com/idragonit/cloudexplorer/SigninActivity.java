package com.idragonit.cloudexplorer;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import com.google.api.client.extensions.android.http.AndroidHttp;
import com.google.api.client.extensions.android.json.AndroidJsonFactory;
import com.idragonit.cloudexplorer.dialog.WaitingDialog;
import com.idragonit.cloudmonitor.backend.myApi.MyApi;
import com.idragonit.cloudmonitor.backend.myApi.model.UserInfo;

import java.io.IOException;

@TargetApi(Build.VERSION_CODES.JELLY_BEAN_MR2)
public class SigninActivity extends Activity {
    private static final String TAG = SigninActivity.class.getSimpleName();

    WaitingDialog mWaitingDialog;

    TextView mTxtUserName;
    TextView mTxtPassword;

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);

        setContentView(R.layout.activity_signin);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        mTxtUserName = (TextView) findViewById(R.id.txt_username);
        mTxtPassword = (TextView) findViewById(R.id.txt_password);

        findViewById(R.id.btn_signin).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userName = mTxtUserName.getText().toString();
                String password = mTxtUserName.getText().toString();

                if (TextUtils.isEmpty(userName)) {
                    Toast.makeText(SigninActivity.this, "Please input user name!", Toast.LENGTH_LONG).show();
                    return;
                }

                if (TextUtils.isEmpty(password)) {
                    Toast.makeText(SigninActivity.this, "Please input password!", Toast.LENGTH_LONG).show();
                    return;
                }

                showLoading("Sign in...");
                (new SigninTask(userName, password)).execute(SigninActivity.this);
            }
        });
    }

    public void showLoading(String message){
        hideLoading();

        mWaitingDialog = new WaitingDialog(this, message);
        mWaitingDialog.show();
    }

    public void hideLoading(){
        if (mWaitingDialog!=null){
            try {
                mWaitingDialog.dismiss();
                mWaitingDialog = null;
            }catch (Exception e){}
        }
    }

    class SigninTask extends AsyncTask<Context, Void, UserInfo> {
        private Context context;
        private String mUserName;
        private String mPassword;

        public SigninTask(String userName, String password) {
            mUserName = userName;
            mPassword = password;
        }

        @Override
        protected UserInfo doInBackground(Context... params) {
            if(DeviceScanActivity.myApiService == null) {  // Only do this once
                MyApi.Builder builder = new MyApi.Builder(AndroidHttp.newCompatibleTransport(), new AndroidJsonFactory(), null)
                        .setRootUrl("https://infinite-uptime-1232.appspot.com/_ah/api/");
                DeviceScanActivity.myApiService = builder.build();
            }

            context = params[0];

            try {
                UserInfo userInfo = DeviceScanActivity.myApiService.userLogin(mUserName, mPassword).execute();
                return userInfo;
            } catch (IOException e) {
                e.getMessage();
            }

            return null;
        }

        @Override
        protected void onPostExecute(UserInfo result) {
            hideLoading();

            if (result != null) {
                Intent intent = new Intent(SigninActivity.this, DeviceScanActivity.class);
                intent.putExtra(DeviceScanActivity.DATABASE_NAME, result.getDbName());
                startActivity(intent);
                finish();
            }
            else {
                Toast.makeText(SigninActivity.this, "Signin is failed!", Toast.LENGTH_LONG).show();
            }
        }
    }
}

