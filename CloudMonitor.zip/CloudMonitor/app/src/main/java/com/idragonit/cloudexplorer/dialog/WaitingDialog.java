package com.idragonit.cloudexplorer.dialog;

import android.app.ProgressDialog;
import android.content.Context;

public class WaitingDialog extends ProgressDialog {

	Context mContext;
	String mMessage;

	public WaitingDialog(Context context, String message) {
		super(context);

		// TODO Auto-generated constructor stub
		mContext = context;
		mMessage = message;

		setCancelable(false);
		setMessage(message);
	}
}

