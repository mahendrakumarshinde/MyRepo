This library, originally from Thomas Roell ((email)[grumpyoldpizza@gmail.com]), was modified for IU need.

The **I2S_BUFFER_SIZE** definition in I2S.h was changed to 64 from 512, so that I2S Tx callbacks can drive data collection at higher frequencies. A smaller buffer size means that Tx callbacks are triggered more often (to empty the buffer).
