/*
 5/8/17
 This example sketch includes augmented functionality to use the ESP82XX "Deep Sleep" function and OTA FW updates:
 
 1) "WiFiSerial::serialCom()" is called each iteration of the loop to check for incoming status messages from the WiFi/UART bridge
 2) The WiFi UART bridge sends command "21" to the host MCU (STM32L4 Butterfly) at a 1Hz interval; global variable "WiFi_bridge_ready"
    is set true to indicate that the bridge is active and connected to a suitable host. The sketch will not update over WiFi unless
    "WiFi_bridge_ready" is true. If the bridge is sleeping, don't bother updating...
 3) Calling "WiFiSerial::Put_WiFi_To_Sleep(WIFI_DEEP_SLEEP)" will put the ESP82XX WiFi/UART bridge to sleep for "WIFI_DEEP_SLEEP" seconds.
    When it wakes up, it will reconnect with the host and indicate it is ready fro traffic
 4) There is a structure in the main loop data update that allows an update to be made and then put the bridge to sleep. When the bridge
    wakes up and indicates "WiFi_bridge_ready" as true, it will do the next update and go back to sleep...
 5) The WiFi can be shut off completely by calling "WiFiSerial::Put_WiFi_To_Sleep(0.0f)" in setup(). Using 0.0f as the argument will keep 
    the WiFi shut off until the next power cycle
 6) Receiving serial command "12" initiates the OTA FW update function: "OTA_Update(uint32_t update_size, uint16_t update_blocks)"
 7) OTA FW update capability is currently demonstrated using an ESP8285 development board (in AP mode) in conjunction with a "Dragonfly" 
    STM32L4 development board. The dragonfly has drag-and-drop file handling capability for the new FW ".iap" file and communicates with
    the ESP8285 also by WiFi/UART bridge
 8) The IU board will NAK the transaction if the FW image exceeds available flash space or if a data black is skipped; all NAK conditions result
    in resumption of normal steady-state operaton of the IU board
*/
