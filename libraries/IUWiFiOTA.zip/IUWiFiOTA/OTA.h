#ifndef OTA_h
#define OTA_h

#include "Host_WiFiserial.h"

#define FLASHSTART                    ((uint32_t)(&__FlashBase))
#define FLASHEND                      ((uint32_t)(&__FlashLimit))

extern uint8_t                        WiFi_bridge_ready;
extern uint8_t                        OTA_bytes[130];
extern uint32_t                       OTA_Update_Size;
extern uint16_t                       OTA_Update_Blocks;
extern uint16_t                       block;

class OTA
{
  public:
                                      OTA();
     static void                      OTA_Update(uint32_t update_size, uint16_t update_blocks);
  private:
};

#endif // OTA_h

