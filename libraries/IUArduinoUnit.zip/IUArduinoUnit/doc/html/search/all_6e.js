var searchData=
[
  ['name',['name',['../class_test.html#acff24a84a14b606d01913a4a701ca821',1,'Test']]],
  ['nextbyte',['nextByte',['../class_fake_stream.html#a4b37e51beae0c92064eb81c06b5076cd',1,'FakeStream']]]
];
