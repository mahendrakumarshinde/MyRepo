/*
 * Copyright (c) 2017 Thomas Roell.  All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal with the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 *  1. Redistributions of source code must retain the above copyright notice,
 *     this list of conditions and the following disclaimers.
 *  2. Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimers in the
 *     documentation and/or other materials provided with the distribution.
 *  3. Neither the name of Thomas Roell, nor the names of its contributors
 *     may be used to endorse or promote products derived from this Software
 *     without specific prior written permission.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
 * CONTRIBUTORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * WITH THE SOFTWARE.
 */

#include "GNSS.h"

GNSSLocation::GNSSLocation()
{
    _location.time.year   = 1980 - 1980;
    _location.time.month  = 1;
    _location.time.day    = 6;
    _location.time.hour   = 0;
    _location.time.minute = 0;
    _location.time.second = 0;
    _location.time.millis = 0;
    _location.mask        = 0;
    _location.correction  = 0;
    _location.type        = GNSS_LOCATION_TYPE_NONE;
    _location.latitude    = 0;
    _location.longitude   = 0;
    _location.altitude    = 0;
    _location.separation  = 0;
    _location.speed       = 0;
    _location.course      = 0;
    _location.climb       = 0;
    _location.ehpe        = 0;
    _location.evpe        = 0;
    _location.quality     = GNSS_LOCATION_QUALITY_NONE;
    _location.numsv       = 0;
    _location.pdop        = 9999;
    _location.hdop        = 9999;
    _location.vdop        = 9999;
    _location.ticks       = 0;
}

GNSSLocation::GNSSLocation(const gnss_location_t *location)
{
    _location = *location;
}

GNSSLocation::operator bool() const
{
    return (_location.type != GNSS_LOCATION_TYPE_NONE);
}

enum GNSSLocation::GNSSfixType GNSSLocation::fixType(void) const
{
    return (enum GNSSLocation::GNSSfixType)_location.type;
}

enum GNSSLocation::GNSSfixQuality GNSSLocation::fixQuality(void) const
{
    return (enum GNSSLocation::GNSSfixQuality)_location.quality;
}

unsigned int GNSSLocation::satellites(void) const
{
    return _location.numsv;
}

uint16_t GNSSLocation::year(void) const
{
    return _location.time.year + 1980;
}

uint8_t GNSSLocation::month(void) const
{
    return _location.time.month;
}

uint8_t GNSSLocation::day(void) const
{
    return _location.time.day;
}

uint8_t GNSSLocation::hour(void) const
{
    return _location.time.hour;
}

uint8_t GNSSLocation::minute(void) const
{
    return _location.time.minute;
}

uint8_t GNSSLocation::second(void) const
{
    return _location.time.second;
}

uint16_t GNSSLocation::millis(void) const
{
    return _location.time.millis;
}

uint8_t GNSSLocation::correction(void) const
{
    return _location.correction;
}

double GNSSLocation::latitude(void) const
{
    return (double)_location.latitude / (double)1e7;
}

double GNSSLocation::longitude(void) const
{
    return (double)_location.longitude / (double)1e7;
}

float GNSSLocation::altitude(void) const
{
    return (float)_location.altitude / (float)1e3;
}

float GNSSLocation::separation(void) const
{
    return (float)_location.separation / (float)1e3;
}

float GNSSLocation::speed(void) const
{
    return (float)_location.speed / (float)1e3;
}

float GNSSLocation::course(void) const
{
    return (float)_location.course / (float)1e5;
}

float GNSSLocation::climb(void) const
{
    return (float)_location.climb / (float)1e3;
}

float GNSSLocation::ehpe(void) const
{
    return (float)_location.ehpe / (float)1e3;
}

float GNSSLocation::evpe(void) const
{
    return (float)_location.evpe / (float)1e3;
}

float GNSSLocation::pdop(void) const
{
    return (float)_location.pdop / (float)1e2;
}

float GNSSLocation::hdop(void) const
{
    return (float)_location.hdop / (float)1e2;
}

float GNSSLocation::vdop(void) const
{
    return (float)_location.vdop / (float)1e2;
}

uint32_t GNSSLocation::ticks() const
{
    return _location.ticks;
}

void GNSSClass::begin(Uart &uart, GNSSClass::GNSSmode mode, GNSSClass::GNSSrate rate)
{
    _uart = &uart; 

    _uart->begin(9600);

    if (mode == MODE_NMEA)
    {
	gnss_initialize(mode, rate, 9600, &GNSSClass::_send_routine, &GNSSClass::_location_callback, &GNSSClass::_satellites_callback);
    }
    else
    {
	gnss_initialize(mode, rate, 115200, &GNSSClass::_send_routine, &GNSSClass::_location_callback, &GNSSClass::_satellites_callback);

	_uart->begin(115200);
    }

    _uart->onReceive(&GNSSClass::_receive_routine);
}

void GNSSClass::end()
{
    if (_uart)
    {
	_uart->end();
	_uart = NULL;
    }
}

void GNSSClass::ppsUpdate(uint32_t ticks)
{
    if (_uart)
    {
	gnss_pps_update(ticks);
    }
}

bool GNSSClass::setConstellation(GNSSconstellation constellation)
{
    return (_uart && gnss_set_constellation(constellation));
}

bool GNSSClass::setSBAS(bool on)
{
    return (_uart && gnss_set_sbas(on));
}

bool GNSSClass::setQZSS(bool on)
{
    return (_uart && gnss_set_qzss(on));
}

bool GNSSClass::setPeriodic(unsigned int onTime, unsigned int period, bool force)
{
    return (_uart && gnss_set_periodic(onTime, period, force));
}

bool GNSSClass::sleep()
{
    return (_uart && gnss_sleep());
}

bool GNSSClass::wakeup()
{
    return (_uart && gnss_wakeup());
}

bool GNSSClass::done()
{
    return gnss_done();
}


int GNSSClass::available(void)
{
    return !!_location_pending;
}

GNSSLocation GNSSClass::read(void)
{
    gnss_location_t location;

    if (_location_pending)
    {
	do
	{
	    _location_pending = false;

	    location = _location_data;
	}
	while (_location_pending);

	return GNSSLocation(&location);
    }
    else
    {
	return GNSSLocation();
    }
}

GNSSLocation GNSSClass::peek(void)
{
    gnss_location_t location;

    if (_location_pending)
    {
	do
	{
	    _location_pending = false;

	    location = _location_data;
	}
	while (_location_pending);

	_location_pending = true;

	return GNSSLocation(&location);
    }
    else
    {
	return GNSSLocation();
    }
}

void GNSSClass::onReceive(void(*callback)(void))
{
    _receive_callback = callback;
}

void GNSSClass::_receive_routine(void)
{
    uint8_t rx_data[16];
    int rx_count;

    do
    {
	rx_count = GNSS._uart->read(&rx_data[0], sizeof(rx_data));

	if (rx_count > 0)
	{
	    gnss_receive(&rx_data[0], rx_count);
	}
    }
    while (rx_count > 0);
}

void GNSSClass::_send_routine(const uint8_t *data, uint32_t count, gnss_send_callback_t callback)
{
    if (GNSS._uart)
    {
	GNSS._uart->write(data, count, callback);
    }
}

void GNSSClass::_location_callback(const gnss_location_t *location)
{
    GNSS._location_data = *location;
    GNSS._location_pending = true;

    if (GNSS._receive_callback)
    {
	(*GNSS._receive_callback)();
    }
}

void GNSSClass::_satellites_callback(const gnss_satellites_t *satellites)
{
    GNSS._satellites_data = *satellites;
    GNSS._satellites_pending = true;
}

GNSSClass GNSS;
